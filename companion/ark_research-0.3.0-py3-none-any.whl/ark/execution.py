"""ExecutionMixin: planner cycle, experiment loop, writing phase, meta-debug, self-repair."""

import hashlib
import json
import os
import re
import subprocess
import time
import yaml
from datetime import datetime, timedelta
from pathlib import Path
from typing import List

from ark import shutting_down
from ark.quality import raw_log_sanity, format_for_prompt
from ark.findings_schema import (
    validate_findings,
    format_violations_for_log,
    sync_findings_from_json,
)
from ark.config import defaults
from ark.engines.cli import selected_agent_runtime
from ark.latex.utils import BODY_END_PDF_MARKER


_STRUCTURE = {
    "labels": re.compile(r"\\label\{([^}]*)\}"),
    "figures": re.compile(r"\\includegraphics"),
    "tables": re.compile(r"\\begin\{table\*?\}"),
    "sections": re.compile(r"\\(?:sub)*section\{"),
}


def _digests(root: Path, rel_paths) -> dict:
    """sha256 of each file, or None where it does not exist.

    Used to tell whether an agent actually edited the files it was sent to
    edit. Content, not mtime: a tool that rewrites a file byte-identically
    has not changed it, and a tool that touches it without writing has not
    either.
    """
    out = {}
    for rel in rel_paths:
        p = Path(root) / rel
        try:
            out[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
        except Exception:
            out[rel] = None
    return out


def _structure_lost(before: str, after: str, ignore_labels=(), ignore_counts=None) -> list:
    """What a rewrite of main.tex removed: labels by name, the rest by count.

    Starred sections are left out because the end-matter pass adds one
    (Acknowledgments) on purpose.

    ``ignore_labels`` and ``ignore_counts`` carry removals already accounted
    for — the delivery contract passes the ones the review itself asked for,
    so obeying a reviewer is not reported as a loss.
    """
    ignore_labels = set(ignore_labels)
    ignore_counts = ignore_counts or {}
    lost = []
    for name, pat in _STRUCTURE.items():
        if name == "labels":
            gone = sorted(set(pat.findall(before)) - set(pat.findall(after)) - ignore_labels)
            if gone:
                lost.append(f"labels {', '.join(gone[:5])}")
        else:
            n0, n1 = len(pat.findall(before)), len(pat.findall(after))
            dropped = n0 - n1 - ignore_counts.get(name, 0)
            if dropped > 0:
                lost.append(f"{dropped} {name}")
    return lost


_COLLECT_RESULTS = (
    "The jobs you started have finished: the orchestrator waited for them and copied their "
    "output into results/. Check each job's output and exit status, verify the numbers against "
    "the files, and update auto_research/state/findings.json with what the results actually "
    "show. If a job failed or produced nothing, say so plainly and do not fill in its results. "
    "Reply with a short summary.")


def collect_after_jobs(host, sessions: list, waited_s: float, *, outcome_out: dict | None = None):
    """Resume the experimenter that submitted the jobs, now that they are done.

    It knows what it submitted and why. A fresh session first re-reads the
    project (10-19 actions in production traces, each at a 60-90k context),
    and the review-loop experimenter was asked to analyse before its jobs had
    even finished. Only runtimes that can resume hand back a session, and a
    wait under a minute means nothing was running.
    """
    if not sessions or waited_s < 60 or shutting_down.is_set() or getattr(host, "_terminal_error", None):
        return None
    host.log_step("Jobs finished, resuming the experimenter to collect the results", "progress")
    return host.run_agent("experimenter", _COLLECT_RESULTS, timeout=1800,
                          continue_session=sessions[-1], outcome_out=outcome_out)


def _experiment_writeup_task(issue: dict) -> str:
    """Writer task that carries a finished (or failed) experiment into the paper."""
    what = issue.get("description") or issue.get("title") or ""
    if issue.get("status") == "failed":
        return (
            "The experiment planned for this issue is recorded as failed. Check "
            "`results/` for any output it left (a session can be cut off while "
            "its jobs still finish). Report only what those files show. Where "
            "nothing exists, make sure the paper claims nothing that depended on "
            "it: remove or qualify those claims and state the gap plainly, for "
            "example in Limitations. Do not fill in numbers.\n\n"
            f"Issue: {what}")
    return (
        "The experiment for this issue has finished. Read its outputs under "
        "`results/` and the matching entries in `auto_research/state/findings.yaml`, "
        "then update the paper: tables, figure captions and the claims in the "
        "text. Use only numbers that appear in those files. If the outcome is null "
        "or contradicts the current text, change the text to match the result.\n\n"
        f"Issue: {what}")


class QuotaExhaustedError(Exception):
    """Raised when page count enforcement fails due to quota exhaustion."""

    def __init__(self, page_count: float, venue_pages: int):
        self.page_count = page_count
        self.venue_pages = venue_pages
        super().__init__(f"Quota exhausted with {page_count:.1f}/{venue_pages} body pages")


EXPERIMENT_RESUME_NOTE = (
    "\n## Resuming an interrupted attempt\n"
    "An earlier session was cut off. Check existing scripts, scheduler jobs, and results first. "
    "Keep completed work and run only what is missing or failed. "
    "Do not resubmit a job whose results already exist."
)


def settle_interrupted_experiments(project):
    try:
        if project._compute_backend.wait_for_completion(max_wait_hours=4):
            return True
    except Exception as exc:
        project.log(f"Could not check jobs from the interrupted attempt: {exc}", "WARN")
    if not shutting_down.is_set():
        project._terminal_error = "Could not reconcile existing experiment jobs. Check the scheduler before resuming."
    return False


class ExecutionMixin:
    """Mixin providing execution logic for the paper improvement pipeline.

    Expects self to have: code_dir, config, log, log_step, log_summary_box,
    run_agent, memory, state_dir, action_plan_file, latest_review_file,
    findings_file, literature_file, latex_dir, figures_dir, hooks,
    _save_action_plan, _load_action_plan, compile_latex,
    _generate_figures_from_results, generate_figures, paper_accept_threshold,
    iteration, project_name, send_notification.
    """

    def _wait_for_local_results(self, max_wait_hours: float) -> bool:
        """Wait for local experiment results. Delegates to compute backend."""
        return self._compute_backend.wait_for_completion(max_wait_hours)

    def wait_for_slurm(self, max_wait_hours: float = 4, job_prefix: str = None) -> bool:
        """Wait for submitted jobs to complete. Delegates to compute backend."""
        return self._compute_backend.wait_for_completion(max_wait_hours)

    def _wait_for_slurm_jobs(self, max_wait_hours: float = defaults.MAX_COMPUTE_WAIT_HOURS) -> bool:
        """Wait for experiment jobs (internal shortcut). Delegates to compute backend."""
        return self._compute_backend.wait_for_completion(max_wait_hours)

    def run_planner_cycle(self, review_output: str) -> bool:
        """Planner-driven iteration cycle (planning + execution).

        Calls run_planning_phase then _run_execute_phase.
        Returns True if successfully completed.
        """
        action_plan, planner_output = self.run_planning_phase(review_output)
        if action_plan is None:
            return False
        return self._run_execute_phase(action_plan, planner_output)

    def run_planning_phase(self, review_output: str):
        """Run the planning half: literature check + planner agent + validation.

        Returns:
            (action_plan dict, planner_output str) on success, (None, '') on failure.
        """
        # Step 0: Check for literature needs — re-bootstrap from Deep Research if needed
        needs_lit, lit_topics = self._check_needs_literature_search(review_output)
        if needs_lit:
            deep_research_file = self.state_dir / "deep_research.md"
            if deep_research_file.exists():
                self.log_step("Re-reading Deep Research report for additional citations...", "progress")
                self._bootstrap_citations_from_deep_research()
            else:
                self.log_step("No Deep Research report available for literature search", "info")

        # Step 1: Planner analyzes review
        self.log_step("Planner analyzing review...", "progress")
        findings_summary = self._load_findings_summary()

        escalations = self.memory.get_strategy_escalation()
        escalation_prompt = ""
        if escalations:
            escalation_prompt = "\n## Strategy Escalation Suggestions\n\n"
            escalation_prompt += "**Note**: The system intelligently determines whether escalation is needed based on issue type\n"
            escalation_prompt += "- Presentation/layout issues: prefer WRITING_ONLY or FIGURE_CODE_REQUIRED\n"
            escalation_prompt += "- Technical/data issues: may need EXPERIMENT_REQUIRED\n\n"
            for issue_id, info in escalations.items():
                count = info["count"]
                banned = info["banned_methods"]
                required = info["required_escalation"]
                issue_type = info.get("issue_type", "unknown")
                escalation_prompt += f"**{issue_id}** (repeated {count} times, type: {issue_type}):\n"
                if banned:
                    escalation_prompt += f"  - Tried multiple times: {', '.join(banned)}\n"
                if required:
                    escalation_prompt += f"  - Suggestion: **{required}**\n"
                escalation_prompt += "\n"

        # Page count awareness for planner
        page_constraint = ""
        venue_pages = self.config.get("venue_pages")
        page_count = getattr(self, '_body_page_count', 0)
        self._page_over_limit = False
        if venue_pages:
            if page_count and page_count > venue_pages + 0.10:
                self._page_over_limit = True
            page_count_display = f"{page_count:.1f}" if page_count else 'unknown'
            page_constraint = f"""
## PAGE LIMIT: {venue_pages} pages (body text, excluding references and appendix)

Current body pages: {page_count_display}. {"OVER LIMIT — page reduction is a priority." if self._page_over_limit else "Within limit."}
For every writing task, instruct the writer to compile and verify the body page count stays at or under {venue_pages} pages.
"""

        # Append overfull hbox warnings to planner page constraint
        overfull = getattr(self, '_overfull_warnings', [])
        if overfull:
            significant = [w for w in overfull if self._parse_overfull_pt(w) > 3.0]
            if significant:
                page_constraint += "\n## LAYOUT WARNINGS (from LaTeX compilation)\n\n"
                page_constraint += "The following content overflows column/page margins. Include a WRITING_ONLY task to fix these:\n\n"
                for w in significant:
                    page_constraint += f"- `{w}`\n"
                page_constraint += "\n**Fix**: Wrap overflowing tables with `\\resizebox{\\linewidth}{!}{...}` or break long equations.\n"

        # When the score gap from target is large, plans dominated by
        # WRITING_ONLY tasks rarely move the needle — the gap usually
        # reflects evidentiary issues that prose edits can only paper
        # over. Soft-nudge the planner; do not require any specific
        # task type.
        bottleneck_constraint = ""
        bottleneck = self._get_bottleneck()
        current_score = self.memory.scores[-1] if self.memory.scores else 0
        target_score = float(self.config.get("review_target_score", 8.0))
        if current_score and current_score < (target_score - 1.0):
            bottleneck_constraint = f"""
## SCORE GAP

Current score: {current_score}/10. Target: {target_score}/10.
Bottleneck dimension: {bottleneck or "unknown"}.

When the gap is this wide, plans dominated by WRITING_ONLY tasks tend
not to move the score — the gap usually reflects evidentiary or
analytical issues that prose edits can only paper over. Default
toward at least one EXPERIMENT_REQUIRED or FIGURE_CODE_REQUIRED
task this iteration, unless every flagged issue is purely cosmetic
(typos, awkward phrasing, layout artefacts). Apply judgment, not a
hard rule.
"""

        planner_output = self.run_agent("planner", f"""
Analyze the following review comments and generate action_plan.yaml.
{escalation_prompt}{page_constraint}{bottleneck_constraint}
## Review Comments Summary
Please read the full review report: auto_research/state/latest_review.md

## Current Findings Summary
{findings_summary}

## Classification (the most consequential decision in this plan)

For each issue, decide which agent can actually solve it. The four
categories partition the work by *what artifact change is required*:

- **WRITING_ONLY** — the writer agent can fix it by editing main.tex
  alone. The numbers and figures stay the same; only prose changes.
  (Typical: rewording an abstract, hedging a claim, adding a caveat,
  fixing typos, restructuring a paragraph.)

- **FIGURE_CODE_REQUIRED** — the coder agent must edit a plotting
  script and re-render. Use this when the underlying data already
  exists in `results/` but the figure must show different content
  (add a panel, change colormap, swap encoding, add error bars).

- **EXPERIMENT_REQUIRED** — the experimenter agent must run a script
  or sbatch job to **produce numbers that don't currently exist in
  `results/`**. The defining test is simple: *can a writer alone fix
  this by editing LaTeX?* If no — and `results/` doesn't already have
  the data the issue is asking for — it's EXPERIMENT_REQUIRED.

- **LITERATURE_REQUIRED** — pull additional citations from the
  Deep Research report.

## Self-check before committing to WRITING_ONLY

If the reviewer's "Fix" recipe combines a substantive action
(*compute*, *run*, *evaluate*, *measure*, *verify*, *test*, *add a
panel*) with a wrap-up ("...and add one sentence acknowledging
this"), do not classify the whole issue as WRITING_ONLY because the
last clause is writing. Pick the type that addresses the substantive
action; the writing tail is a follow-up the writer agent picks up
later. A WRITING_ONLY caveat that doesn't change the underlying
evidence will be re-flagged on the next iteration.

## Tasks
1. Identify all Major Issues (M1, M2, ...) and Minor Issues (m1, m2, ...)
2. Classify each issue per the rules above
3. Generate a specific action list per issue
4. Check strategy escalation requirements, ensure banned methods are not used
5. Write results to auto_research/state/action_plan.yaml
""", timeout=defaults.TIMEOUT_PLANNER, prior_context=review_output)

        # Validate action plan
        action_plan = self._load_action_plan()
        valid, validation_msg = self._validate_action_plan(action_plan)
        if not valid:
            self.log(f"Action plan validation failed: {validation_msg}", "WARN")
            self.log("Retrying planner with explicit format instructions...", "INFO")
            self.run_agent("planner", f"""
The previously generated action_plan.yaml has incorrect format: {validation_msg}

Please regenerate action_plan.yaml, strictly following this format:

```yaml
issues:
  - id: "M1"
    type: "EXPERIMENT_REQUIRED"  # or FIGURE_CODE_REQUIRED or WRITING_ONLY
    title: "Issue title"
    description: "Detailed description"
    status: "pending"
    actions:
      - agent: "experimenter"
        task: "What to do"
```

IMPORTANT: Every issue MUST have all fields: id, type, title, description, status, actions.

Please read auto_research/state/latest_review.md and regenerate.
{escalation_prompt}{page_constraint}{bottleneck_constraint}
## Current Findings Summary
{findings_summary}
""", timeout=defaults.TIMEOUT_HITL_DECISION, prior_context=review_output)
            action_plan = self._load_action_plan()

        issues = action_plan.get("issues", [])

        if not issues:
            self.log_step("Planner generated no issues, skipping", "warning")
            return None, ''

        # Hard cap: when over page limit, keep only top issues + compression task
        if getattr(self, '_page_over_limit', False) and len(issues) > 6:
            # Keep P0 (compression) + top 5 Major issues
            p0 = [i for i in issues if i.get("id") == "P0"]
            majors = [i for i in issues if i.get("id", "").startswith("M") and i.get("id") != "P0"]
            rest = [i for i in issues if i not in p0 and i not in majors]
            capped = p0 + majors[:5] + rest[:max(0, 6 - len(p0) - min(len(majors), 5))]
            dropped = len(issues) - len(capped)
            if dropped > 0:
                self.log(f"Page over limit: capped plan from {len(issues)} to {len(capped)} issues (dropped {dropped} low-priority)", "WARN")
                action_plan["issues"] = capped
                issues = capped
                self._save_action_plan(action_plan)

        exp_count = sum(1 for i in issues if i.get("type") == "EXPERIMENT_REQUIRED")
        lit_count = sum(1 for i in issues if i.get("type") == "LITERATURE_REQUIRED")
        fig_count = sum(1 for i in issues if i.get("type") == "FIGURE_CODE_REQUIRED")
        write_count = sum(1 for i in issues if i.get("type") == "WRITING_ONLY")
        self.log_step(f"Plan: {len(issues)} issues (exp:{exp_count}, lit:{lit_count}, fig:{fig_count}, write:{write_count})", "success")

        # Record repair methods and check violations
        violations = []
        for issue in issues:
            issue_id = issue.get("id", "")
            issue_type = issue.get("type", "")
            issue_desc = issue.get("title", "") or issue.get("description", "")
            # Build an issue dict for content-based tracking
            issue_ref = {"id": issue_id, "title": issue_desc}
            if issue_id and issue_type:
                self.memory.record_repair_method(issue_ref, issue_type)
                issue_key = self.memory._issue_key(issue_ref)
                banned = self.memory.get_banned_methods(issue_key, issue_desc)
                if issue_type in banned:
                    violations.append((issue_id, issue_type, banned, issue_desc))
                    self.log(f"Violation: {issue_id} used a banned method {issue_type}!", "ERROR")

        if violations:
            self.log("Detected possible strategy improvement suggestions", "WARNING")
            tech_violations = []
            for v in violations:
                issue_id, issue_type, banned, issue_desc = v
                pres_type = self.memory.classify_issue_type(issue_desc)
                if pres_type == "presentation":
                    self.log(f"  {issue_id}: presentation issue, {issue_type} may be appropriate, continuing", "INFO")
                else:
                    self.log(f"  {issue_id}: technical issue, suggest switching to {[m for m in ['FIGURE_CODE_REQUIRED', 'EXPERIMENT_REQUIRED'] if m not in banned]}", "WARNING")
                    tech_violations.append((issue_id, issue_type, banned, issue_desc))

            # Ask user when technical issues are repeating failed strategies
            user_provided_fix = False
            if tech_violations and self.telegram.is_configured:
                viol_list = "\n".join(f"- {vid}: tried `{vtype}` again" for vid, vtype, _, _ in tech_violations)
                idx, reply = self.ask_user_decision(
                    "Repeating failed strategies on technical issues",
                    options=[
                        "Auto-fix: try EXPERIMENT_REQUIRED next",
                        "Auto-fix: try FIGURE_CODE_REQUIRED next",
                        "Pause and wait for my guidance",
                    ],
                    timeout=defaults.TIMEOUT_HITL_DECISION,
                    default=0,
                    what_happened=(
                        f"{len(tech_violations)} technical issue(s) are reusing strategies "
                        f"that already failed:\n{viol_list}"
                    ),
                    background=[
                        "Banned strategies are tracked per-issue across iterations.",
                        "Auto-fix in 15 min if no reply.",
                    ],
                    option_details=[
                        "Upgrades the issue type to EXPERIMENT_REQUIRED and re-runs the experimenter.",
                        "Upgrades the issue type to FIGURE_CODE_REQUIRED and re-runs the writer on the figure.",
                        "Stops execution here. Reply with text to set a new direction; the agents will use it next iteration.",
                    ],
                    phase="violated_strategies",
                )
                self._asked_this_iteration = True
                # idx 2 = "Pause and wait for my guidance" — don't auto-fix.
                # idx 3 = Custom free-text slot — treat reply as user guidance.
                if idx == 2 or (reply and reply.strip() and idx == 3):
                    user_provided_fix = True
                elif reply is None:
                    self.telegram.send_async(
                        f"⏰ <b>{self.display_name}</b>: 15min timeout — auto-fixing "
                        f"{len(tech_violations)} violation(s), continuing.",
                        parse_mode="HTML",
                        polish=False,
                    )

            # Auto-fix technical violations if user didn't provide guidance
            if tech_violations and not user_provided_fix:
                self.log("Auto-fixing banned method violations for technical issues", "INFO")
                self.notify_progress(
                    "Auto-fix",
                    f"upgrading {len(tech_violations)} violation(s)",
                    level="warn",
                )
                for vid, vtype, banned, vdesc in tech_violations:
                    for issue in issues:
                        if issue.get("id") != vid:
                            continue
                        # Pick best non-banned upgrade type
                        if "EXPERIMENT_REQUIRED" not in banned:
                            upgrade_type = "EXPERIMENT_REQUIRED"
                            upgrade_agent = "experimenter"
                        elif "FIGURE_CODE_REQUIRED" not in banned:
                            upgrade_type = "FIGURE_CODE_REQUIRED"
                            upgrade_agent = "writer"
                        else:
                            upgrade_type = "EXPERIMENT_REQUIRED"
                            upgrade_agent = "experimenter"

                        old_type = issue["type"]
                        issue["type"] = upgrade_type
                        # Rewrite actions with correct agent
                        actions = issue.get("actions", [])
                        for action in actions:
                            action["agent"] = upgrade_agent
                        if not actions:
                            issue["actions"] = [{"agent": upgrade_agent, "task": issue.get("description", issue.get("title", ""))}]
                        v_desc = issue.get("title", "") or issue.get("description", "")
                        self.memory.record_repair_method({"id": vid, "title": v_desc}, upgrade_type)
                        self.log(f"  Auto-fixed {vid}: {old_type} -> {upgrade_type} (agent: {upgrade_agent})", "INFO")
                        break

                self._save_action_plan(action_plan)
                exp_count = sum(1 for i in issues if i.get("type") == "EXPERIMENT_REQUIRED")
                fig_count = sum(1 for i in issues if i.get("type") == "FIGURE_CODE_REQUIRED")
                write_count = sum(1 for i in issues if i.get("type") == "WRITING_ONLY")
                self.log_step(f"Plan after auto-fix: {len(issues)} issues (exp:{exp_count}, fig:{fig_count}, write:{write_count})", "success")

        return action_plan, planner_output

    def _run_execute_phase(self, action_plan: dict, planner_output: str = "") -> bool:
        """Execute the action plan: literature, experiments, writing."""
        issues = action_plan.get("issues", [])

        import threading
        from concurrent.futures import ThreadPoolExecutor, as_completed

        if not hasattr(self, '_action_plan_lock'):
            self._action_plan_lock = threading.Lock()

        def _run_literature_issue(issue):
            """Handle a literature issue by re-reading Deep Research report.

            Does NOT do independent keyword searches. All citations come from
            the Deep Research report (bootstrapped in Round 1). If reviewer
            asks for more literature, we re-extract from the same report and
            search API for any papers not yet in references.bib.
            """
            from ark.citation import (
                bootstrap_citations, append_papers_to_bib,
            )

            if self._quota_exhausted or shutting_down.is_set():
                return

            self.log_step(f"Literature: {issue.get('id')} - {issue.get('title', '')[:30]}", "progress")
            issue["status"] = "in_progress"
            with self._action_plan_lock:
                self._save_action_plan(action_plan)

            # Re-read Deep Research report and re-bootstrap any missing citations
            deep_research_file = self.state_dir / "deep_research.md"
            if deep_research_file.exists():
                self.log_step("  Re-reading Deep Research report for additional citations...", "progress")
                self._bootstrap_citations_from_deep_research()
            else:
                self.log_step("  No Deep Research report available, skipping", "warning")

            issue["status"] = "completed"
            with self._action_plan_lock:
                self._save_action_plan(action_plan)

        def _run_experiment_issue(issue):
            """Execute a single experiment issue."""
            if self._quota_exhausted or shutting_down.is_set():
                return
            self.log_step(f"Experiment: {issue.get('id')} - {issue.get('title', '')[:30]}", "progress")
            try:
                self._run_experiment_task(issue, action_plan)
            except Exception as e:
                self.log(f"Experiment task {issue.get('id')} failed: {e}", "ERROR")
                issue["status"] = "failed"
                issue["failure_reason"] = str(e)
                with self._action_plan_lock:
                    self._save_action_plan(action_plan)

        # Multi-round scheduler. An experiment issue can be reset to "pending"
        # from inside _run_experiment_task (e.g. when a human responds to an
        # intervention request). The old single-shot ThreadPoolExecutor would
        # leave that issue stranded because all futures were submitted up front
        # — this is exactly what stranded E5 on safeclaw-v2. Each round
        # re-scans the action plan and submits anything still pending.
        MAX_SCHEDULE_ROUNDS = 3
        for round_idx in range(1, MAX_SCHEDULE_ROUNDS + 1):
            if self._quota_exhausted:
                self.log_step("Quota exhausted, stopping schedule rounds", "warning")
                break

            lit_issues = [i for i in issues if i.get("type") == "LITERATURE_REQUIRED" and i.get("status", "pending") == "pending"]
            exp_issues_pending = [i for i in issues if i.get("type") == "EXPERIMENT_REQUIRED" and i.get("status", "pending") == "pending"]

            if not lit_issues and not exp_issues_pending:
                if round_idx > 1:
                    self.log_step(f"All issues drained after round {round_idx - 1}", "info")
                break

            if round_idx > 1:
                self.log_step(
                    f"Round {round_idx}/{MAX_SCHEDULE_ROUNDS}: "
                    f"{len(exp_issues_pending)} experiment(s) + {len(lit_issues)} literature still pending "
                    f"(likely reset by human intervention)",
                    "progress",
                )

            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = []
                if lit_issues:
                    self.log_step(f"Queueing {len(lit_issues)} literature tasks (parallel)", "progress")
                    for issue in lit_issues:
                        futures.append(executor.submit(_run_literature_issue, issue))
                if exp_issues_pending:
                    self.log_step(f"Queueing {len(exp_issues_pending)} experiment tasks (parallel)", "progress")
                    for issue in exp_issues_pending:
                        futures.append(executor.submit(_run_experiment_issue, issue))
                # Wait for all to complete
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception as e:
                        self.log(f"Parallel task error: {e}", "ERROR")

        # If we used up all rounds and issues are still pending, log it clearly.
        still_pending_exp = [i.get("id") for i in issues if i.get("type") == "EXPERIMENT_REQUIRED" and i.get("status", "pending") == "pending"]
        if still_pending_exp:
            self.log_step(
                f"{len(still_pending_exp)} experiment(s) still pending after {MAX_SCHEDULE_ROUNDS} rounds: {still_pending_exp}",
                "warning",
            )

        if self._quota_exhausted or getattr(self, "_terminal_error", None) or shutting_down.is_set():
            return False

        # Step 3: Run the writing phase, even if some experiments are
        # still pending or failed. Reasoning:
        #   - _run_writing_phase only emits writer tasks for EXPERIMENT_REQUIRED
        #     issues whose status == "completed" (see _run_writing_phase:900),
        #     so partial failure is already handled correctly.
        #   - WRITING_ONLY tasks (reviewer-driven revisions) are independent of
        #     experiment status and must still be applied.
        #   - The old early-return here fed a hardcoded "fallback writer" in
        #     pipeline.py with an impoverished prompt (no figure list, wrong
        #     venue) that silently deleted already-generated concept figures.
        #     Going through the real writing phase keeps the proper prompt.
        incomplete_exp = [
            i.get("id") for i in issues
            if i.get("type") == "EXPERIMENT_REQUIRED"
            and i.get("status", "pending") not in ("completed", "failed", "skipped")
        ]
        if incomplete_exp:
            self.log_step(
                f"Writing phase proceeding with {len(incomplete_exp)} experiment(s) still incomplete "
                f"({incomplete_exp}); only their review-driven writing tasks will run",
                "warning",
            )
        else:
            self.log_step("All experiments resolved, starting writing phase...", "progress")

        return self._run_writing_phase(action_plan, prior_context=planner_output)

    def _run_experiment_task(self, issue: dict, action_plan: dict):
        """Execute a single experiment issue. No retry loop — next iteration handles retries."""
        lock = getattr(self, '_action_plan_lock', None)
        issue["status"] = "in_progress"
        if lock:
            with lock:
                self._save_action_plan(action_plan)
        else:
            self._save_action_plan(action_plan)

        exp_task = issue.get("description", issue.get("title", "Unknown task"))
        actions = issue.get("actions", [])
        if actions:
            for action in actions:
                if action.get("agent") == "experimenter":
                    exp_task = action.get("task", exp_task)
                    break

        # 1. Setup compute
        compute_ctx = self._compute_backend.setup()
        
        # Determine remote working directory
        # Remote backends (e.g. SkyPilot) provide 'work_dir' in compute_ctx. Slurm/Local fallback to code_dir.
        remote_work_dir = compute_ctx.get("work_dir", str(self.code_dir))

        session_args = {}
        issue_id = issue.get("id")
        interrupted = issue_id in getattr(self, "_interrupted_review_experiments", set())
        if interrupted:
            # Multi-round scheduling may revisit this issue after a human reply.
            self._interrupted_review_experiments.discard(issue_id)
        if issue_id and issue.get("type") == "EXPERIMENT_REQUIRED" and selected_agent_runtime() == "dsh":
            digest = hashlib.sha256(str(issue_id).encode()).hexdigest()[:16]
            checkpoint = self.state_dir / f"review-experiment-{self.iteration}-{digest}.dsh-session"
            session_args["session_checkpoint"] = checkpoint
            if interrupted and checkpoint.is_file():
                session_args["interrupted_session"] = checkpoint.read_text().strip()
                session_args["resume_instructions"] = EXPERIMENT_RESUME_NOTE
        
        # Sync project code to backend
        self._compute_backend.sync_to_backend(str(self.code_dir), remote_work_dir)

        compute_instructions = self._compute_backend.get_agent_instructions()

        # Check for referenced file paths that don't exist
        file_existence_warning = ""
        path_pattern = re.compile(r'(?:references/|data/|experiments/|code/)[\w/.-]+')
        referenced_paths = path_pattern.findall(exp_task + " " + issue.get("description", ""))
        missing_paths = []
        for ref_path in set(referenced_paths):
            full_path = self.code_dir / ref_path
            if not full_path.exists():
                missing_paths.append(ref_path)
        if missing_paths:
            file_existence_warning = (
                "\n\n## WARNING: Referenced paths do not exist!\n"
                "The following paths mentioned in the task do NOT exist on disk:\n"
                + "\n".join(f"- {p} (NOT FOUND at {self.code_dir / p})" for p in missing_paths)
                + "\n\n**Do NOT fabricate synthetic data to substitute for missing real data.** "
                "Instead, report that the required data files are missing and skip "
                "any analysis that depends on them. Output a clear error message "
                "explaining what files are needed.\n"
            )
            self.log(f"WARNING: Experiment references missing paths: {missing_paths}", "WARN")

        # Gate B (pre-run): surface raw-log anomalies from prior runs so the
        # experimenter can address them before writing findings.yaml. This
        # catches silent failures like "LLM judge default-allowed on every
        # call" that otherwise slip into summary JSON unnoticed.
        prior_anomalies = raw_log_sanity(self.code_dir / "results")
        prior_anomaly_section = format_for_prompt(prior_anomalies)
        if prior_anomalies:
            block_count = sum(1 for a in prior_anomalies if a.severity == "block")
            self.log_step(
                f"raw-log sanity: {len(prior_anomalies)} anomalies in results/ "
                f"({block_count} blocking) — surfacing to experimenter",
                "warning" if block_count else "info",
            )

        sessions = []
        outcome = {}
        try:
            if interrupted and not self._compute_backend.sync_from_backend(
                f"{remote_work_dir}/results", str(self.code_dir / "results"),
            ):
                self._terminal_error = "Could not retrieve prior experiment results. Check the backend before resuming."
                return
            # 2. Experimenter runs the experiment (includes result analysis)
            exp_output = self.run_agent("experimenter", f"""
Task: {exp_task}

Issue context:
- ID: {issue.get('id')}
- Title: {issue.get('title')}
- Description: {issue.get('description', 'N/A')}
{file_existence_warning}
{compute_instructions}
{prior_anomaly_section}
{EXPERIMENT_RESUME_NOTE if interrupted else ""}

After running the experiment:
1. Check whether the experiment completed successfully (no OOM, no errors)
2. Check whether result files were generated
3. Evaluate whether the data supports the paper's arguments
4. Write auto_research/state/findings.json with your findings (JSON, not YAML —
   ARK converts it to findings.yaml; do NOT hand-write YAML)
""", timeout=defaults.TIMEOUT_EXPERIMENTER, session_out=sessions, outcome_out=outcome, **session_args)

            # 3. Wait for jobs
            self.log_step("Waiting for experiment completion...", "info")
            waited = time.time()
            jobs_complete = self._compute_backend.wait_for_completion(max_wait_hours=defaults.MAX_COMPUTE_WAIT_HOURS)

            # 4. Collect results
            results_synced = self._compute_backend.sync_from_backend(
                f"{remote_work_dir}/results", str(self.code_dir / "results"))
            collected = None
            if jobs_complete and results_synced:
                collected = collect_after_jobs(self, sessions, time.time() - waited, outcome_out=outcome)
            if collected is not None:
                exp_output = collected

        finally:
            self._compute_backend.teardown()

        # Interrupted by a Stop: its output is not a result. Filed "failed"
        # (empty output) or "completed" it would mislead the next planner,
        # and "completed" went on to generate figures during the stop.
        if shutting_down.is_set():
            issue["status"] = "pending"
            if lock:
                with lock:
                    self._save_action_plan(action_plan)
            else:
                self._save_action_plan(action_plan)
            self.log(f"Experiment {issue.get('id')} interrupted by the stop, left pending", "WARN")
            return

        # Gate B (post-run): re-scan results after the new run, validate
        # findings.yaml against the augmented schema (source / construct).
        # Everything is warn-level — we log but do not block the pipeline
        # while agents learn the new discipline.
        post_anomalies = raw_log_sanity(self.code_dir / "results")
        if post_anomalies:
            self.log_step(
                f"raw-log sanity (post-run): {len(post_anomalies)} anomalies "
                f"({sum(1 for a in post_anomalies if a.severity == 'block')} blocking)",
                "warning",
            )
            for a in post_anomalies:
                self.log(f"  [{a.severity}] {a.rule_id} @ {a.location}: {a.message}", "WARN")
        findings_path = getattr(self, "findings_file", None)
        if findings_path:
            # Prevention-at-source: the experimenter authors findings.json;
            # regenerate the canonical findings.yaml from it before validating.
            converted, sync_msgs = sync_findings_from_json(Path(findings_path).parent)
            for m in sync_msgs:
                self.log(f"findings sync: {m}", "INFO" if converted else "WARN")
            violations = validate_findings(Path(findings_path), project_root=self.code_dir)
            if violations:
                self.log_step(
                    f"findings.yaml validation: {len(violations)} issue(s) "
                    "(warn-only for now; see log)",
                    "warning",
                )
                rendered = format_violations_for_log(violations)
                if rendered:
                    self.log(rendered, "WARN")

        # 5. Guard against run_agent empty return (timeout / API failure / crash).
        #    Without this check, the fall-through at step 7 would happily mark the
        #    issue as "completed" even though experimenter produced zero output —
        #    this is the exact path that caused E3 on safeclaw-v2 to claim success
        #    after 2 hours of silence. Treat empty output as a hard failure; next
        #    review iteration's planner can decide whether to reschedule.
        incomplete = bool(sessions) and (
            not outcome.get("completed") or not jobs_complete or not results_synced
            or not self._experiment_evidence_files()
        )
        has_output = bool((exp_output or "").strip())
        human_responded = has_output and self._check_human_intervention(
            stage=f"Experiment {issue.get('id')}"
        )
        if not human_responded and (incomplete or not has_output):
            self.log_step(
                f"Experiment {issue.get('id')} did not complete with evidence",
                "error",
            )
            issue["status"] = "failed"
            issue["failure_reason"] = ("experimenter or backend did not complete with result evidence"
                                       if incomplete else "experimenter returned empty output")
            if lock:
                with lock:
                    self._save_action_plan(action_plan)
            else:
                self._save_action_plan(action_plan)
            return

        # 6. Check if experimenter requested human intervention
        if human_responded:
            self.log_step(f"Human responded for {issue.get('id')}, re-running experiment", "info")
            # Re-run the experiment with the user's input
            issue["status"] = "pending"
            if lock:
                with lock:
                    self._save_action_plan(action_plan)
            else:
                self._save_action_plan(action_plan)
            return  # Will be retried in next pass

        # 7. Mark done — reviewer in next iteration decides if more work needed
        issue["status"] = "completed"
        if lock:
            with lock:
                self._save_action_plan(action_plan)
        else:
            self._save_action_plan(action_plan)
        self.log_step(f"Issue {issue.get('id')} completed", "success")
        self._generate_figures_from_results()

    def _format_reviewer_context_block(self, task: dict) -> str:
        """Surface the reviewer's verbatim observation, fix, acceptance criterion,
        and priority justification to the writer agent. The planner is required
        (per planner.prompt Output Format) to lift these fields from the review.
        Without this, the writer only sees the planner's task summary and tends
        to fix the description rather than the underlying issue, which is the
        dominant cause of issues being re-flagged in the next iteration.
        """
        if not isinstance(task, dict):
            return ""

        observation = (task.get("reviewer_observation") or "").strip()
        fix = (task.get("reviewer_fix") or "").strip()
        criterion = (task.get("acceptance_criterion") or "").strip()
        justification = (task.get("priority_justification") or "").strip()
        prior_iter_id = task.get("prior_iter_id")
        prior_attempted = task.get("prior_attempted")

        if not any([observation, fix, criterion, justification, prior_iter_id]):
            return ""

        lines = ["\n## Reviewer Context (from latest review report)\n"]
        if observation:
            lines.append(f"### What the reviewer observed\n{observation}\n")
        if fix:
            lines.append(f"### Reviewer's suggested fix\n{fix}\n")
        if criterion:
            lines.append(
                "### Acceptance criterion (next iteration's reviewer will check this)\n"
                f"{criterion}\n"
            )
        if justification:
            lines.append(f"### Why this priority\n{justification}\n")
        if prior_iter_id:
            attempted_note = (
                "The previous writer DID attempt this last round and the fix did not satisfy the reviewer."
                if prior_attempted
                else "The previous writer did NOT attempt this last round."
            )
            lines.append(
                f"### Cross-iteration linkage\n"
                f"This continues prior issue **{prior_iter_id}**. {attempted_note} "
                f"Try a different approach if the prior approach failed.\n"
            )

        if criterion:
            lines.append(
                "### MANDATORY VERIFICATION (before marking the task done)\n"
                "After your edit, re-read the modified section and self-check: would the "
                "acceptance criterion above now pass when the reviewer reads the rendered PDF? "
                "If no, iterate on the edit. Do NOT stop at \"I touched the right paragraph\".\n"
            )

        return "".join(lines)

    def _get_page_constraint_warning(self) -> str:
        """Return a page constraint warning string for the writer."""
        venue_pages = self.config.get("venue_pages")
        if not venue_pages:
            return ""

        result = f"""
## PAGE LIMIT: {venue_pages} pages (body text only, excluding references and appendix)

After making all changes, you MUST verify the page count:
1. Ensure `\\clearpage` appears immediately before `\\bibliography{{...}}` so References starts on a fresh page
2. Compile with `pdflatex -interaction=nonstopmode main.tex` (run twice for stable layout)
3. Check the body page count (pages before the References section)
4. If over {venue_pages} pages: condense verbose text and move less essential PROSE/tables to `\\appendix` — but KEEP FIGURES IN THE BODY (never move a method/result/concept figure to the appendix just to save space)
5. If under {venue_pages} pages: you have room — do NOT pad with filler
6. Repeat compile-and-check until body pages = {venue_pages} or fewer
"""

        # Append overfull hbox warnings
        overfull = getattr(self, '_overfull_warnings', [])
        if overfull:
            significant = [w for w in overfull if self._parse_overfull_pt(w) > 3.0]
            if significant:
                result += "\n## LAYOUT WARNINGS (from LaTeX compilation)\n\n"
                result += "The following content overflows column/page margins. **You must fix these:**\n\n"
                for w in significant:
                    result += f"- `{w}`\n"
                result += "\n**Fix**: Wrap overflowing tables with `\\resizebox{\\linewidth}{!}{...}` or break long equations.\n"

        return result

    @staticmethod
    def _parse_overfull_pt(warning: str) -> float:
        """Extract the pt value from an Overfull hbox warning."""
        m = re.search(r'([\d.]+)pt', warning)
        return float(m.group(1)) if m else 0.0

    def _enforce_page_count(self, context: str = "post-writing") -> bool:
        """Check and enforce page count: not over limit, last page >= 90% filled.

        For a 6-page venue:
        - Over 6.1 pages → compression pass
        - Under 5.9 pages (last page < 90%) → expansion pass
        - Also ensures \\clearpage before \\bibliography

        Args:
            context: Where this check is called from (for logging)

        Returns:
            True if page count is acceptable, False if couldn't be fixed.
        """
        venue_pages = self.config.get("venue_pages")
        if not venue_pages or self._quota_exhausted:
            return True

        # Page-fitting strictness (per-project, set in the webapp):
        #   relaxed  — no adjustment; take the paper as written (cheapest).
        #   balanced — DEFAULT: keep the body within ~1 page of the limit. Expand
        #              if more than ~1 page short (so the last page has content),
        #              compress if over; accept within range, never block/fail;
        #              capped at a few passes.
        #   strict   — hard ceiling + 70% last-page fill (limit-0.15 for 2-col),
        #              up to 20 passes.
        # NOTE: 'relaxed' now means NO adjustment. The old [limit-1] floor that
        # used to be called 'relaxed' is now 'balanced'. Back-compat: old 'off'
        # configs map to the new 'relaxed' (both = no adjustment).
        layout_mode = (self.config.get("layout_mode") or "balanced").lower()
        if layout_mode == "off":
            layout_mode = "relaxed"
        if layout_mode not in ("relaxed", "balanced", "strict"):
            layout_mode = "balanced"
        if layout_mode == "relaxed":
            self.log(f"[{context}] Page fitting: relaxed — no page adjustment", "INFO")
            return True

        # Measure the layout the user will receive, including the body-end
        # marker and the separate endmatter page, before requesting an edit.
        self._ensure_clearpage_before_bibliography()
        self.compile_latex()
        page_count = getattr(self, '_body_page_count', 0)
        if not page_count:
            return True

        # 70% fill rule:
        # Last page must be at least 70% filled (30% whitespace allowed).
        # NEVER exceed the page limit — desk rejection is worse than a short last page.
        # Single-column: min = N - 0.3 (e.g., 6 → 5.7)
        # Double-column: min = N - 0.15 (half a page = one column)
        from ark.latex_geometry import get_geometry
        venue_format = self.config.get("venue_format", "")
        geo = get_geometry(venue_format, paper_dir=self.latex_dir) if venue_format else {}
        columns = geo.get("columns", 1)

        if columns >= 2:
            min_pages = venue_pages - 0.15  # double-column: right column 70% filled
        else:
            min_pages = venue_pages - 0.3   # single-column: last page 70% filled
        max_pages = venue_pages
        latex_dir = self.config.get("latex_dir", "paper")

        # Balanced: looser than strict's 70%-fill floor, but NOT "anything goes".
        # Require the body to reach within ~1 page of the limit so the last page
        # actually has content — no grossly under-filled papers (e.g. 5.5/8).
        # Strict enforces the tight 70%-fill floor; balanced tolerates up to one
        # full page short, and caps the passes (vs strict's 20).
        if layout_mode == "balanced":
            min_pages = max(venue_pages - 1.0, 0.0)
            MAX_PAGE_ATTEMPTS = 5
        else:  # strict
            # Hard limit of 20 attempts to prevent infinite loops.
            MAX_PAGE_ATTEMPTS = 20

        self.log(f"[{context}] Page check: {page_count:.1f} body pages "
                 f"(target: {min_pages:.2f}–{max_pages:.1f}, {columns}-col, "
                 f"{layout_mode} mode)", "INFO")

        # Loop until page count is in range.
        # Every 4 failed attempts, relax tolerance by 0.1 pages (both sides).
        attempt = 0
        tolerance_relaxations = 0
        cur_min = min_pages
        cur_max = max_pages
        history = []  # list of {"before", "after", "action"} for feedback to LLM

        chain = []  # later rounds continue the first round's session
        while attempt < MAX_PAGE_ATTEMPTS:
            in_range = cur_min <= page_count <= cur_max
            if in_range:
                if tolerance_relaxations > 0:
                    self.log(f"[{context}] Page count OK: {page_count:.1f}/{venue_pages} "
                             f"(accepted with relaxed tolerance after {attempt} attempts)", "INFO")
                else:
                    self.log(f"[{context}] Page count OK: {page_count:.1f}/{venue_pages}", "INFO")
                return True

            attempt += 1

            # Every 4 attempts, relax the MIN bound only. The venue page
            # limit is a hard ceiling — desk rejection is worse than a
            # sparse last page — so `cur_max` is never relaxed above
            # `max_pages`. This matches the docstring above and matches
            # page-adjustment skill's "Never exceed the venue page limit"
            # rule. Only the "last page ≥ 70% filled" convention gets
            # progressively looser to let under-target papers pass.
            if attempt > 0 and attempt % 4 == 0:
                tolerance_relaxations += 1
                cur_min = min_pages - tolerance_relaxations * 0.1
                # cur_max stays pinned at max_pages regardless of relaxation
                self.log(f"[{context}] Relaxing MIN tolerance (round {tolerance_relaxations}): "
                         f"new range {cur_min:.2f}–{cur_max:.1f} "
                         f"(max stays at hard ceiling {max_pages})", "WARN")
                # Re-check with relaxed tolerance before another agent call
                continue

            if self._quota_exhausted:
                # Balanced mode never fails the run over page count — accept and
                # move on. Strict mode escalates so the caller can handle it.
                if layout_mode == "balanced":
                    self.log(f"[{context}] Quota exhausted; balanced mode accepts "
                             f"{page_count:.1f}/{venue_pages} pages as-is", "WARN")
                    return True
                self.log(f"[{context}] Quota exhausted, cannot enforce page count "
                         f"({page_count:.1f}/{venue_pages} pages)", "ERROR")
                raise QuotaExhaustedError(page_count, venue_pages)

            # Build history block (shown from attempt 2 onward)
            if history:
                hist_lines = ["## Previous attempts in this loop"]
                for i, h in enumerate(history, 1):
                    delta = h["after"] - h["before"]
                    hist_lines.append(
                        f"{i}. {h['before']:.2f} → {h['after']:.2f} pages "
                        f"(asked to {h['action']}, actual delta {delta:+.2f})"
                    )
                hist_lines.append(
                    "Use these observations to calibrate your edit size — "
                    "if a previous attempt overshot, be gentler; if it had no "
                    "measurable effect, be more aggressive.\n"
                )
                hist_block = "\n".join(hist_lines) + "\n"
            else:
                hist_block = ""

            page_before = page_count
            gap = page_count - venue_pages  # positive=over, negative=under

            if page_count > cur_max:
                action = "compress"
                self.log(f"[{context}] Over limit ({page_count:.1f} > {cur_max:.1f}), compressing (attempt {attempt})...", "WARN")
                self.run_agent_chain(chain, "writer", f"""{hist_block}## PAGE ADJUSTMENT — compress (attempt {attempt})

Current: {page_count:.2f} body pages ({gap:+.2f} over limit, {columns}-column).
Target: {cur_min:.2f}–{venue_pages:.0f} body pages.

For a small overflow, first look for a result or motivation repeated across the
introduction, discussion and conclusion. Keep its clearest occurrence and edit
the redundant prose. Preserve the supporting table, citations and the limits
on the claim. Recompile before changing any other part of the paper.
Keep citations tied to verified primary records. Do not reintroduce removed, unconfirmed citations to fill space.
Refer to the page-adjustment and figure-integrity skills for strategies and constraints.
After changes, compile and verify. Ensure `\\clearpage` before `\\bibliography`.
""", timeout=defaults.TIMEOUT_PAGE_ADJUSTMENT)

            elif page_count < cur_min:
                action = "expand"
                self.log(f"[{context}] Under target ({page_count:.1f} < {cur_min:.2f}), expanding (attempt {attempt})...", "WARN")
                self.run_agent_chain(chain, "writer", f"""{hist_block}## PAGE ADJUSTMENT — expand (attempt {attempt})

Current: {page_count:.2f} body pages ({-gap:+.2f} short of target, {columns}-column).
Target: {cur_min:.2f}–{venue_pages:.0f} body pages.

Keep citations tied to verified primary records. Do not reintroduce removed, unconfirmed citations to fill space.
Refer to the page-adjustment and figure-integrity skills for strategies and constraints.
After changes, compile and verify. Ensure `\\clearpage` before `\\bibliography`.
""", timeout=defaults.TIMEOUT_PAGE_ADJUSTMENT)

            self._ensure_clearpage_before_bibliography()
            self.compile_latex()
            page_count = getattr(self, '_body_page_count', 0)
            history.append({"before": page_before, "after": page_count, "action": action})
            if not page_count:
                self.log(f"[{context}] Could not determine page count after {action}", "WARN")
                return True

            # Detect stalled progress: if page count didn't change at all, bail out
            # instead of looping fruitlessly.
            stall_count = sum(1 for h in history[-3:] if abs(h["after"] - h["before"]) < 0.01)
            if stall_count >= 3:
                if layout_mode == "balanced":
                    self.log(f"[{context}] Balanced mode: page count stalled at "
                             f"{page_count:.1f}/{venue_pages} — accepting as-is", "INFO")
                    return True
                self.log(f"[{context}] Page count stalled at {page_count:.1f} for 3 consecutive "
                         f"attempts — aborting page enforcement", "ERROR")
                return False

        # Exhausted max attempts. In balanced mode this is expected (a few
        # best-effort passes, then accept) — log it softly, not as an error.
        if layout_mode == "balanced":
            self.log(f"[{context}] Balanced mode: accepting {page_count:.1f}/{venue_pages} "
                     f"pages after {MAX_PAGE_ATTEMPTS} best-effort pass(es)", "INFO")
            return True
        self.log(f"[{context}] Page enforcement failed after {MAX_PAGE_ATTEMPTS} attempts "
                 f"({page_count:.1f}/{venue_pages} pages)", "ERROR")
        return False

    # LaTeX snippet that saves the current vertical position to the .aux file.
    # \pdfsavepos records the position at shipout; the deferred \write expands
    # \pdflastypos at that moment, giving the y-coordinate (in sp, from the
    # page bottom).  Must use \write (not \protected@write) so expansion
    # happens at shipout time, after \pdfsavepos has recorded the position.
    _ARK_BODY_END_MARKER = (
        r"\makeatletter\pdfsavepos"
        r"\write\@auxout{\string\gdef\string\arkBodyEndY{\the\pdflastypos}"
        r"\string\gdef\string\arkPageH{\number\pdfpageheight}"
        r"\string\gdef\string\arkBodyEndPage{\arabic{page}}}"
        r"\makeatother"
    )

    def _ensure_clearpage_before_bibliography(self):
        return ExecutionMixin.prepare_endmatter(self.latex_dir, self.log, venue=getattr(self, "config", {}).get("venue_format"))

    @staticmethod
    def prepare_endmatter(latex_dir, log, *, venue=None):
        """Pin canonical ACM layout:

            body
            [BODY_END_MARKER]
            \\clearpage
            \\section*{Acknowledgments}             ← endmatter, on the refs page
            ... Acknowledgments content ...
            \\bibliographystyle{...}
            \\bibliography{...}
            \\clearpage
            \\appendix
            ... appendix content ...
            \\end{document}

        This matches acmart's official sample-sigplan.tex (line 745-844),
        which puts the appendix *after* the bibliography, not before.
        Many writer agents emit the older
        body→appendix→bibliography order; this routine reorders the file
        in place so the rendered PDF matches the venue convention.

        Boilerplate sections (Acknowledgments, LLM Usage Statement, etc.)
        emitted between Conclusion and \\bibliography belong on the
        references page — *after* the body \\clearpage, *before*
        \\bibliography. Earlier versions of this routine left them in the
        body region, which silently consumed page-limit budget and pushed
        Conclusion / Limitations into a partial-fill last body page.
        We now extract the Acknowledgments block from the body and re-insert
        it as endmatter on the references-page side of the \\clearpage.

        The body-end \\pdfsavepos marker is placed at the body / refs
        boundary (immediately before the \\clearpage that precedes
        the Acknowledgments and \\bibliography), so page-count
        metrics derived from the marker exclude the Acknowledgments,
        the bibliography, and the appendix — matching venue page-limit
        conventions ("N pages excluding references and appendix").

        Idempotent: running this on an already-canonical file
        produces a byte-identical result.
        """
        import re as _re

        main_tex = latex_dir / "main.tex"
        if not main_tex.exists():
            return
        try:
            content = main_tex.read_text()
            if r'\bibliography{' not in content:
                return

            # Strip any previously-injected body-end markers so the
            # rebuild below uses a single canonical position.
            content = content.replace(ExecutionMixin._ARK_BODY_END_MARKER + '\n', '')
            content = content.replace(BODY_END_PDF_MARKER + '\n', '')

            # Locate the bibliography block. We treat
            # \bibliographystyle + \bibliography as a single contiguous
            # block — they always ship together.
            bib_match = _re.search(
                r'(?:\\bibliographystyle\{[^}]*\}\s*)?\\bibliography\{[^}]*\}',
                content,
            )
            if not bib_match:
                return
            bib_block = content[bib_match.start():bib_match.end()].strip()

            end_doc_pos = content.find(r'\end{document}')
            if end_doc_pos < 0:
                return

            # IEEEtran spells it \appendices and the appendix package uses an
            # environment. A bare find(r'\appendix') misses both, and 527e
            # lost its whole appendix: shape (c) below kept nothing after the
            # bibliography, so 602 lines became 233.
            appendix_m = _re.search(
                r'\\appendi(?:x|ces)\b|\\begin\{appendices\}', content)
            appendix_pos = appendix_m.start() if appendix_m else -1
            # Whatever follows the bibliography stays, appendix or not.
            after_bib = content[bib_match.end():end_doc_pos].strip()
            # A style declared after the bibliography prints nothing. Keep it
            # with its bibliography so it cannot acquire its own page break.
            trailing_style = _re.match(r"(?:\\clearpage\s*)*(\\bibliographystyle\{[^}]*\})\s*", after_bib)
            if trailing_style and r"\bibliographystyle" not in bib_block:
                bib_block = trailing_style[1] + "\n" + bib_block
                after_bib = after_bib[trailing_style.end():].lstrip()

            # Three input shapes to handle:
            #   (a) appendix BEFORE bib  → reorder to bib then appendix
            #   (b) appendix AFTER bib   → already canonical; just clean
            #       the surrounding clearpages and re-insert marker
            #   (c) no appendix          → body + bib, drop in marker
            if appendix_pos != -1 and appendix_pos < bib_match.start():
                appendix_block = content[appendix_pos:bib_match.start()]
                if after_bib and venue != "usenix":
                    appendix_block = appendix_block.rstrip() + "\n\n" + after_bib
                body_section = content[:appendix_pos]
                reordered = True
            else:
                appendix_block = after_bib
                body_section = content[:bib_match.start()]
                reordered = False

            tail = content[end_doc_pos:].rstrip()

            # Extract Acknowledgments (and any other boilerplate
            # endmatter sections — including legacy LLM Usage Statement)
            # from the body. They belong on the references-page side
            # of the \clearpage, not in the body.
            # Pattern: \section*{Acknowledgments} ... up to next
            # \section, \appendix, \bibliography, or \end{document}.
            ENDMATTER_TITLES = [
                r'(?:LLM|AI) (?:Usage|Use) Statement',
                r'Acknowledg(?:e?ments|ements)?',
            ]
            if venue == "icml":
                ENDMATTER_TITLES.append(r'Impact Statement')
            endmatter_pattern = _re.compile(
                r'\\(?:sub)?section\*?\{\s*(?:' + '|'.join(ENDMATTER_TITLES) + r')\s*\}'
                r'.*?'
                r'(?=\\(?:sub)?section\*?\{|\\appendix\b|\\appendices\b'
                r'|\\begin\{appendices\}|\\bibliography\b|\Z)',
                _re.DOTALL | _re.IGNORECASE,
            )
            endmatter_blocks = []
            # Run pattern on body_section (and appendix_block when (a))
            for m in endmatter_pattern.finditer(body_section):
                endmatter_blocks.append(m.group(0).rstrip())
            body_section = endmatter_pattern.sub('', body_section)
            if reordered and appendix_block:
                # case (a): writer put appendix between body and bib,
                # but boilerplate could be inside that range too.
                for m in endmatter_pattern.finditer(appendix_block):
                    endmatter_blocks.append(m.group(0).rstrip())
                appendix_block = endmatter_pattern.sub('', appendix_block)

            # REQUIRED Idea2Paper disclosure: the check is for the DISCLOSURE
            # TEXT itself, not merely "an Acknowledgments section exists" — a
            # writer once authored its own acknowledgments crediting our
            # internal stack ("supported by the OpenHands AI research
            # platform... OpenRouter... Claude Sonnet 4", project 472e4874),
            # which satisfied the old any-Acknowledgments guard and shipped
            # WITHOUT the required disclosure. Now: if an Acknowledgments
            # block exists but lacks the disclosure, append it INTO that
            # block; if none exists, insert the standard section. Idempotent
            # on the idea2paper.org marker. Endmatter sits past the body
            # \clearpage (zero body-page cost); wording is double-blind-safe.
            from ark.template_preprocess import ARK_ACK_TEXT
            if not any("idea2paper.org" in b for b in endmatter_blocks):
                ack_idx = next((i for i, b in enumerate(endmatter_blocks)
                                if _re.match(r'\\(?:sub)?section\*?\{(?:AI |LLM |Acknowledg)', b, _re.I)), None)
                if ack_idx is not None:
                    endmatter_blocks[ack_idx] = (
                        endmatter_blocks[ack_idx].rstrip() + "\n\n" + ARK_ACK_TEXT)
                    log("Appended Idea2Paper disclosure to the writer's "
                             "Acknowledgments (required text was missing)", "INFO")
                else:
                    endmatter_blocks.append(
                        "\\section*{Acknowledgments}\n" + ARK_ACK_TEXT)
                    log("Inserted Idea2Paper Acknowledgments (required "
                             "disclosure was missing)", "INFO")

            endmatter_text = "\n\n".join(b for b in endmatter_blocks if b.strip())

            # Strip stray \clearpage from the trailing edges of each
            # piece — we re-insert canonical separators below.
            if appendix_block:
                appendix_block = _re.sub(
                    r'^\s*\\clearpage\s*', '', appendix_block.lstrip()
                ).lstrip()
                appendix_block = _re.sub(
                    r'\\clearpage\s*$', '', appendix_block.rstrip()
                ).rstrip()
            if venue == "icml":
                # The stock ICML bibliography already typesets its own heading.
                if not _re.search(r"\\(?:renewcommand|def)\s*\{?\\bibsection\b", content):
                    body_section = _re.sub(
                        r"(?m)^\s*\\section\*\{References\}\s*(?:\\(?:clearpage|newpage)\s*)*\Z",
                        "", body_section,
                    ).rstrip()
                # Keep the author's title and prose while giving a stand-alone appendix
                # after the bibliography its venue counter and PDF destination.
                title = _re.match(r"\\section\*?\{((?:Reproducibility |Technical )?Appendix)\}", appendix_block, _re.I)
                if appendix_m is None and title and _re.sub(r"(?m)(?<!\\)%.*", "", appendix_block[title.end():]).strip():
                    appendix_block = r"\appendix" + "\n" + r"\section{" + title[1] + "}" + appendix_block[title.end():]
            # Removing a redundant heading can expose the writer's preceding page break.
            body_section = _re.sub(
                r'(?:\\(?:clearpage|newpage)\s*)+\Z', '', body_section.rstrip()
            ).rstrip()
            if endmatter_text:
                endmatter_text = _re.sub(
                    r'^\s*\\clearpage\s*', '', endmatter_text.lstrip()
                ).lstrip()
                endmatter_text = _re.sub(
                    r'\\clearpage\s*$', '', endmatter_text.rstrip()
                ).rstrip()

            # When a writer has put a break between an acknowledgment and
            # its disclosure, the short acknowledgment otherwise takes a
            # whole page. These boilerplate paragraphs precede references.
            endmatter_text = _re.sub(r"(?m)^[ \t]*\\(?:clearpage|newpage)[ \t]*$", "", endmatter_text).strip()

            # Reassemble in canonical order.
            parts = [
                body_section,
                "",
                BODY_END_PDF_MARKER,
                ExecutionMixin._ARK_BODY_END_MARKER,
                r"\clearpage",
            ]
            if endmatter_text:
                parts.extend(["", endmatter_text, ""])
            if venue == "usenix" and reordered:
                # Preserve a pre-reference Open Science appendix (Security track).
                parts.extend([appendix_block, "", bib_block, after_bib])
            else:
                parts.append(bib_block)
                if appendix_block:
                    parts.extend(["", r"\clearpage", appendix_block])
            if venue == "neurips" and appendix_pos != -1:
                checklist = _re.compile(r"(?m)^[ \t]*(\\input\{checklist(?:\.tex)?\})[ \t]*$")
                entries = list(checklist.finditer("\n".join(parts)))
                if len(entries) == 1:
                    parts = [checklist.sub("", part).rstrip() for part in parts]
                    parts.extend(["", entries[0][1]])
            parts.extend(["", tail, ""])
            new_content = "\n".join(parts)

            # A layout pass only moves text. If anything the paper defines
            # would vanish, the rewrite is wrong: keep the file as it is.
            lost = _structure_lost(content, new_content)
            if lost:
                log("Skipped end-matter reorder: it would have dropped "
                         + ", ".join(lost), "WARN")
                # This function is the only place a pipeline run inserts the
                # required Idea2Paper disclosure (`ensure_disclosure_in_tex`
                # otherwise runs only from `ark audit --repair`), so returning
                # here traded a soft layout violation for a hard missing-
                # disclosure one. Apply the disclosure on its own.
                try:
                    from ark.delivery_contract import ensure_disclosure_in_tex
                    if ensure_disclosure_in_tex(main_tex):
                        log("Inserted the required Idea2Paper disclosure "
                                 "without reordering", "INFO")
                except Exception as e:
                    log(f"Could not insert the Idea2Paper disclosure: {e}",
                             "ERROR")
                return

            if new_content != content:
                main_tex.write_text(new_content)
                if reordered and venue != "usenix":
                    log(
                        "Reordered: body → bibliography → appendix "
                        "(matches acmart sample-sigplan convention)",
                        "INFO",
                    )
                if endmatter_blocks:
                    titles = []
                    for b in endmatter_blocks:
                        m = _re.search(r'\\section\*?\{\s*([^}]+?)\s*\}', b)
                        if m:
                            titles.append(m.group(1))
                    log(
                        f"Moved endmatter ({', '.join(titles)}) onto refs "
                        f"page (after \\clearpage, before \\bibliography)",
                        "INFO",
                    )
        except Exception as e:
            log(f"Failed to inject \\clearpage: {e}", "WARN")

    @staticmethod
    def _first_pos(content: str, *needles: str) -> int:
        """Return the smallest non-negative index of any needle in content."""
        positions = [content.find(n) for n in needles]
        return min(p for p in positions if p >= 0)

    def _ensure_float_barrier(self):
        """Strip every body-region \\FloatBarrier from main.tex.

        Rationale: writer agents sometimes add \\FloatBarrier in the middle of
        the body (e.g. before an Analysis section). A stray barrier there
        traps column flow — pending floats (a following \\begin{table*}) block
        further text from entering the current page's right column, and the
        page ships half-empty.

        Earlier versions of this routine *also* injected one canonical
        \\FloatBarrier right before the last body section, on the theory that
        a single barrier in a stable spot was harmless. In practice it caused
        the opposite problem: with figure-dense papers (~6 figures + a table
        in 8 pages), the pre-Conclusion barrier flushes the entire pending
        float queue at once, clustering several figures onto two consecutive
        pages and pushing the Conclusion onto a 9th page — silently breaking
        the venue page limit. LaTeX's default float placement, plus the
        natural barrier at \\bibliography{}, handles paper layout fine
        without our help. We now only strip stray barriers and leave float
        placement to LaTeX.

        We also no longer touch \\usepackage{placeins}: with no injection of
        our own and writer-added \\FloatBarriers stripped, the package isn't
        needed.
        """
        main_tex = self.latex_dir / "main.tex"
        if not main_tex.exists():
            return
        try:
            import re as _re
            content = main_tex.read_text()

            # Find the body boundary — \appendix, \clearpage before \bibliography, or \bibliography
            body_end = len(content)
            for boundary in [r'\appendix', r'\clearpage', r'\bibliography{']:
                pos = content.find(boundary)
                if pos != -1 and pos < body_end:
                    body_end = pos

            body_content = content[:body_end]
            tail = content[body_end:]

            # Strip every existing \FloatBarrier (plus its trailing whitespace /
            # newline) from the body. Matching \\FloatBarrier not followed by a
            # letter keeps us from eating any hypothetical \FloatBarrierFoo.
            barrier_re = _re.compile(r'\\FloatBarrier(?![A-Za-z])\s*\n?')
            existing = barrier_re.findall(body_content)
            removed = len(existing)
            if not removed:
                return  # nothing to do; leave file untouched

            body_content = barrier_re.sub('', body_content)
            content = body_content + tail
            main_tex.write_text(content)

            if removed == 1:
                self.log(
                    "Stripped 1 writer-added \\FloatBarrier from body",
                    "INFO",
                )
            else:
                self.log(
                    f"Stripped {removed} writer-added \\FloatBarrier copies "
                    "from body",
                    "INFO",
                )
        except Exception as e:
            self.log(f"Failed to strip FloatBarrier: {e}", "WARN")

    def _fix_overfull(self, context: str = "pre-delivery"):
        """Fix overfull \\hbox warnings by asking writer to reword.

        Loops until 0 overfull warnings or max attempts.
        """
        MAX_ATTEMPTS = 3
        latex_dir = self.config.get("latex_dir", "paper")

        chain = []  # later rounds continue the first round's session
        for attempt in range(MAX_ATTEMPTS):
            # Parse overfull from log
            log_path = self.latex_dir / "main.log"
            if not log_path.exists():
                return

            log_text = log_path.read_text(errors="replace")
            import re as _re
            # LaTeX reports two kinds of overfull \hbox: "in paragraph at
            # lines" (prose running past the column) and "in alignment at
            # lines" (a tabular/array too wide for its column). The latter is
            # the one that makes a table spill past the margin — and rewording
            # prose can never fix it, so we must detect it separately and give
            # table-specific repair instructions.
            overfull_lines = _re.findall(
                r'Overfull \\hbox \(([0-9.]+)pt too wide\) in (paragraph|alignment) at lines (\d+)--(\d+)',
                log_text
            )
            # Only fix significant ones (>3pt)
            significant = [
                (float(pt), kind, int(l1), int(l2))
                for pt, kind, l1, l2 in overfull_lines if float(pt) > 3.0
            ]

            if not significant:
                if attempt > 0:
                    self.log(f"[{context}] All overfull warnings fixed (attempt {attempt})", "INFO")
                return

            if self._quota_exhausted:
                self.log(f"[{context}] {len(significant)} overfull warnings remain (quota exhausted)", "WARN")
                return

            has_table = any(kind == "alignment" for _, kind, _, _ in significant)
            self.log(f"[{context}] Fixing {len(significant)} overfull warnings (attempt {attempt + 1}/{MAX_ATTEMPTS}){' [includes table]' if has_table else ''}...", "WARN")

            overfull_desc = "\n".join(
                f"- Lines {l1}-{l2}: {pt:.1f}pt too wide ({'TABLE/tabular' if kind == 'alignment' else 'prose'})"
                for pt, kind, l1, l2 in significant[:10]
            )

            table_guidance = (
                """
For any line marked **TABLE/tabular** above, rewording prose will NOT help —
the table itself is wider than the column. Fix the table by (in order of
preference):
- Abbreviate long cell labels (e.g. "Standardized (StandardScaler)" → "Std." with a caption note; "Preprocessing" → "Prep.")
- Drop or merge a non-essential column (e.g. fold a yes/no column into a footnote symbol)
- Wrap the tabular in \\resizebox{\\columnwidth}{!}{ ... } so it scales to the column width
- Reduce the table font with \\footnotesize / \\scriptsize around the tabular
- Only if it genuinely needs the full text width, promote it to a two-column-spanning table* environment
Do NOT change any numeric values, drop data rows, or fabricate cells.
"""
                if has_table else ""
            )

            self.run_agent_chain(chain, "writer", f"""## FIX OVERFULL HBOX (attempt {attempt + 1})

The paper has {len(significant)} overfull \\hbox warnings (content extending past column margin):

{overfull_desc}

For **prose** lines, reword the sentence to allow LaTeX better line breaking:
- Shorten long compound words or phrases
- Add \\- hyphenation hints for technical terms
- Split long inline math or URLs
- Rephrase to use shorter synonyms
{table_guidance}
Do NOT change figures, template, or page structure.
After fixing, compile: cd {latex_dir} && pdflatex -interaction=nonstopmode main.tex
""", timeout=defaults.TIMEOUT_LATEX_COMPILE)

            self.compile_latex()

        # Final check
        remaining = len([1 for pt, _, _, _ in significant if float(pt) > 3.0]) if significant else 0
        if remaining:
            self.log(f"[{context}] {remaining} overfull warnings remain after {MAX_ATTEMPTS} attempts", "WARN")

    def _script_that_draws(self, fig_name: str) -> str:
        """The plotting script that mentions this figure, else the default one.

        A project may have more than one: dsh6's coder answered a figure task by
        writing `scripts/plot_n_iter_bar.py` beside `create_paper_figures.py`,
        and sending the coder at the wrong file wastes the attempt — its own
        rules tell it to stop when the target function is not there.
        """
        default = self.config.get("create_figures_script", "scripts/create_paper_figures.py")
        stem = Path(fig_name).stem
        try:
            for s in sorted((Path(self.code_dir) / "scripts").glob("*.py")):
                if stem in s.read_text(errors="replace"):
                    return f"scripts/{s.name}"
        except Exception:
            pass
        return default

    def _fix_illegible_figures(self, context: str = "pre-delivery") -> None:
        """One attempt at a figure whose own labels cannot be read.

        dsh8 delivered `fig_main_results` with the value label
        `1000  (hit max_iter=1000)` printed across the `10³` y-tick. Everything
        upstream worked: the overlap was found, Layer-1 tried and failed to fix
        it, and the escalation file was written — addressed to *"the next
        planner iteration"*, on a run with `--iterations 1`. Nothing read it,
        the contract reported the violation, and the paper shipped with it.

        So the last actor before delivery is here. One attempt: the coder knows
        which labels collide and which script draws them, the figures are
        regenerated and the paper recompiled. If the figure is still unreadable
        afterwards, say so and deliver anyway — the contract is observe-only and
        a second attempt on a model that just failed one is a worse use of the
        run than an honest log line.
        """
        from ark.figure_legibility import describe

        if getattr(self, "_quota_exhausted", False):
            return

        def _scan():
            """(illegible, unreadable) — per figure, never per scan.

            One figure PyMuPDF cannot open used to abort the comprehension and
            return, so a single bad file meant no figure got repaired and the
            log said only that "the check failed". A file we could not read is
            reported as exactly that, and the rest are still examined.
            """
            bad, unreadable = [], []
            for f in sorted(self.figures_dir.glob("*.pdf")):
                try:
                    what = describe(f)
                except Exception as e:
                    unreadable.append((f.name, f"could not be read: {e}"))
                    continue
                if what:
                    bad.append((f.name, what))
            return bad, unreadable

        broken, unreadable = _scan()
        for name, why in unreadable:
            self.log_step(f"[{context}] {name}: {why} — NOT checked for legibility",
                          "warning")
        if not broken:
            return

        self.log_step(f"[{context}] {len(broken)} figure(s) with unreadable labels — "
                      f"sending the coder once", "progress")
        tasks = []
        for i, (name, what) in enumerate(broken, 1):
            tasks.append({
                "id": f"FIGLEG{i}",
                "type": "FIGURE_CODE_REQUIRED",
                "title": f"{name}: labels are unreadable on the page",
                "description": (
                    f"{name} is drawn at its print size and its own labels are "
                    f"unreadable: {what}.\n\n"
                    f"Give the labels room. Shorten the text, raise the y-limit so a "
                    f"value label clears the data, rotate a crowded tick row "
                    f"(`rotation=30, ha=\"right\"`), thin decade ticks with "
                    f"`LogLocator(numticks=3)`, or widen the figure. Do not shrink the "
                    f"font below the template minimum, and do not change any plotted "
                    f"value — only the layout of the text."),
                "actions": [{"agent": "coder",
                             "target_file": self._script_that_draws(name),
                             "modification": what}],
            })
        if self._run_figure_code_tasks(tasks) is False:
            self.log_step(f"[{context}] quota exhausted during the figure repair — "
                          f"{len(broken)} figure(s) left unreadable", "warning")
            return

        still, unreadable = _scan()
        # "still unreadable" and "could not be re-checked" are the two things
        # this whole gate exists to tell apart, so they stay apart in the log.
        outstanding = {n for n, _ in still} | {n for n, _ in unreadable}
        fixed = len([n for n, _ in broken if n not in outstanding])
        parts = []
        if still:
            parts.append(f"{len(still)} still unreadable: "
                         + "; ".join(f"{n} ({w})" for n, w in still))
        if unreadable:
            parts.append(f"{len(unreadable)} could NOT be re-checked: "
                         + "; ".join(f"{n} ({w})" for n, w in unreadable))
        if parts:
            self.log_step(f"[{context}] {fixed} fixed, " + ", ".join(parts), "warning")
        else:
            self.log_step(f"[{context}] all {fixed} figure(s) now legible", "success")

    def _collect_writing_tasks(self, issues: list) -> list:
        """Writer tasks for this plan: WRITING_ONLY issues, plus one write-up
        per finished experiment or literature issue."""
        writing_tasks = []
        for issue in issues:
            if issue.get("type") == "WRITING_ONLY":
                writing_tasks.append({
                    "id": issue.get("id") or "?",
                    "title": issue.get("title") or "",
                    "description": issue.get("description") or "",
                    "actions": issue.get("actions") or [],
                })
                issue["status"] = "in_progress"
            elif issue.get("type") == "EXPERIMENT_REQUIRED" and issue.get("status") in ("completed", "failed"):
                actions = [a for a in (issue.get("actions") or [])
                           if isinstance(a, dict) and a.get("agent") == "writer"]
                # The planner's schema has no `actions` key, so in production
                # 0 of 143 issues carried one and no finished experiment ever
                # reached the paper. The integration task is the pipeline's
                # job, not something the planner has to remember to ask for.
                if not actions:
                    actions = [{"agent": "writer",
                                "task": _experiment_writeup_task(issue)}]
                for action in actions:
                    writing_tasks.append({
                        "id": issue.get("id"),
                        "title": f"Integrate experiment results for {issue.get('title')}",
                        "description": action.get("task", ""),
                        "actions": [action],
                        "_from_experiment": True,
                    })
            elif issue.get("type") == "LITERATURE_REQUIRED" and issue.get("status") == "completed":
                actions = [a for a in (issue.get("actions") or [])
                           if isinstance(a, dict) and a.get("agent") == "writer"]
                if not actions:
                    actions = [{"agent": "writer", "task": (
                        "The literature task for this issue is done; its notes are in "
                        f"`auto_research/state/literature.yaml`. Address the issue in the "
                        f"paper using only references that are in references.bib.\n\n"
                        f"Issue: {issue.get('description') or issue.get('title') or ''}")}]
                for action in actions:
                    writing_tasks.append({
                        "id": issue.get("id"),
                        "title": f"Update {issue.get('title')} based on literature survey",
                        "description": action.get("task", ""),
                        "actions": [action],
                    })
                    self.log(f"  Added literature writing task: {issue.get('id')} - write literature content into LaTeX", "INFO")
        return writing_tasks

    def _run_figure_code_tasks(self, figure_tasks: list, prior_context: str = "") -> bool:
        """Send the coder at the plotting scripts, then regenerate and recompile.

        Phase 1 of the writing phase, and also the pre-delivery gate for a
        figure whose labels are unreadable. It lives on its own because
        `_run_writing_phase` returns early when there is no prose to write,
        so the only way to run a figure task by itself was not to run it.
        """
        # Phase 1: FIGURE_CODE_REQUIRED tasks
        if figure_tasks:
            self.log_step(f"Processing {len(figure_tasks)} FIGURE_CODE_REQUIRED tasks (modifying Python code)", "progress")

            figure_instructions = []
            target_files_all: set[str] = set()
            for task in figure_tasks:
                task_id = task.get("id", "")
                task_title = task.get("title", "")
                task_desc = task.get("description", "")
                actions = task.get("actions", [])

                target_file = self.config.get("create_figures_script", "scripts/create_paper_figures.py")
                target_function = ""
                modification = task_desc

                for action in actions:
                    if "target_file" in action:
                        target_file = action["target_file"]
                    if "target_function" in action:
                        target_function = action["target_function"]
                    if "modification" in action:
                        modification = action["modification"]

                target_files_all.add(target_file)

                # Discover actual function names present in the target script so
                # writer doesn't have to guess. Hardcoding function names here
                # (as we used to) only works for one specific past project.
                available_functions = []
                try:
                    tf_path = Path(self.code_dir) / target_file
                    if tf_path.exists():
                        import re as _re
                        for m in _re.finditer(r"^def\s+(fig\w+)\s*\(", tf_path.read_text(), _re.M):
                            available_functions.append(m.group(1))
                except Exception:
                    pass
                fn_hint = (
                    "Functions defined in this script: " + ", ".join(available_functions)
                    if available_functions
                    else "Inspect the script to find the function that emits this figure."
                )

                figure_instructions.append(f"""
### {task_id}: {task_title}

**CRITICAL**: You must modify Python code, not LaTeX!

**Target file**: {target_file}
**Target function**: {target_function if target_function else "See task description"}
**Modification needed**: {modification}

**Detailed task**:
{task_desc}

**Action steps**:
1. Use the Read tool to read {target_file}
2. Locate the function that produces this figure. {fn_hint}
3. Use the Edit tool to modify matplotlib parameters (figsize, fontsize, tight_layout, etc.)
4. Confirm that the modified code has correct syntax
5. Do not run the script (the system will run it automatically)
""")

            # Load plot style guide
            _style_path = Path(__file__).parent / "templates" / "style_guides" / "academic_plot_style.md"
            _plot_style = _style_path.read_text() if _style_path.exists() else ""

            # Surface persistent user instructions directly to the coder.
            # The coder profile sets user_instructions=False, which means
            # user-supplied directives only reach the agent indirectly via
            # the planner's task description. In practice that's been
            # losing them: the planner correctly translates a user color
            # palette into per-figure modifications, but the academic
            # style guide below contains "MUST FOLLOW: Wong palette" and
            # the agent defers to that absolute-sounding rule, ignoring
            # the per-task override. Inject the user instructions at the
            # top of the prompt with an explicit precedence rule so the
            # agent has no ambiguity.
            _user_instructions = ""
            try:
                ui_file = self.state_dir / "user_instructions.yaml"
                if ui_file.exists():
                    import yaml as _yaml
                    data = _yaml.safe_load(ui_file.read_text()) or {}
                    msgs = [e.get("message", "").strip()
                            for e in (data.get("instructions") or [])
                            if e.get("message")]
                    if msgs:
                        _user_instructions = "\n".join(f"- {m}" for m in msgs)
            except Exception as e:
                self.log(f"Could not read user_instructions.yaml: {e}", "WARN")

            user_overrides_section = (
                f"""\n## ⚠️ USER OVERRIDES (highest priority, takes precedence over the style guide below)

The user has issued these explicit instructions for this project. They
are persistent — every iteration must continue to honour them. If any
of them conflicts with the Academic Plot Style Guide further down,
**follow the user instruction**, not the style guide. Do not silently
fall back to the guide's defaults.

{_user_instructions}
"""
                if _user_instructions
                else ""
            )

            before = _digests(self.code_dir, target_files_all)

            self.run_agent("coder", f"""
## Task: Modify existing Python plotting scripts

You received {len(figure_tasks)} FIGURE_CODE_REQUIRED tasks. Each task is
a *modification* to a function already present in the script — not a
request to invent a new figure from scratch and not a request to edit
LaTeX. The writer agent does LaTeX; you own the Python.
{user_overrides_section}
{''.join(figure_instructions)}

## Academic Plot Style Guide (background defaults — overridden by USER OVERRIDES above)

{_plot_style}

## Hard rules (violating any of these is worse than doing nothing)
- Only modify the target .py file. Do NOT edit main.tex, the bibliography,
  or anything outside `scripts/`.
- If the target function does not exist in the script, STOP. Report
  "target function X not found in Y" in your response and leave the
  file unchanged. Do NOT invent a new function or fabricate data.
- If the change you would need to make requires new data that isn't
  already in the script or in `results/`, STOP and report. Do NOT
  hardcode synthetic data.
- Do NOT run the script — the system re-runs it automatically after
  your edit.

## Follow-ups for the writer (optional, end of your response)
If your Python edit changes the figure's identity (e.g. you split a
panel into two subplots), the paper may need a caption / ref update
in main.tex. List those as a short "LaTeX follow-ups needed:" block
at the end of your response. DO NOT edit main.tex yourself — the
writer agent will pick those up in a later task.

## Tool usage
- Read each target .py file before editing it.
- Use Edit for small changes; Write only for complete rewrites of a
  single function body.
""", timeout=defaults.TIMEOUT_WRITER, prior_context=prior_context)

            if self._quota_exhausted or getattr(self, "_terminal_error", None):
                return False

            # Verify Python scripts were modified — across ALL target files,
            # not just the last one from the loop. Compare the files' own
            # contents: this used to ask `git diff --name-only`, which lists
            # tracked files only, and the pipeline tracks `auto_research/state/*`
            # and nothing else. `scripts/create_paper_figures.py` is untracked,
            # so the answer was always "not modified" — on dsh6 and dsh8 the
            # coder edited the script, compiled it and grepped the result, and
            # was told it had changed nothing.
            self.log_step("Verifying Python code changes...", "progress")
            try:
                after = _digests(self.code_dir, target_files_all)
                touched = sorted(p for p in target_files_all
                                 if before.get(p) != after.get(p))
                if touched:
                    self.log_step(f"Python code modified: {', '.join(touched)}", "success")
                else:
                    self.log_step("WARNING: FIGURE_CODE_REQUIRED task but Python not modified!", "error")
                    self.log(
                        f"Expected changes in one of: {sorted(target_files_all)}. "
                        f"Writer may have targeted the wrong file, or the existing "
                        f"code already satisfied the request.",
                        "WARN",
                    )
            except Exception as e:
                self.log(f"Verification failed: {e}", "WARN")

            # Regenerate figures (protect AI-generated files via manifest)
            self.log_step("Regenerating figures with modified code...", "progress")
            try:
                from ark.figure_manifest import (
                    load_manifest, backup_protected, restore_protected,
                )
                manifest = load_manifest(self.figures_dir)
                backups = backup_protected(self.figures_dir, manifest)

                # Every script the coder was sent at, not `target_file` — the
                # loop variable left over from the task loop above, i.e. the
                # last task's script. That was harmless while every task
                # defaulted to create_paper_figures.py; `_script_that_draws()`
                # now returns a different script per figure, so two illegible
                # figures drawn by two scripts meant one was edited and never
                # re-run, then reported as "still unreadable".
                ran, failures = [], []
                for tf in sorted(target_files_all):
                    r = subprocess.run(
                        ["python", tf],
                        capture_output=True, text=True, timeout=120,
                        cwd=self.code_dir
                    )
                    (ran if r.returncode == 0 else failures).append(
                        (tf, (r.stderr or "")[:200]))

                # Restore any AI-generated figures overwritten by the script
                restore_protected(self.figures_dir, backups, log_fn=self.log)

                for tf, err in failures:
                    self.log_step(f"Figure generation failed for {tf}: {err}", "error")

                if ran:
                    self.log_step(
                        f"Figures regenerated from {len(ran)}/{len(target_files_all)} "
                        f"script(s)", "success" if not failures else "warning")
                    # This is the last time anything touches the figures, and
                    # on a single-iteration run no reviewer sees them again.
                    # Say it in the live log rather than let it reach the PDF
                    # silently; the same note reaches the next agent through
                    # the Available Figures block.
                    from ark.figure_legibility import describe
                    for fig in sorted(self.figures_dir.glob("*.pdf")):
                        # Per figure: a file that cannot be opened must not
                        # silence the warning for the ones that can.
                        try:
                            what = describe(fig)
                        except Exception as e:
                            what = f"could not be read, so NOT checked: {e}"
                        if what:
                            self.log_step(f"{fig.name}: {what}", "warning")
                    self.compile_latex()
                else:
                    # Each failure was already named above with its stderr.
                    self.log_step(f"No figure script regenerated: all "
                                  f"{len(failures)} failed", "error")
            except Exception as e:
                self.log_step(f"Figure generation error: {e}", "error")
        # True = "the quota did not stop us", not "every figure came out right";
        # the caller's only decision is whether to spend the next writer call.
        return True

    def _run_writing_phase(self, action_plan: dict, prior_context: str = ""):
        """Execute writing phase for all writing tasks."""
        issues = action_plan.get("issues", [])
        issues = [i for i in issues if i is not None and isinstance(i, dict)]

        latex_dir_name = self.config.get("latex_dir", "paper")
        writing_tasks = self._collect_writing_tasks(issues)

        if not writing_tasks:
            self.log_step("No writing tasks to execute", "info")
            return True

        writing_tasks = [t for t in writing_tasks if t is not None]
        task_list = []
        for i, task in enumerate(writing_tasks, 1):
            task_list.append(f"""
### Task {i}: {task.get('id') or '?'} - {task.get('title') or ''}
{task.get('description') or ''}
""")

        # Classify: FIGURE_CODE_REQUIRED vs WRITING_ONLY
        figure_tasks = [i for i in issues if i.get("type") == "FIGURE_CODE_REQUIRED"]

        # Phase 0.5: Nano Banana concept figures (if enabled)
        if figure_tasks and self.config.get("figure_generation") == "nano_banana":
            concept_tasks = []
            matplotlib_tasks = []
            for task in figure_tasks:
                title = (task.get("title") or "").lower()
                desc = (task.get("description") or "").lower()
                is_concept = any(kw in title + " " + desc for kw in [
                    "concept", "architecture", "overview", "mechanism",
                    "illustration", "diagram", "workflow", "pipeline",
                ])
                if is_concept:
                    concept_tasks.append(task)
                else:
                    matplotlib_tasks.append(task)

            if concept_tasks:
                self.log_step(f"Routing {len(concept_tasks)} concept figure tasks to Nano Banana", "progress")
                n_generated = self._generate_nano_banana_figures()
                if n_generated > 0:
                    for task in concept_tasks:
                        task["status"] = "completed"
                else:
                    self.log("Concept figure generation produced 0 figures, tasks remain pending", "WARN")
                self._save_action_plan(action_plan)

            # Only keep matplotlib tasks for the standard figure code path
            figure_tasks = matplotlib_tasks

        # Phase 1: FIGURE_CODE_REQUIRED tasks. Its quota abort is this phase's
        # abort: extracting Phase 1 into the helper left the `return False`
        # inside it, so an exhausted quota logged "Aborting writing phase" and
        # then fell through to Phase 2 and spent another writer call anyway.
        if self._run_figure_code_tasks(figure_tasks, prior_context) is False:
            return False

        # Phase 2: Writing tasks (split by priority)
        high_priority_tasks = []
        batch_tasks = []

        for task in writing_tasks:
            if task is None:
                continue
            # Only experiment-derived tasks need individual calls (different context)
            if task.get("_from_experiment"):
                high_priority_tasks.append(task)
            else:
                batch_tasks.append(task)

        self.log_step(f"Writing tasks: {len(high_priority_tasks)} high-priority (individual), {len(batch_tasks)} batch", "progress")

        # Phase 2A: Individual high-priority tasks
        for task in high_priority_tasks:
            task_id = (task.get('id') or '?') if isinstance(task, dict) else '?'
            task_title = (task.get('title') or '') if isinstance(task, dict) else ''
            task_desc = (task.get('description') or '') if isinstance(task, dict) else ''
            self.log_step(f"Writing (individual): {task_id} - {task_title[:40]}", "progress")

            literature_context = self._get_literature_context_for_task(task)
            reviewer_context = self._format_reviewer_context_block(task)

            page_warning = self._get_page_constraint_warning()
            figure_list = self._list_available_figures()
            self.run_agent("writer", f"""
You have only one task to complete. Please complete it carefully and thoroughly.
{page_warning}
## Available Figures (DO NOT recreate AI concept figures)
{figure_list}

## Task: {task_id} - {task_title}
{task_desc}
{reviewer_context}
{literature_context}

## Requirements
1. Carefully read the relevant sections in {latex_dir_name}/main.tex
2. Make substantial modifications (not minor tweaks)
3. Ensure LaTeX syntax is correct after modifications
4. Keep the paper's core contributions unchanged
5. Reference the high-quality paper style in paper_example/ directory

## Reference Files
- auto_research/state/latest_review.md - Review report
- auto_research/state/literature.yaml - Literature survey results
- {latex_dir_name}/references.bib - References library
""", timeout=defaults.TIMEOUT_WRITER, prior_context=prior_context)

            if self._quota_exhausted:
                self.log("Aborting writing phase: API quota exhausted", "ERROR")
                return False

            # Verify changes
            try:
                diff_output = subprocess.run(
                    ["git", "diff", "--stat", f"{latex_dir_name}/main.tex"],
                    capture_output=True, text=True, cwd=self.code_dir
                ).stdout
                if diff_output.strip():
                    self.log_step(f"  ✓ {task_id}: changes detected", "success")
                else:
                    self.log_step(f"  ✗ {task_id}: No changes detected! Task may have failed.", "error")
            except Exception as e:
                self.log(f"  Verification error: {e}", "WARN")

        # Phase 2B: Batch normal tasks
        if batch_tasks:
            self.log_step(f"Processing {len(batch_tasks)} batch writing tasks", "progress")

            task_list = []
            for idx, task in enumerate(batch_tasks, 1):
                reviewer_block = self._format_reviewer_context_block(task)
                task_list.append(f"""
### Task {idx}: {task.get('id', '')} - {task.get('title', '')}
{task.get('description', '')}
{reviewer_block}
""")

            page_warning = self._get_page_constraint_warning()
            figure_list = self._list_available_figures()
            self.run_agent("writer", f"""
Please update the paper {latex_dir_name}/main.tex according to the following review revision tasks.
{page_warning}
## Available Figures (DO NOT recreate AI concept figures)
{figure_list}

## Revision Task List

{''.join(task_list)}

## Notes
1. Ensure LaTeX syntax is correct after each modification
2. Keep the paper's core contributions unchanged
3. Reference the high-quality paper style in paper_example/ directory
4. For multi-column templates: use `\\begin{{figure*}}` (full width) for complex figures, multi-panel plots, and architecture diagrams. Use `\\begin{{figure}}` (single column) only for simple single charts. Match `\\includegraphics[width=]` to the environment (\\textwidth vs \\columnwidth).

## Reference Files
- auto_research/state/latest_review.md - Review report
- auto_research/state/action_plan.yaml - Complete task list
""", timeout=defaults.TIMEOUT_WRITER, prior_context=prior_context)

        if self._quota_exhausted or getattr(self, "_terminal_error", None):
            return False

        # Verify total modifications
        total_added = 0
        try:
            diff_result = subprocess.run(
                ["git", "diff", "--numstat", f"{latex_dir_name}/main.tex"],
                capture_output=True, text=True, cwd=self.code_dir
            )
            if diff_result.stdout.strip():
                for line in diff_result.stdout.strip().split("\n"):
                    parts = line.split("\t")
                    if len(parts) >= 2 and parts[0].isdigit():
                        total_added += int(parts[0])

            if total_added < 5:
                self.log(f"Writing phase only added {total_added} lines, modifications may be insufficient", "WARN")
            else:
                self.log(f"Writing phase added {total_added} lines total", "INFO")
        except Exception as e:
            self.log(f"Writing quality verification failed: {e}", "WARN")

        self._report_dropped_figures(latex_dir_name)

        # Mark tasks completed if the writer actually changed the paper. A small
        # but real edit (e.g. a one-line title or number fix) is still meaningful
        # — only a completely empty diff (0 lines) counts as a failed writing pass.
        if total_added >= 1:
            for issue in issues:
                if issue.get("type") in ["WRITING_ONLY", "FIGURE_CODE_REQUIRED"]:
                    issue["status"] = "completed"
            self._save_action_plan(action_plan)
            self.log_step("Writing phase completed", "success")

            # Page count logged for awareness (hard enforcement is in post-validate)
            venue_pages = self.config.get("venue_pages")
            if venue_pages and not self._quota_exhausted:
                self.compile_latex()
                page_count = getattr(self, '_body_page_count', 0)
                if page_count:
                    self.log(f"Page count after writing: {page_count:.1f}/{venue_pages} body pages", "INFO")

            return True
        else:
            reason = "API quota exhausted" if self._quota_exhausted else f"only {total_added} lines added"
            self.log(f"Writing phase failed ({reason}), tasks NOT marked completed", "ERROR")
            self._save_action_plan(action_plan)
            return False

    def _report_dropped_figures(self, latex_dir_name: str) -> list:
        """Name any figure the writing pass removed from the paper.

        A writing pass is prose work; it has no reason to delete a figure the
        experiments produced. But it can, and until now nothing noticed. The
        surrounding accounting reads only the ADDED column of ``git diff
        --numstat``, so a pass that deletes a figure and writes two paragraphs
        reports "added 15 lines" and looks healthy — the compile still
        succeeds, the page count still fits, and the figure is simply gone.
        Observed live: a writer dropped an \\includegraphics for a concept
        figure and the PDF fell from 1.08 MB to 349 KB with no warning
        anywhere in the run.

        Compares removed against added targets so relocating a figure (which
        shows up as a delete plus an insert) stays silent. Reports rather than
        restores: an unexplained deletion is worth a human's attention, but
        re-inserting a figure into prose the writer has since rearranged is
        how you get a broken float or a duplicate.
        """
        pattern = re.compile(r"\\includegraphics\s*(?:\[[^\]]*\])?\s*\{([^}]+)\}")
        try:
            diff = subprocess.run(
                ["git", "diff", "-U0", "--", f"{latex_dir_name}/main.tex"],
                capture_output=True, text=True, cwd=self.code_dir, timeout=60,
            ).stdout
        except Exception as e:
            self.log(f"Figure-retention check skipped: {e}", "WARN")
            return []
        removed, added = set(), set()
        for line in diff.splitlines():
            if line.startswith("-") and not line.startswith("---"):
                removed.update(pattern.findall(line))
            elif line.startswith("+") and not line.startswith("+++"):
                added.update(pattern.findall(line))
        dropped = sorted(removed - added)
        if dropped:
            self.log(f"Writing phase REMOVED {len(dropped)} figure(s) from the "
                     f"paper: {', '.join(dropped)} — a prose pass should not "
                     f"drop figures; check the paper before delivery", "WARN")
        return dropped

    def _get_literature_context_for_task(self, task: dict) -> str:
        """Read literature.yaml and extract context relevant to the current task."""
        if not self.literature_file.exists():
            return ""

        try:
            lit_data = yaml.safe_load(self.literature_file.read_text()) or {}

            entries = lit_data.get("entries", [])
            if not entries:
                entries = lit_data.get("papers", [])
            if not entries:
                entries = lit_data.get("references", [])
            if not entries and isinstance(lit_data, list):
                entries = lit_data

            if not entries:
                for key, val in lit_data.items():
                    if isinstance(val, list) and len(val) > 0:
                        entries = val
                        break

            if not entries:
                return ""

            lines = ["\n## Available Literature Resources (from Literature Agent)\n"]
            for entry in entries[:20]:
                if isinstance(entry, dict):
                    title = entry.get("title", "")
                    bibtex_key = entry.get("bibtex_key", entry.get("key", entry.get("cite_key", "")))
                    abstract = entry.get("abstract", entry.get("summary", ""))
                    context = entry.get("context", "")
                    venue = entry.get("venue", "")
                    year = entry.get("year", "")
                    importance = entry.get("importance", "")
                    if title:
                        cite_str = f" (cite: \\cite{{{bibtex_key}}})" if bibtex_key else ""
                        venue_str = f" [{venue} {year}]" if venue else ""
                        imp_str = " **[MUST CITE]**" if importance == "critical" else ""
                        lines.append(f"- **{title}**{cite_str}{venue_str}{imp_str}")
                        if abstract:
                            lines.append(f"  Abstract: {abstract[:400]}")
                        elif context:
                            lines.append(f"  Context: {context[:400]}")
                elif isinstance(entry, str):
                    lines.append(f"- {entry}")

            # Add [NEEDS-CHECK] citations
            needs_check = lit_data.get("needs_check", [])
            if needs_check:
                lines.append("\n## [NEEDS-CHECK] Citations (unverified)")
                for nc in needs_check:
                    if isinstance(nc, dict):
                        nc_title = nc.get("title", "")
                        nc_key = nc.get("bibtex_key", "")
                        nc_importance = nc.get("importance", "")
                        nc_context = nc.get("context", "")
                        if nc_title and nc_key:
                            imp_str = " **[MUST CITE]**" if nc_importance == "critical" else ""
                            lines.append(f"- **{nc_title}** (cite: \\cite{{{nc_key}}}) [NEEDS-CHECK]{imp_str}")
                            if nc_context:
                                lines.append(f"  Context: {nc_context[:400]}")

            if len(lines) > 1:
                lines.append(f"\nPlease cite these references in Related Work and other appropriate sections.")
                lines.append(f"BibTeX entries are in {self.config.get('latex_dir', 'paper')}/references.bib, please use \\cite{{}} to cite.")
                lines.append(f"\nDo NOT remove existing \\cite{{}} commands. When revising, only add or modify — never delete existing citations.")
                lines.append(f"\n[NEEDS-CHECK] papers are treated as normal citations. Use them where appropriate based on content relevance.")
                return "\n".join(lines)
            return ""
        except Exception:
            return ""

    def _get_bottleneck(self) -> str:
        """Extract bottleneck dimension from latest_review.md score table.

        Parses the | Dimension | Score | table and returns the dimension
        with the lowest score. Falls back to 'Unknown' on parse failure.
        """
        if not self.latest_review_file.exists():
            return "Unknown"

        try:
            content = self.latest_review_file.read_text()
            # Parse score table rows: | Dimension | X.X/10 | ... |
            row_pattern = re.compile(
                r"\|\s*([^|*]+?)\s*\|\s*(\d+(?:\.\d+)?)\s*/\s*10\s*\|"
            )
            dimensions = []
            for match in row_pattern.finditer(content):
                dim_name = match.group(1).strip()
                score = float(match.group(2))
                # Skip header, total, and separator rows
                if dim_name.lower() in ("dimension", "total", "---", "--------"):
                    continue
                dimensions.append((dim_name, score))

            if dimensions:
                # Return the dimension with the lowest score
                bottleneck = min(dimensions, key=lambda x: x[1])
                return bottleneck[0]
        except Exception as e:
            self.log(f"Failed to extract bottleneck: {e}", "WARN")

        return "Unknown"

    def self_repair(self, stagnation_reason: str) -> bool:
        """Self-repair: re-plan strategy when stagnating.

        Includes meta-reflection check: if last repair was ineffective,
        escalate strategy instead of repeating.
        """
        self.log("Starting self-repair process...", "REPAIR")

        current_score = self.memory.scores[-1] if self.memory.scores else 0.0
        stagnation_count = self.memory.stagnation_count
        bottleneck = self._get_bottleneck()

        last_repair_effective, ineffective_reason = self.memory.was_last_repair_effective()
        repeat_issues = self.memory.get_repeat_issues(threshold=3)

        self.log(f"Bottleneck dimension: {bottleneck}", "REPAIR")
        if not last_repair_effective:
            self.log(f"Meta-reflection warning: last repair was ineffective - {ineffective_reason}", "REPAIR")
        if repeat_issues:
            self.log(f"Repeated Issues: {[r[0] for r in repeat_issues]}", "REPAIR")

        meta_reflection = ""
        if not last_repair_effective or repeat_issues:
            meta_reflection = f"""
### Meta-Reflection Warning - Must Change Approach!

**Last repair was ineffective**: {ineffective_reason}

**Recurring Issues** (these problems have been attempted multiple times but remain unresolved):
"""
            for issue_id, count in repeat_issues:
                meta_reflection += f"- **{issue_id}**: appeared {count} times\n"

            meta_reflection += """
**Mandatory Requirements**:
1. Do not use the same repair method as before
2. Analyze why previous repairs were ineffective
3. Adopt a completely different strategy:
   - If previously editing text -> now run experiments
   - If previously adjusting formatting -> now modify Python code to regenerate figures
   - If figure issues keep recurring -> must use FIGURE_CODE_REQUIRED (modify plotting scripts and re-run)
"""

        repair_prompt = f"""
## Self-Repair Mode - Bottleneck Breakthrough

**Stagnation reason**: {stagnation_reason}
**Current score**: {current_score}/10
**Target score**: {self.paper_accept_threshold}/10
**Consecutive stagnation count**: {stagnation_count}
**Bottleneck dimension**: {bottleneck}
{meta_reflection}

### Bottleneck Analysis

Determine repair strategy based on bottleneck dimension:

| Bottleneck | Strategy |
|------|------|
| Technical Quality | **Must add experiment tasks** (pure writing cannot break through) |
| Presentation | Focus on improving figures (use FIGURE_CODE_REQUIRED) |
| Innovation | Re-frame contribution |
| Writing Quality | Rewrite key sections |

### Required Steps

1. Read auto_research/state/action_plan.yaml, analyze current task structure
2. Read auto_research/state/latest_review.md, understand the reviewer's specific suggestions
3. Check repeated Issues, analyze why previous repairs were ineffective

### Mandatory Requirements

- If bottleneck is **Technical Quality** and < 7.5:
  - Must add EXPERIMENT_REQUIRED tasks

- If bottleneck is **Presentation** or figure-related Issues keep recurring:
  - Must use FIGURE_CODE_REQUIRED (not WRITING_ONLY!)
  - Must modify {self.config.get("create_figures_script", "scripts/create_paper_figures.py")}
  - Must run scripts to regenerate figures

- If all tasks are WRITING_ONLY:
  - This is a danger sign, must add experiment or FIGURE_CODE tasks

**Important**: This is an automatically triggered repair process; you need to make autonomous decisions, do not wait for human instructions.

**Output**: Update auto_research/state/action_plan.yaml, ensure there are breakthrough tasks targeting the {bottleneck} bottleneck.
"""

        self.run_agent("planner", repair_prompt)

        self.memory.mark_repair_attempt(self.iteration)

        if last_repair_effective:
            self.memory.stagnation_count = max(0, stagnation_count - 3)
            self.log(f"Repair effective, stagnation count reduced by 3: {stagnation_count} -> {self.memory.stagnation_count}", "REPAIR")
        else:
            self.log(f"Last repair was ineffective, stagnation count unchanged: {stagnation_count}", "REPAIR")

        self.memory.save()

        self.log("Self-repair completed", "REPAIR")
        return True
