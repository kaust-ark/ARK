---
name: figure-integrity
description: Rules for maintaining figure and table data integrity. All visual data must trace to result files — never invented or modified for convenience.
tags: [writing, figures, tables, data-integrity, latex]
---

# Figure and Table Integrity

## Core Rule

Every number displayed in a figure or table must be traceable to a file in `results/` or `data/`. If the source file doesn't exist, the figure should not exist either.

## When Creating or Updating Figures

1. **Read the source data first.** Before writing any plotting script, read the actual result file (`results/*.json`, `results/*.csv`) and extract the exact values. Do NOT hardcode numbers from memory or from the paper text.
2. **Load data from files, not literals.** Plotting scripts must `json.load()` or `pandas.read_csv()` from the result file. Acceptable:
   ```python
   with open("results/exp3_repair_n100.json") as f:
       data = json.load(f)
   drr = data["mean_drr"]
   ```
   Not acceptable:
   ```python
   drr = 0.942  # from the paper
   ```
3. **Handle missing data honestly.** If a result file doesn't exist or is incomplete:
   - Leave the figure cell/bar/point blank or mark it "N/A"
   - Add a `% TODO` comment in the LaTeX caption
   - Do NOT invent a plausible value

## Where Figures Belong (Initial Placement)

This applies when you *first write* the paper, not only during page adjustment.

- **AI concept figures (PaperBanana / Nano-Banana: overview, method, mechanism
  schematics) belong in the BODY**, next to where the concept is introduced
  (Introduction or Method) — never in `\appendix`. They illustrate the core
  contribution; that is why they were generated.
- **Do not create an `\appendix` solely to hold figures.** An appendix is for
  supporting *text* (proofs, full tables, prompt templates, hyperparameter
  grids, extra qualitative samples beyond the main results) — not for the
  paper's main figures.
- This holds **regardless of page count**. Even when the body is well under
  the page limit (e.g. a short paper using 1.6 of 2 allowed pages), a concept
  figure still goes in the body — being short is not a reason to appendix it.
- A concept figure whose `\includegraphics` sits after `\appendix` is a
  placement bug. Move it into the body.

## When the Paper Text Cites a Figure

The flow is always: **experiment → result file → figure → paper text**. Never the reverse.

- If the paper says "F1=0.891 (Figure 4)" — verify that Figure 4's plotting script reads a file that contains 0.891.
- If the paper text and the figure disagree, the result file is the authority. Fix whichever is wrong.

## During Page Adjustment

Figures and tables are **protected zones** during page compression or expansion:

- You may **resize** a figure (change `width`/`height` in `\includegraphics`)
- You may **move** a figure to a different position **within the body**
- **Keep figures in the body. Do NOT move a method / result / concept figure to
  the appendix to meet the page limit.** A figure that illustrates the work earns
  its place in the main text — banishing it to the appendix to save space defeats
  the reason it was generated. To save space, condense PROSE or move detailed
  *text*/tables to the appendix instead; under "relaxed" page-fitting, tolerating
  a slightly short/over last page is preferable to appendixing a figure. Only
  genuinely *supplementary* figures (extra qualitative examples beyond the main
  results) may live in the appendix.
- You may **change float placement** (`[t]`, `[!htbp]`, `[p]`)
- You must NOT **change the data** shown in the figure
- You must NOT **regenerate the figure with different values**
- You must NOT **remove data points, bars, or table rows** to make it smaller

## Labels Must Not Overprint

A figure saved at its intended print size is roughly **3.3 inches wide** in a
two-column template. matplotlib will happily draw labels on top of one another
at that width and report no error, so the script has to leave them room. A
real paper shipped two charts whose x-axis read `RaStandardized` and
`PlannAdtualActual max_iter max_iter` — both were the right size, inserted at
natural width, and traced to the data. They were simply unreadable.

When writing or regenerating a plotting script:

- Inspect the saved PDF at its intended print size, including both ends of
  every rotated axis title. A chart can have zero pairwise text overlaps
  while part of a title lies outside the canvas. Shorten the title or give
  it more height, then render the saved file again.

- **Count the characters before you choose a figsize.** Category labels on a
  shared axis need about 0.09 in per character at 9 pt. Three labels of
  "Actual max_iter (scaled)" will not fit across 3.3 in — the script must
  shorten them, rotate them, or ask for a wider figure.
- **Prefer shorter text to smaller fonts.** `Raw` / `Scaled` beats
  `Actual max_iter (raw)` / `Actual max_iter (scaled)` at 6 pt; never go below
  the template's minimum font size to make words fit.
- **Rotate rather than shrink** when the text genuinely cannot be shortened:
  `plt.xticks(rotation=30, ha="right")`.
- **Give a wide chart the full page**: set `placement` to `full_width` and use
  `\begin{figure*}` instead of squeezing it into one column.
- **Use `constrained_layout=True`** (or call `fig.tight_layout()`) so axis
  titles and value labels are not clipped at the figure edge.
- **Value labels need headroom.** A bar annotated at its own top is clipped by
  the axes; raise the y-limit or place the label inside the bar.
- On a log axis, consecutive decade ticks (`10⁰`, `10²`) collide on a narrow
  panel. Thin them with `ax.xaxis.set_major_locator(LogLocator(numticks=3))`.

This is checked automatically: `figures_legible` in the delivery contract
measures the overlap of the figure's own text boxes, and the
`## Available Figures` block in your task marks any figure whose labels
overprint. A figure flagged there must be regenerated, not resized in LaTeX.

## After Any Figure Modification

1. **Spot-check values.** Pick 2-3 numbers from the figure and verify them against the source file.
2. **Check captions.** If the figure was moved or its context changed, update the caption to remain accurate.
3. **Check references.** Ensure all `\ref{fig:...}` in the text still point to the correct figure.

## Common Mistakes to Avoid

- Regenerating a plotting script from scratch using numbers "remembered" from the paper text, when the original script loaded from a result file
- Changing figure data during page compression to make the figure smaller
- Copying a figure caption's numbers into a new version of the figure without reading the actual data
- Creating a figure for an experiment that was blocked or incomplete — an honest "not evaluated" note is better than a fabricated chart
