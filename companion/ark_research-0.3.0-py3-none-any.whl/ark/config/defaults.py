# ark/config/defaults.py

# Phase and Step Timeouts (seconds)
TIMEOUT_RESEARCHER = 600
TIMEOUT_REVIEWER = 2400
TIMEOUT_PLANNER = 1200
TIMEOUT_WRITER = 3600
TIMEOUT_CODER = 3600
TIMEOUT_EXPERIMENTER = 7200
TIMEOUT_INITIALIZER = 1200

# Task-specific Agent Timeouts
TIMEOUT_PAGE_ADJUSTMENT = 1800
TIMEOUT_SCORE_RETRY = 600
# Citation extraction reads the full Deep Research report (often 25+ sources)
# and lists every cited paper — a non-trivial read+extract. 300s proved too
# tight for slower OpenRouter models (MiniMax M3 hit the 300s wall-clock with
# an empty result). 600s gives headroom while still bounding a genuine hang.
TIMEOUT_CITATIONS_EXTRACT = 600
# Per-agent prompt specialization: a one-shot ~300-word generation. 300s was
# borrowed from CITATIONS_EXTRACT and proved too tight for slower OpenRouter
# models (MiniMax M3 specialization calls ran 184-288s — one tipped over 300s
# and was killed mid-generation, yielding an empty result). 600s gives ample
# headroom while still bounding a genuine hang.
TIMEOUT_AGENT_SPECIALIZE = 600
TIMEOUT_LIT_REVIEW = 1200
TIMEOUT_DEEP_RESEARCH_POLL = 1200
TIMEOUT_NANO_BANANA_PLAN = 600

# Human-in-the-Loop Timeouts
# Every HITL decision auto-continues (with its default) once this elapses — no
# prompt may block the run waiting on the user. 10 minutes by default.
TIMEOUT_HITL_DECISION = 600  # 10 minutes
TIMEOUT_TELEGRAM_ASK = 1800  # 30 minutes

# LaTeX and Compilation
TIMEOUT_LATEX_COMPILE = 600
MAX_COMPILE_RETRIES = 5

# Compute
MAX_COMPUTE_WAIT_HOURS = 2.0
MAX_SLURM_WAIT_HOURS = 4.0
MAX_LOG_FILES_TO_KEEP = 5
STAGNATION_THRESHOLD_WARNING = 3
STAGNATION_THRESHOLD_REPAIR = 5

# Thresholds
DEFAULT_PAPER_ACCEPT_THRESHOLD = 8
STAGNATION_PROGRESS_FLOOR = 0.3

# HITL and User Interaction
DEFAULT_USER_DECISION_TIMEOUT = 1800  # 30 minutes
DEFAULT_QUOTA_WAIT_TIME = 1800        # 30 minutes

# Constants
PROJECT_STATE_SUBDIR = "auto_research/state"
PROJECT_LOG_SUBDIR = "auto_research/logs"
