"""CompilerMixin: LaTeX compilation, figure generation, PDF-to-image conversion."""

from collections import Counter
import json
import os
import re
import subprocess
import sys
import yaml
from pathlib import Path
from typing import NamedTuple
from ark.latex import utils as latex_utils
# The one citation-command regex + key extractors (ark.citation is stdlib-only,
# so this top-level import cannot cycle). Every "which keys are cited?" question
# in this module goes through these — divergent copies silently delete valid
# references; see CITE_CMD_RE's docstring.
from ark.citation import CITE_CMD_RE, NOCITE_ALL, active_tex_sources, cited_keys_in_dir
from ark.template_preprocess import find_matching_brace


GEMINI_IMAGE_ASPECT_RATIOS = frozenset({
    "1:1", "1:4", "1:8", "2:3", "3:2", "3:4", "4:1",
    "4:3", "4:5", "5:4", "8:1", "9:16", "16:9", "21:9",
})


class BodyFigure(NamedTuple):
    label: str
    asset: str
    location: str
    caption: str
    caption_location: str


def body_sections_and_figures(root, sources):
    """Track source lines in input order, stopping at the first appendix."""
    main = root / "main.tex"
    events = re.compile(
        r"\\begin\{(?P<literal>verbatim\*?|lstlisting|minted|comment)\}.*?\\end\{(?P=literal)\}"
        r"|\\(?:input|include|subfile)\s*\{(?P<input>[^{}]+)\}"
        r"|(?P<appendix>\\appendix\b|\\begin\{appendices\})|(?P<end>\\end\{document\})"
        r"|\\section\s*(?:\[[^\]]*\]\s*)?\{(?P<heading>[^{}\\%]{1,160})\}"
        r"|\\begin\{(?P<float>figure\*?)\}(?P<body>.*?)\\end\{(?P=float)\}", re.S)
    plain_figure = re.compile(
        r"\s*(?:\[[^\]]*\]\s*)?(?:\\centering\s*)?(?P<graphic>\\includegraphics)"
        r"\s*(?:\[(?P<options>[^\]]*)\]\s*)?\{(?P<asset>[^{}\\]+)\}\s*"
        r"\\caption\s*(?:\[[^\]]*\]\s*)?\{")

    def walk(path, ancestors):
        source = sources[path]
        start = re.search(r"\\begin\{document\}", source)
        for event in events.finditer(source, start.end() if start else 0):
            if event["end"]:
                break
            if event["input"]:
                rel = Path(event["input"])
                if not rel.suffix:
                    rel = rel.with_suffix(".tex")
                child = (root / rel).resolve()
                if child not in sources:
                    child = (path.parent / rel).resolve()
                if child in sources and child not in ancestors:
                    yield from walk(child, ancestors | {child})
            else:
                yield path, source, event

    headings, figures = [], []
    last_heading = None
    for path, source, event in walk(main, {main}):
        if event["appendix"]:
            break
        location = path.relative_to(root)
        if event["heading"]:
            line = source.count("\n", 0, event.start()) + 1
            title = " ".join(event["heading"].split())
            # An intervening label belongs to the heading, never to a paragraph.
            empty = (last_heading is not None and last_heading[0] == path and
                     re.fullmatch(r"(?:\s|\\label\s*\{[^{}]*\})*", source[last_heading[1]:event.start()]) is not None)
            headings.append((title, f"{location}:{line}", empty))
            last_heading = path, event.end()
        if not event["float"]:
            continue
        body = event["body"]
        graphic = plain_figure.match(body)
        if not graphic:
            continue
        options = {opt.split("=")[0].strip() for opt in (graphic["options"] or "").split(",") if opt.strip()}
        if options - {"width", "height", "totalheight", "scale", "keepaspectratio"}:
            continue
        end = find_matching_brace(body, graphic.end() - 1)
        label = re.fullmatch(r"\s*\\label\s*\{([^{}]+)\}\s*", body[end + 1:]) if end else None
        if label:
            offset = event.start("body") + graphic.start("graphic")
            line = source.count("\n", 0, offset) + 1
            caption_line = source.count("\n", 0, event.start("body") + graphic.end() - 1) + 1
            figures.append(BodyFigure(label[1], graphic["asset"], f"{location}:{line}",
                                      body[graphic.end():end], f"{location}:{caption_line}"))
    return headings, figures


def rendered_body_images(doc, figures, sources, root):
    """Match plain labelled floats to their printed caption and adjacent raster."""
    labels = {}
    label_pattern = re.compile(r"\\newlabel\{([^{}]+)\}\{\{(\d+)\}\{(\d+)\}")
    pending = [root / "main.aux"]
    active_aux = {path.with_suffix(".aux") for path in sources}
    while pending:
        aux = pending.pop()
        if aux not in active_aux or aux.is_symlink() or not aux.is_file():
            continue
        active_aux.remove(aux)
        content = aux.read_text(errors="replace")
        pending.extend((root / name).resolve() for name in re.findall(r"\\@input\{([^{}]+\.aux)\}", content))
        for key, number, page in label_pattern.findall(content):
            labels[key] = (number, int(page))
    for figure in figures:
        number, page_no = labels.get(figure.label, ("", 0))
        if not 1 <= page_no <= len(doc):
            continue
        page = doc[page_no - 1]
        captions = [b for b in page.get_text("blocks", flags=0)
                    if re.match(rf"^\s*(?:Figure|Fig\.)\s+{number}[.:]\s", b[4], re.I)]
        if len(captions) != 1:
            continue
        left, top, right = captions[0][:3]
        adjacent = [im["digest"] for im in page.get_image_info(hashes=True)
                    if 0 <= top - im["bbox"][3] < 30
                    and left <= (im["bbox"][0] + im["bbox"][2]) / 2 <= right]
        if len(adjacent) == 1:
            yield figure, number, page_no, captions[0][4], adjacent[0]


def _repeated_figure_notes(doc, figures, sources, root):
    images = {}
    for figure, number, page_no, _, pixels in rendered_body_images(doc, figures, sources, root):
        images.setdefault((figure.asset, pixels), {})[number] = (
            f"Figure {number} (p. {page_no}, {figure.location}, {figure.asset})")
    notes = []
    for matches in images.values():
        if len(matches) > 1:
            where = ", ".join(matches.values())
            notes.append(f"The same whole image appears in {where}. "
                         "Keep one figure and reference it from the other passage.")
    return notes


def repeated_result_series(doc, *, verified_tables=()):
    """Locate repeated prose series. With verified tables, require eight values from one table."""
    decimal = re.compile(r"(?<![\w.])-?\d+\.\d+(?!\w|\.\d)")
    tables = [set(decimal.findall(t["rendered_table"])) for t in verified_tables]
    length = 8 if tables else 6
    boundary = latex_utils.body_page_boundary(doc)
    last_page = boundary[0] if boundary else len(doc)
    seen = {}
    notes = []
    for page_number in range(last_page):
        for block in doc[page_number].get_text("blocks", flags=0):
            text = " ".join(block[4].split()).replace("−", "-")
            if re.match(r"(?:Fig(?:ure)?\.?|Table)\s+\d", text, re.I) or len(re.findall(r"\b[a-zA-Z]{3,}\b", text)) < 20:
                continue
            values = decimal.findall(text)
            # Short endpoint comparisons belong in both the abstract and results.
            windows = [tuple(values[i:i + length]) for i in range(len(values) - length + 1)]
            windows = [w for w in windows if len(set(w)) == length and
                       (not tables or any(table.issuperset(w) for table in tables))]
            match = next((w for w in windows if w in seen), None)
            if match:
                location = f"Body paragraphs on PDF pages {seen[match]} and {page_number + 1}"
                table_note = " These values also appear in the verified worker table." if tables else ""
                notes.append(f"{location} repeat the numerical series beginning {', '.join(match[:3])}.{table_note} "
                             "Keep the condition-level values in one place; use the other paragraph for "
                             "a contrast, an explanation or a limitation supported by the study.")
            for window in windows:
                seen.setdefault(window, page_number + 1)
    return notes


def body_repetition_notes(root, *, empty_headings_only=False) -> list[str]:
    """Locate repeated headings, floats and numerical prose in the typeset body."""
    root = root.resolve()
    main = root / "main.tex"
    notes = []
    try:
        sources = dict(active_tex_sources(root))
        if main not in sources:
            return []
        headings, figures = body_sections_and_figures(root, sources)
        groups = {}
        previous = None
        for title, location, empty in headings:
            key = title.casefold()
            if key == "conclusions":
                key = "conclusion"
            groups.setdefault(key, []).append((title, location, empty and key == previous))
            previous = key
        groups = {key: rows for key, rows in groups.items() if len(rows) > 1 and
                  (any(empty for _, _, empty in rows) or (key == "conclusion" and not empty_headings_only))}
        counts = Counter(figure.asset for figure in figures)
        figures = [] if empty_headings_only else [figure for figure in figures if counts[figure.asset] > 1]
        if empty_headings_only and not groups:
            return []

        import fitz
        with fitz.open(root / "main.pdf") as doc:
            for key, rows in groups.items():
                name = r"conclusions?" if key == "conclusion" else re.escape(key)
                heading = re.compile(rf"\s*(\d+)\.?\s+{name}\s*", re.I)
                rendered = sorted((int(m[1]), i + 1) for i, page in enumerate(doc)
                            for block in page.get_text("blocks", flags=0)
                            if (m := heading.fullmatch(block[4])))
                if len(rendered) != len(rows):
                    continue
                for i, (title, _, empty) in enumerate(rows):
                    if empty and rendered[i][0] == rendered[i-1][0] + 1:
                        notes.append(f"Empty repeated heading '{title}' in {rows[i-1][1]} and {rows[i][1]} "
                                     f"(sections {rendered[i-1][0]} and {rendered[i][0]}, "
                                     f"PDF p. {rendered[i][1]}). Keep one heading above the section text.")
                if key == "conclusion" and not empty_headings_only and not any(r[2] for r in rows):
                    where = ", ".join(f"section {n} (p. {p}, {loc})"
                                      for (n, p), (_, loc, _) in zip(rendered, rows))
                    notes.append(f"Repeated Conclusion heading in {where}. Merge the closing material into one section.")
            if len(figures) > 1:
                notes.extend(_repeated_figure_notes(doc, figures, sources, root))
            if not empty_headings_only:
                notes.extend(repeated_result_series(doc))
    except (ImportError, OSError, RuntimeError, TypeError, ValueError):
        # These optional notices require readable, matching typesetting artifacts.
        pass
    return notes


def stretched_prose(paper, doc, pages, *, appendix=False):
    """Locate TeX's worst underfull prose lines in the printed ICML columns."""
    log = paper / "main.log"
    if not log.is_file():
        return []
    warnings = re.findall(r"Underfull \\hbox \(badness 10000\) in paragraph at lines (\d+)--(\d+)\n(.*?)\n *\[\]",
                          log.read_text(errors="replace"), re.S)
    if not warnings:
        return []

    # Attribute a warning only when its typeset words also occur at the reported
    # source lines. Leave code, equations, floats and unmatched input files alone.
    tex = re.sub(r"(?m)(?<!\\)%.*$", "", (paper / "main.tex").read_text())
    if appendix:
        start = re.search(r"\\appendix\b", tex)
        if not start:
            return []
        # Source line numbers in the TeX log are relative to the complete document.
        tex = "\n" * tex.count("\n", 0, start.end()) + tex[start.end():]
    tex = re.split(r"\\(?:appendix\b|bibliography\s*\{)", tex, maxsplit=1)[0]
    excluded = (r"\\begin\{(?!(?:document|abstract|enumerate|itemize|description)\})([^{}]+)\}.*?\\end\{\1\}"
                r"|\\\[.*?\\\]|\$\$.*?\$\$")
    lines = re.sub(excluded, lambda m: "\n" * m[0].count("\n"), tex, flags=re.S).splitlines()

    def words(text):
        return " " + " ".join(re.findall(r"[a-z]+", text.lower().replace("-", ""))) + " "

    candidates = []
    for start, end, reported in warnings:
        # TeX's font switches and physical log wrapping are invisible on the printed line.
        visible = re.sub(r"\\[A-Z][A-Z0-9]*/(?:[\w.-]+/){3}[\d.]+(?:\s*\([+-]\d+\))?",
                         " ", reported.replace("\n", ""))
        for index in range(int(start) - 1, min(int(end), len(lines))):
            # The opening prose fragment is attributable even when the
            # following inline formula or file name forced TeX to stretch it.
            text = re.sub(r"\\(?:textbf|textit|emph|textrm|textnormal)\s*\{([^{}\\\$%]+)\}", r"\1", lines[index])
            plain = re.match(r"\s*(?:\\item\s+)?([A-Za-z][^\\${}%]*)", text)
            if plain:
                candidates.append((index + 1, words(plain[1]), words(visible)))
    if not candidates:
        return []

    notes = []
    for idx in pages:
        page = doc[idx]
        rows = {}
        for w in page.get_text("words"):
            x, y, right, bottom, word = w[:5]
            if (page.rect.width * .08 < x < right < page.rect.width * .94
                    and page.rect.height * .08 < y < bottom < page.rect.height * .94):
                rows.setdefault((x >= page.rect.width / 2, round(bottom)), []).append((x, right, word))
        for (right_column, _), row in rows.items():
            run = []
            for x, right, word in sorted(row):
                if run and x - run[-1][0] < 12:  # three consecutive gaps wider than a 10pt body em
                    run = []
                run.append((right, word))
                if len(run) < 4:
                    continue
                phrase = " ".join(w for _, w in run[-4:])
                normalized = words(phrase)
                if len(normalized.split()) != 4:
                    continue
                line = next((n for n, source, report in candidates if normalized in source and normalized in report), None)
                if line:
                    column = "right" if right_column else "left"
                    advice = ("Reflow the appendix paragraph and set any long path or code expression on its own "
                              "line. Preserve the exact commands, identifiers and recorded values." if appendix else
                              "Reflow the sentence or put the neighboring long expression on a display line.")
                    notes.append(f'PDF p. {idx + 1}, {column} column (main.tex:{line}): "{phrase}" has three '
                                 "consecutive word spaces of at least 12 pt. TeX reports maximum paragraph badness. "
                                 + advice)
                    break
            else:
                continue
            break  # one verifiable passage per affected page
    return notes


class CompilerMixin:
    """Mixin providing LaTeX compilation and figure management.

    Expects self to have: latex_dir, figures_dir, code_dir, config, hooks,
    log, log_step, run_agent, state_dir.
    """

    def compile_latex_with_errors(self) -> tuple:
        """Compile LaTeX and return (success, error_string).

        On success with no errors: returns (True, "").
        On success with errors (PDF exists but has issues): returns (True, error_string).
        On failure: returns (False, structured_errors).
        """
        success = self.compile_latex()
        compile_errors = getattr(self, '_last_compile_errors', [])

        if success and not compile_errors:
            return True, ""

        if success and compile_errors:
            # PDF exists but has issues (undefined refs, bibtex errors, etc.)
            error_str = "PDF was generated but has the following issues:\n\n"
            error_str += "\n".join(f"- {e[:150]}" for e in compile_errors[:10])
            return True, error_str

        # PDF not generated — real failure
        log_path = self.latex_dir / "main.log"
        errors = self._extract_latex_errors(log_path)

        stderr = getattr(self, '_last_compile_stderr', '')
        if "no specific errors found" in errors and stderr:
            errors += f"\n\nStderr from last pdflatex run:\n{stderr[:1000]}"

        if compile_errors:
            errors += "\n\nAdditional issues:\n" + "\n".join(f"- {e[:150]}" for e in compile_errors[:10])

        return False, errors

    def _extract_latex_errors(self, log_path: Path) -> str:
        """Parse LaTeX log for structured error messages."""
        return latex_utils.extract_latex_errors(log_path)

    def _body_repetition_notes(self, *, empty_headings_only=False) -> list[str]:
        return body_repetition_notes(self.latex_dir, empty_headings_only=empty_headings_only)

    def _compile_until_success(self, context: str = "") -> bool:
        """Keep fixing and recompiling until LaTeX compiles successfully.

        Strategy escalation:
        1. Attempts 1-3: Writer fixes errors normally
        2. Attempt 4: Programmatic fix (strip non-UTF8 bytes, fix common issues)
        3. Attempts 5-7: Writer with aggressive "comment out broken parts" prompt
        4. Attempt 8+: Writer rewrites broken sections from scratch

        Returns True when compiled, False only if 10 attempts all fail
        (should be extremely rare — our own agents generated this).
        """
        MAX_ATTEMPTS = 10
        last_errors = ""
        chain = []  # later rounds continue the first round's session

        for attempt in range(1, MAX_ATTEMPTS + 1):
            success, errors = self.compile_latex_with_errors()
            if success:
                if attempt > 1:
                    self.log_step(f"Compilation fixed on attempt {attempt}", "success")
                else:
                    self.log_step("Initial draft compiled successfully", "success")
                return True

            self.log_step(f"Compile attempt {attempt} failed", "warning")

            # Strategy 1 (attempts 1-3): normal writer fix
            if attempt <= 3:
                self.run_agent_chain(chain, "writer",
                    f"LaTeX compilation failed. Read paper/main.tex carefully, find and fix "
                    f"the syntax errors below. Do NOT remove content — fix the LaTeX syntax.\n\n{errors}")

            # Strategy 2 (attempt 4): programmatic fix for common issues
            elif attempt == 4:
                self.log_step("Trying programmatic fixes...", "progress")
                self._auto_fix_latex()
                # Also let writer have another look after programmatic fix
                success, errors = self.compile_latex_with_errors()
                if success:
                    self.log_step("Programmatic fix worked", "success")
                    return True
                self.run_agent_chain(chain, "writer",
                    f"After programmatic cleanup, LaTeX still fails. Fix these remaining errors:\n\n{errors}")

            # Strategy 3 (attempts 5-7): aggressive — comment out broken parts
            elif attempt <= 7:
                same_error = errors[:200] == last_errors[:200]
                self.run_agent_chain(chain, "writer",
                    f"LaTeX has failed {attempt} times{' with the same error' if same_error else ''}. "
                    f"Take aggressive action: COMMENT OUT the broken section entirely and replace "
                    f"with a brief placeholder like '% TODO: fix this section'. "
                    f"The paper MUST compile.\n\n{errors}")

            # Strategy 4 (attempt 8+): nuclear — rewrite from scratch
            else:
                self.run_agent_chain(chain, "writer",
                    f"LaTeX has failed {attempt} times. Read the ENTIRE main.tex file, identify ALL "
                    f"syntax errors, and rewrite any broken sections from scratch. Remove any "
                    f"non-standard packages or commands that might cause issues. "
                    f"Priority: the paper MUST compile, even if some content is lost.\n\n{errors}")

            last_errors = errors

        self.log_step(f"Compilation failed after {MAX_ATTEMPTS} attempts", "error")
        return False

    def _auto_fix_latex(self):
        """Programmatic fixes for common LaTeX compilation issues."""
        latex_utils.auto_fix_latex(self.latex_dir, log_fn=self.log)

    def _disclose_study_panel_art(self, source):
        """Identify synthetic subject artwork at its point of use in the paper."""
        from ark.figure_manifest import load_manifest
        figures = getattr(self, "figures_dir", None)
        if not isinstance(figures, Path):
            return
        language = str(getattr(self, "config", {}).get("language") or "en").lower()
        if language.startswith("en"):
            note = ("The AI-generated artwork is a conceptual illustration. Any shapes or axis "
                    "markings in it are illustrative. Measurements are reported in the results. ")
        elif language.startswith(("zh", "chinese")):
            note = "图中 AI 生成的部分是概念示意，图形和坐标刻度仅作说明。实验测量值见结果部分。"
        else:
            return
        from ark.nano_banana import TYPESET_PANELS
        artifacts = load_manifest(figures, infer_existing=False)["figures"]
        panels = {Path(name).stem for name, item in artifacts.items()
                  if isinstance(item, dict) and item.get("representation") in TYPESET_PANELS}
        if not panels:
            return

        def annotate(match):
            block = match.group()
            included = re.findall(r"\\includegraphics\*?(?:\s*\[[^]]*\])?\s*\{([^{}]+)\}", block)
            if not any(Path(name).stem in panels and (Path(name).parent == Path(".") or
                       (source.parent / Path(name).parent).resolve() == figures.resolve()) for name in included):
                return block
            if note.strip() in block or (re.search(r"illustrative|conceptual", block, re.I)
                    and re.search(r"not (?:an? )?(?:observed|measured|experimental|empirical|data)", block, re.I)):
                return block
            return re.sub(r"(\\caption(?:\s*\[[^]]*\])?\s*\{)", lambda m: m[0] + note, block, count=1)

        original = source.read_text(errors="replace")
        updated = re.sub(r"\\begin\{figure(\*?)\}.*?\\end\{figure\1\}", annotate, original, flags=re.S)
        if updated != original:
            source.write_text(updated)

    def compile_latex(self) -> bool:
        """Compile the LaTeX paper.

        Uses nonstopmode to avoid interactive prompts, but parses log/blg
        files for actual errors (undefined citations, bibtex syntax errors, etc.).

        On success, stores the PDF path in self._latest_pdf.
        Returns True/False for backward compat.
        """
        self.log("Compiling LaTeX...")
        self._last_compile_stderr = ""
        self._last_compile_errors = []
        source_path = self.latex_dir / "main.tex"
        if not source_path.is_file():
            self._last_compile_errors = ["main.tex is missing"]
            self.log("LaTeX compilation failed: main.tex is missing", "ERROR")
            return False
        self._disclose_study_panel_art(source_path)
        pdf_path = self.latex_dir / "main.pdf"
        # Strip phantom citations (cite keys that don't exist in
        # references.bib) before invoking pdflatex/bibtex. Without this,
        # writer agents that name a non-existent key produce "[?]" markers
        # in the rendered PDF and a stream of "I didn't find a database
        # entry" warnings the bibtex audit then has to chase. Running
        # the prune fresh on every compile is cheap (single regex pass)
        # and idempotent (a citation re-added to .bib later doesn't get
        # re-stripped).
        self._prune_undefined_citations()
        try:
            previous_pdf = pdf_path.stat() if pdf_path.is_file() else None
            for cmd in [
                ["pdflatex", "-interaction=nonstopmode", "main.tex"],
                ["bibtex", "main"],
                ["pdflatex", "-interaction=nonstopmode", "main.tex"],
                ["pdflatex", "-interaction=nonstopmode", "main.tex"],
            ]:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    timeout=120,
                    cwd=self.latex_dir,
                )
                stderr = result.stderr.decode("utf-8", errors="replace") if isinstance(result.stderr, bytes) else (result.stderr or "")
                stdout = result.stdout.decode("utf-8", errors="replace") if isinstance(result.stdout, bytes) else (result.stdout or "")
                if result.returncode != 0 and "main.tex" in cmd:
                    self._last_compile_stderr = stderr[:1000] or stdout[-1000:]

            # Parse log for real errors (not just warnings)
            log_path = self.latex_dir / "main.log"
            blg_path = self.latex_dir / "main.blg"

            if log_path.exists():
                log_text = log_path.read_text(errors="replace")
                # LaTeX errors start with "!"
                latex_errors = [l.strip() for l in log_text.split("\n") if l.startswith("!")]
                if latex_errors:
                    self._last_compile_errors.extend(latex_errors[:10])

            if blg_path.exists():
                blg_text = blg_path.read_text(errors="replace")
                # BibTeX errors. NB: do NOT match the "(There were N error
                # messages)" summary line — it's a count, not an error, and
                # surfacing it made clean compiles look broken. Match the actual
                # problems (parse errors / missing database entries) instead.
                import re as _re
                bib_errors = _re.findall(r"^I was expecting.*$|^Warning--I didn't find a database entry.*$",
                                         blg_text, _re.MULTILINE)
                if bib_errors:
                    self._last_compile_errors.extend(bib_errors[:10])

            current_pdf = pdf_path.stat() if pdf_path.is_file() else None
            if (source_path.is_file() and current_pdf and current_pdf.st_size > 0
                    and (previous_pdf is None or current_pdf.st_mtime_ns != previous_pdf.st_mtime_ns
                         or current_pdf.st_ino != previous_pdf.st_ino)):
                self._latest_pdf = pdf_path
                self._pdf_page_count = self._count_pdf_pages(pdf_path)
                self._body_page_count = self._count_body_pages(pdf_path)
                self._overfull_warnings = self._parse_overfull_warnings()
                page_info = f", {self._body_page_count:.1f} body pages ({self._pdf_page_count} total)" if self._body_page_count else ""
                overfull_info = f", {len(self._overfull_warnings)} overfull warnings" if self._overfull_warnings else ""
                error_info = f", {len(self._last_compile_errors)} errors" if self._last_compile_errors else ""
                self.log(f"LaTeX compiled successfully: {pdf_path} ({pdf_path.stat().st_size} bytes{page_info}{overfull_info}{error_info})")
                for note in self._body_repetition_notes():
                    self.log(f"Manuscript edit: {note}", "WARN")
                if self._last_compile_errors:
                    for err in self._last_compile_errors[:5]:
                        self.log(f"  Compile issue: {err[:120]}", "WARN")
                return True
            else:
                self.log("LaTeX compilation failed: no new PDF was generated")
                if self._last_compile_errors:
                    for err in self._last_compile_errors[:5]:
                        self.log(f"  Error: {err[:120]}", "ERROR")
                return False
        except Exception as e:
            self.log(f"LaTeX compilation error: {e}")
            return False

    def ensure_resolved_citations(self, context: str = "pre-delivery") -> bool:
        """Delivery gate: the final PDF must not contain unresolved citations.

        A late references.bib update or an agent-side bare ``pdflatex`` run (no
        bibtex pass) can leave the delivered PDF full of "?" markers with no
        References section even though every key is valid — shipped once in
        project 50350a67 (page-count check passed, nobody checked citations).
        Detect "?" citation markers on the RENDERED pdf text; if present,
        re-run the full pdflatex→bibtex→pdflatex×2 chain (rebuilds the .bbl)
        and re-check.
        """
        pdf = getattr(self, "_latest_pdf", None) or (self.latex_dir / "main.pdf")

        def _unresolved(p) -> int:
            try:
                import fitz
                doc = fitz.open(str(p))
                text = " ".join(pg.get_text() for pg in doc)
                doc.close()
                # "(?)"/"[?]"/" ? " — natbib/plain render unresolved cites this
                # way; English prose never puts a bare "?" between spaces.
                return len(re.findall(r"[\s(\[]\?[\s,.;)\]]", text))
            except Exception:
                return 0

        n = _unresolved(pdf)
        if not n:
            return True
        self.log(f"[{context}] {n} unresolved citation marker(s) in the final PDF "
                 f"— re-running the full bibtex chain", "WARN")
        self.compile_latex()
        n2 = _unresolved(pdf)
        if not n2:
            self.log(f"[{context}] Citations resolved after recompile", "INFO")
            return True

        # Recompile didn't help — references.bib is genuinely MISSING keys the
        # text cites (the citation search never populated them, or the writer
        # invented keys). Two-stage repair so a paper NEVER ships with "?":
        #   1. Backfill: resolve each orphan \cite key against academic DBs
        #      (DBLP/CrossRef/arXiv/S2) and add the real BibTeX under that key.
        #   2. Prune: any key still unresolvable → strip that \cite so the
        #      sentence stands without a dangling "?" rather than shipping one.
        self.log(f"[{context}] STILL {n2} unresolved — attempting citation "
                 f"backfill from academic databases", "WARN")
        added = self._resolve_orphan_citations(context)
        if added:
            self.compile_latex()
        if _unresolved(pdf):
            pruned = self._prune_undefined_citations()
            if pruned:
                self.log(f"[{context}] Pruned {pruned} unresolvable citation(s) "
                         f"that no database could confirm", "WARN")
                self.compile_latex()
        n3 = _unresolved(pdf)
        if n3:
            self.log(f"[{context}] {n3} citation(s) still unresolved after "
                     f"backfill+prune — bibliography is incomplete", "ERROR")
            return False
        self.log(f"[{context}] Citations resolved (backfilled {added} real "
                 f"reference(s))", "INFO")
        return True

    def _resolve_orphan_citations(self, context: str = "pre-delivery") -> int:
        """Backfill references.bib for \\cite keys that have no bib entry.

        For each orphan key, derive a search query from the key text
        (``pedregosa2011scikit`` → ``pedregosa 2011 scikit``), search the
        academic databases, and — on a confident title match — append the
        REAL BibTeX re-keyed to the orphan key so the citation resolves.
        Returns the number of references added. Fail-soft.
        """
        try:
            from ark.citation import search_papers, fetch_bibtex
        except Exception:
            return 0
        main_tex = self.latex_dir / "main.tex"
        if not main_tex.exists():
            return 0
        tex = main_tex.read_text(errors="replace")
        cite_keys = set()
        for m in self._CITE_CMD_RE.finditer(tex):
            for k in (m.group(4) or "").split(","):
                k = k.strip()
                if k:
                    cite_keys.add(k)
        bib_path = self.latex_dir / "references.bib"
        bib_text = bib_path.read_text(errors="replace") if bib_path.exists() else ""
        have = set(self._BIB_KEY_RE.findall(bib_text))
        orphans = sorted(cite_keys - have)
        if not orphans:
            return 0

        def _query_from_key(k: str) -> str:
            # split camelCase + digit boundaries: pedregosa2011scikit ->
            # "pedregosa 2011 scikit"
            s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", k)
            s = re.sub(r"(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])", " ", s)
            s = re.sub(r"[_\-]+", " ", s)
            return re.sub(r"\s+", " ", s).strip()

        added_entries = []
        for key in orphans:
            try:
                papers = search_papers(_query_from_key(key), max_results=5)
                if not papers:
                    continue
                bib = fetch_bibtex(papers[0])
                if not bib:
                    continue
                # Re-key the fetched entry to the ORIGINAL cite key so \cite
                # resolves (the real DB key differs from the text's key).
                bib = re.sub(r"(@\w+\s*\{)\s*[^,]+,", r"\1" + key + ",", bib, count=1)
                added_entries.append(f"% [ARK:source=backfill]\n{bib.strip()}")
                self.log(f"[{context}] backfilled '{key}' → {papers[0].title[:60]}", "INFO")
            except Exception:
                continue
        if not added_entries:
            return 0
        with open(bib_path, "a") as f:
            f.write("\n\n" + "\n\n".join(added_entries) + "\n")
        return len(added_entries)

    def _count_pdf_pages(self, pdf_path: Path) -> int:
        """Count total pages in a PDF file using PyMuPDF."""
        try:
            import fitz
            doc = fitz.open(str(pdf_path))
            count = len(doc)
            doc.close()
            return count
        except Exception as e:
            self.log(f"Page count check failed: {e}", "WARN")
        return 0

    # Citation commands recognised when pruning — the shared definition from
    # ark.citation, NOT a local copy. cleanup_unused() decides which bib entries
    # to delete using the same regex; when the two drifted apart, a citation one
    # of them could not see was deleted by the first and stripped by the second.
    _CITE_CMD_RE = CITE_CMD_RE

    # Top-level BibTeX entry headers, e.g. "@article{tiecke2017mapping,"
    _BIB_KEY_RE = re.compile(r'@\w+\s*\{\s*([^,\s]+)\s*,', re.MULTILINE)

    def _prune_undefined_citations(self) -> int:
        """Remove ``\\cite{...}``-family keys that don't appear in
        ANY of the project's .bib files, before pdflatex runs.

        Logic:
        1. Parse every ``*.bib`` file in the LaTeX directory (not just
           ``references.bib``) and union their cite keys into a single
           "defined" set. This is critical: ACL/NeurIPS/etc. ship a
           starter ``custom.bib`` (or ``anthology.bib``) which the
           ``\\bibliography{custom}`` line in main.tex actually reads.
           A previous version of this routine looked only at
           ``references.bib`` and would happily strip every
           ``\\cite{mlebench2024}`` etc. that lived in ``custom.bib``,
           leaving the final paper with an empty References page even
           though the keys were perfectly valid for bibtex.
        2. Walk every citation command in main.tex (``\\cite``,
           ``\\citep``, ``\\citet``, ``\\nocite``, biblatex variants,
           etc.). For each command, drop any key not present in the
           combined defined set.
        3. If all keys in a command are undefined, remove the command
           entirely; if some are valid, keep just those.

        Idempotent: a key re-added to any .bib file in a later
        iteration won't get re-stripped because we only act on what's
        currently missing.

        Returns the count of (command, key) pairs pruned.
        """
        main_tex = self.latex_dir / "main.tex"
        bib_files = sorted(self.latex_dir.glob("*.bib"))
        if not main_tex.exists() or not bib_files:
            return 0
        try:
            defined: set[str] = set()
            scanned: list[str] = []
            for bib_file in bib_files:
                try:
                    bib_text = bib_file.read_text(errors="replace")
                except Exception:
                    continue
                file_keys = {
                    m.group(1).strip()
                    for m in self._BIB_KEY_RE.finditer(bib_text)
                    if m.group(1).strip()
                }
                if file_keys:
                    defined |= file_keys
                    scanned.append(f"{bib_file.name}({len(file_keys)})")
            if not defined:
                return 0

            main_text = main_tex.read_text(errors="replace")
            pruned: list[tuple[str, str]] = []  # (cmd, key) for logging

            def _replace(match: "re.Match") -> str:
                cmd = match.group(1)
                pre = match.group(2) or ""
                post = match.group(3) or ""
                key_str = match.group(4)
                keys = [k.strip() for k in key_str.split(",")]
                # `\nocite{*}` is a wildcard meaning "every entry in the bib",
                # not a key — stripping it would silently drop the author's
                # request to print the full bibliography.
                if NOCITE_ALL in keys:
                    return match.group(0)
                valid = [k for k in keys if k and k in defined]
                invalid = [k for k in keys if k and k not in defined]
                if not invalid:
                    return match.group(0)
                for k in invalid:
                    pruned.append((cmd, k))
                if not valid:
                    # All keys gone → drop the whole command. The
                    # surrounding text may need a tiny tidy by the
                    # writer (e.g. dangling "(see )"), but that's
                    # better than rendering "[?]" in the final PDF.
                    return ""
                return f"\\{cmd}{pre}{post}{{{','.join(valid)}}}"

            new_text = self._CITE_CMD_RE.sub(_replace, main_text)

            if pruned:
                main_tex.write_text(new_text)
                summary = ", ".join(
                    sorted({k for _, k in pruned})
                )
                bibs_label = ", ".join(scanned) if scanned else "no .bib files"
                self.log(
                    f"Pruned {len(pruned)} undefined citation(s) "
                    f"({summary}) — keys not present in any .bib "
                    f"[scanned: {bibs_label}]",
                    "INFO",
                )
            return len(pruned)
        except Exception as e:
            self.log(f"_prune_undefined_citations failed: {e}", "WARN")
            return 0

    def _count_body_pages(self, pdf_path: Path) -> float:
        """Count body pages (before References section).

        Primary method: read \\arkBodyEndY / \\arkPageH from the .aux file
        (injected by _ensure_clearpage_before_bibliography via \\pdfsavepos).
        This gives the exact y-position where body text ends, immune to
        page-number / header / footer interference.

        Fallback: PyMuPDF text-block analysis (less accurate).

        Returns a float: e.g. 5.8 means 5 full pages + last page 80% filled.
        """
        # ── Try aux-based measurement first ──
        result = self._count_body_pages_from_aux(pdf_path)
        if result is not None:
            return result

        # ── Fallback: PyMuPDF text-block analysis ──
        return self._count_body_pages_from_pdf(pdf_path)

    def _count_body_pages_from_aux(self, pdf_path: Path) -> float | None:
        """Read body-end position from .aux file (written by \\pdfsavepos).

        Returns body page count as a float, or None if aux data unavailable.

        For two-column papers, the aux-recorded y position is 1-dimensional
        (vertical only) and reflects the *last shipped column's* bottom on
        the last body page. When that page has content only in the left
        column and an empty right column, the raw fill_ratio over-reports
        page utilisation: a half-empty page would read as ~85% full. This
        method post-corrects by sampling the rendered PDF: if the document
        is two-column overall and the last body page has an empty
        non-marker column, the fill is halved to reflect the actual area
        used.
        """
        aux_path = self.latex_dir / "main.aux"
        if not aux_path.exists():
            return None
        try:
            aux_text = aux_path.read_text(errors="replace")
            import re
            m_y = re.search(r'\\gdef\\arkBodyEndY\{(\d+)\}', aux_text)
            m_h = re.search(r'\\gdef\\arkPageH\{(\d+)\}', aux_text)
            if not m_y or not m_h:
                return None

            body_end_y_sp = int(m_y.group(1))   # sp from page bottom
            page_height_sp = int(m_h.group(1))   # total page height in sp
            if page_height_sp <= 0:
                return None

            # fill_ratio = fraction of page used (from top)
            fill_ratio = 1.0 - (body_end_y_sp / page_height_sp)

            import fitz
            doc = fitz.open(str(pdf_path))

            # Prefer the page recorded by the marker itself — it knows
            # its own page number even when an \appendix section sits
            # between body and \bibliography, which would otherwise
            # confuse a "References page minus one" heuristic.
            end_page = latex_utils.recorded_body_end_page(aux_text, len(doc))
            boundary = latex_utils.body_page_boundary(doc)
            pdf_end_page = None
            if boundary is not None:
                page_index, body_bottoms = boundary
                pdf_end_page = page_index + int(any(body_bottoms))
            if end_page is not None and end_page == pdf_end_page:
                last_body_idx = end_page - 1
                ref_page_idx = last_body_idx + 1  # used by column-adjust
            else:
                # With no verified marker page, use the rendered fallback for
                # both the page and its fill, avoiding stale AUX coordinates.
                doc.close()
                return None

            # Column-aware correction: if doc is two-column AND the last
            # body page has an empty column, the 1-D aux fill over-reports.
            adjusted, note = self._column_adjust(
                doc, last_body_idx, ref_page_idx, fill_ratio,
            )
            doc.close()

            result = last_body_idx + adjusted
            self.log(f"Body page count (aux): {result:.2f} "
                     f"(page {last_body_idx+1}, {adjusted:.1%} filled{note})",
                     "DEBUG")
            return result
        except Exception as e:
            self.log(f"Aux-based page count failed: {e}", "DEBUG")
            return None

    # Top fraction of a page that is treated as the running-header zone
    # and excluded when measuring "real" body content.
    _HEADER_BAND = 0.08
    # Same for the bottom — running-footer / page number band.
    _FOOTER_BAND = 0.96

    def _body_text_blocks(self, page):
        height = page.rect.height
        width = page.rect.width

        def margin_line_numbers(block):
            if block[2] > width * 0.08 and block[0] < width * 0.92:
                return False
            lines = block[4].split()
            return len(lines) >= 2 and all(line.isdecimal() for line in lines)

        return [
            block for block in page.get_text("blocks")
            if height * self._HEADER_BAND < block[3] < height * self._FOOTER_BAND
            and not (block[1] > height * 0.85 and block[4].strip().isdigit())
            and not margin_line_numbers(block)
        ]

    def _column_adjust(self, doc, last_body_idx: int, ref_page_idx: int,
                       fill_ratio: float) -> tuple[float, str]:
        """Return (adjusted_fill_ratio, log_note).

        For two-column docs, the aux-recorded y is one-dimensional and only
        reflects the column the body marker landed in. That under-counts
        when the *other* column is partially filled (e.g. left column
        full, right column halfway: aux reports the right's bottom y =
        50%, but the page is ~70% used) and over-counts when the marker's
        column is the only one with content (e.g. left=87%, right=0%:
        aux reports 87%, but the page is ~44% used).

        Replace fill_ratio with the average of the two columns' bottom y
        positions on the last body page — that captures area-use
        correctly across all four (L,R)-fill combinations: both full,
        both partial, only one filled, both empty. For single-column
        docs, return the aux ratio unchanged.
        """
        if not self._is_two_column_doc(doc, ref_page_idx):
            return fill_ratio, ""

        page = doc[last_body_idx]
        ph = page.rect.height
        mid_x = page.rect.width / 2
        content = self._body_text_blocks(page)
        left_y = max((b[3] for b in content if b[0] < mid_x), default=0)
        right_y = max((b[3] for b in content if b[0] >= mid_x), default=0)
        averaged = ((left_y + right_y) / ph) / 2
        note = (f"; 2-col area-avg ({left_y/ph:.0%}/{right_y/ph:.0%})")
        return averaged, note

    def _is_two_column_doc(self, doc, ref_page_idx: int) -> bool:
        """Decide whether the document is two-column by sampling early
        body pages. We deliberately skip the *last* body page — that's
        the page our caller is asking about, and if it is half-empty
        (which is exactly the case we want to flag), sampling it would
        produce a false "single-column" signal and disable the
        correction. We also avoid page 1 when possible because a title
        block can span both columns and is not representative.
        """
        if doc.page_count < 2 or ref_page_idx < 1:
            return False
        # Body pages are 0 .. ref_page_idx-1. Pick samples that are not
        # the last body page.
        body_pages = list(range(ref_page_idx))
        if len(body_pages) >= 3:
            # Skip first and last body page; sample middle.
            sample_indices = [body_pages[1], body_pages[len(body_pages) // 2]]
        elif len(body_pages) == 2:
            # Only the first body page is "not last".
            sample_indices = [body_pages[0]]
        else:
            # Single body page; nothing safer to sample.
            sample_indices = [body_pages[0]]

        # Require at least one sampled page to show content in both
        # halves — that's strong evidence of a two-column layout.
        for idx in sample_indices:
            page = doc[idx]
            mid_x = page.rect.width / 2
            content = self._body_text_blocks(page)
            has_left = any(b[0] < mid_x for b in content)
            has_right = any(b[0] >= mid_x for b in content)
            if has_left and has_right:
                return True
        return False

    def _count_body_pages_from_pdf(self, pdf_path: Path) -> float:
        """Fallback: count body pages via PyMuPDF text-block analysis.

        Column-aware: for two-column docs, averages left and right column
        fill on the last body page so a half-empty 2-col page reads as
        ~half full instead of as full as its filled column.
        """
        try:
            import fitz
            doc = fitz.open(str(pdf_path))

            boundary = latex_utils.body_page_boundary(doc)
            if boundary is None:
                total = len(doc)
                doc.close()
                return float(total)
            ref_page_idx, body_bottoms = boundary
            shares_body = any(body_bottoms)
            if not shares_body and ref_page_idx == 0:
                doc.close()
                return 0.0
            last_body_idx = ref_page_idx if shares_body else ref_page_idx - 1

            last_body_page = doc[last_body_idx]
            ph = last_body_page.rect.height
            mid_x = last_body_page.rect.width / 2
            if not shares_body:
                content_blocks = self._body_text_blocks(last_body_page)
                body_bottoms = (
                    max((b[3] for b in content_blocks if b[0] < mid_x), default=0),
                    max((b[3] for b in content_blocks if b[0] >= mid_x), default=0),
                )

            if self._is_two_column_doc(doc, ref_page_idx):
                # Two-column: average per-column fill so a half-empty page
                # reads as half full, not as full as its non-empty column.
                fill_ratio = sum(body_bottoms) / (2 * ph)
            else:
                fill_ratio = max(body_bottoms) / ph

            result = last_body_idx + fill_ratio
            doc.close()
            return result
        except Exception as e:
            self.log(f"Body page count failed: {e}", "WARN")
            return 0.0

    def _parse_overfull_warnings(self) -> list[str]:
        """Parse main.log for Overfull hbox warnings."""
        return latex_utils.parse_overfull_warnings(self.latex_dir)

    def _generate_figures_from_results(self) -> bool:
        """Generate figures from latest experiment results and copy to paper dir."""
        if hasattr(self.hooks, 'generate_figures_from_results'):
            return self.hooks.generate_figures_from_results(self)
        else:
            self.log("No generate_figures_from_results hook defined.", "WARN")
            return False

    def generate_figures(self) -> bool:
        """Run figure generation script. If script doesn't exist, try to create it first."""
        if hasattr(self.hooks, 'generate_figures'):
            return self.hooks.generate_figures(self)

        self.log("Generating paper figures...", "INFO")
        script_path = self.config.get("create_figures_script", "scripts/create_paper_figures.py")
        full_script = self.code_dir / script_path

        # If script doesn't exist, try to create it from results
        if not full_script.exists():
            self._create_plotting_script_if_needed()

        if not full_script.exists():
            self.log(f"No figure script at {script_path}, skipping", "INFO")
            self._precheck_figure_quality()
            return True

        try:
            self.figures_dir.mkdir(parents=True, exist_ok=True)

            from ark.figure_manifest import load_manifest, register_figure, save_manifest
            import hashlib

            def figure_versions():
                return {p: p.stat().st_mtime_ns for p in self.figures_dir.iterdir()
                        if p.is_file() and p.suffix.lower() in {".png", ".pdf", ".jpg", ".jpeg"}}

            before = figure_versions()
            # Run the plotting script with the orchestrator's own interpreter
            # (the project-local conda env, which ships matplotlib/numpy/pandas).
            # Avoid `mamba activate` in a non-init shell — it emits a "libmamba
            # Shell not initialized" warning and short-circuits the python call.
            result = subprocess.run(
                [sys.executable, script_path],
                capture_output=True,
                text=True,
                timeout=300,
                cwd=self.code_dir,
            )

            if result.returncode == 0:
                # Record files this script actually produced, including descriptive
                # names. The first draft also uses this entrypoint before any review.
                manifest = load_manifest(self.figures_dir, infer_existing=False)
                for path, updated in figure_versions().items():
                    entry = manifest["figures"].get(path.name, {})
                    if updated == before.get(path) or entry.get("source") not in (None, "matplotlib"):
                        continue
                    register_figure(manifest, path.name, "matplotlib", figures_dir=self.figures_dir,
                                    script=str(script_path), artifact_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                save_manifest(self.figures_dir, manifest)
                self.log("Figure generation completed successfully", "INFO")
                self._precheck_figure_quality()
                return True
            else:
                self.log(f"Figure generation warning: {result.stderr[:500]}", "WARN")
                return True  # Continue even with warnings
        except Exception as e:
            self.log(f"Figure generation error: {e}", "ERROR")
            return False

    def _precheck_figure_quality(self):
        """Pre-check figure quality before reviewer sees the paper."""
        self.log(">>> Figure quality pre-check...", "PRECHECK")
        from ark.figure_legibility import describe

        issues = []
        pdfs = sorted(self.figures_dir.glob("*.pdf"))
        pngs = sorted(self.figures_dir.glob("fig*.png"))
        if not (pdfs or pngs):
            self.log("No figure assets available for pre-check", "PRECHECK")
            return
        for pdf in pdfs:
            try:
                issue = describe(pdf)
            except Exception as exc:
                issue = f"could not check the vector labels: {exc}"
            if issue:
                issues.append(f"{pdf.name}: {issue}")

        for png in pngs:
            try:
                from PIL import Image
                with Image.open(png) as image:
                    width, height = image.size
                if height / width < 0.35:
                    issues.append(f"{png.name}: aspect ratio too flat ({height / width:.2f}), recommend height >= width * 0.4")
                if width < 600:
                    issues.append(f"{png.name}: width too small ({width}px), recommend >= 800px")
            except Exception as exc:
                issues.append(f"{png.name}: could not check raster dimensions: {exc}")
            if not png.with_suffix(".pdf").exists():
                issues.append(f"{png.stem}: missing PDF version")

        if issues:
            for issue in issues:
                self.log(issue, "PRECHECK")
            self.log("Update the source plot and regenerate the affected figure.", "PRECHECK")
        else:
            self.log("Figure quality pre-check found no issues in the checked assets.", "PRECHECK")

    def _generate_figure_config(self) -> dict:
        """Generate figure_config.json from template geometry for plotting scripts."""
        from ark.latex_geometry import get_geometry, write_figure_config

        venue = self.config.get("venue_format", "")
        if not venue:
            venue_name = self.config.get("venue", "").lower()
            venue = venue_name if venue_name else "acmart-sigplan"

        geo = get_geometry(venue, paper_dir=self.latex_dir)
        config_path = self.figures_dir / "figure_config.json"
        write_figure_config(geo, config_path)
        self.log(f"Figure config generated: {config_path} (column={geo['columnwidth_in']}in, font={geo['font_size_pt']}pt)", "INFO")
        return geo

    def _run_figure_phase(self):
        """Figure Phase: generate figures and ensure template-aware sizing.

        1. Generate figure_config.json (geometry)
        2. Load manifest, backup protected (AI-generated) figures
        3. Run matplotlib figure script (if exists) + overlap detection
        4. Restore any overwritten protected figures
        5. Generate AI concept figures (Nano Banana, if enabled)
        6. Compile LaTeX

        Figure *quality* issues are handled by the reviewer, not here.
        """
        from ark.figure_manifest import (
            load_manifest, save_manifest, register_figure,
            backup_protected, restore_protected,
        )

        # Step 1: Generate geometry config
        geo = self._generate_figure_config()

        # Step 2: Load manifest (auto-migrates if missing)
        manifest = load_manifest(self.figures_dir)

        # Step 3: Run figure generation script
        script_path = self.config.get("create_figures_script", "scripts/create_paper_figures.py")
        full_script = self.code_dir / script_path
        if full_script.exists():
            self.log_step("Running figure generation script...", "progress")

            # Backup protected files before running matplotlib script
            backups = backup_protected(self.figures_dir, manifest)

            self.generate_figures()

            # Restore any AI-generated files overwritten by the script
            restore_protected(self.figures_dir, backups, log_fn=self.log)

            # Merge outputs registered by the stock generator before accounting
            # for older project hooks that only write files to disk.
            manifest["figures"].update(load_manifest(self.figures_dir, infer_existing=False)["figures"])
            # Register matplotlib outputs in manifest. Pass figures_dir so
            # register_figure can read the actual PDF width (in inches) from
            # disk — that width is what decides placement single vs full,
            # which is what the writer reads to pick figure vs figure*.
            for fig_file in self.figures_dir.glob("fig*"):
                if fig_file.suffix in (".pdf", ".png", ".jpg"):
                    if fig_file.name not in manifest.get("figures", {}):
                        register_figure(
                            manifest, fig_file.name, "matplotlib",
                            figures_dir=self.figures_dir,
                        )
                    elif manifest["figures"][fig_file.name].get("source") == "matplotlib":
                        pass  # Already registered
            save_manifest(self.figures_dir, manifest)

            # Step 3.1: Programmatic overlap detection and auto-fix.
            # Two-layer architecture:
            #   Layer-1 (figure_overlap.check_and_fix_figures) — cheap regex
            #     fixes; runs up to 3 rounds.
            #   Layer-2 (the coder agent) — when Layer-1 exhausts,
            #     unresolved overlaps are written to
            #     ``auto_research/state/unresolved_overlaps.yaml`` so the
            #     next planner pass converts each into a
            #     FIGURE_CODE_REQUIRED task. The planner reads that file
            #     as part of its standard input set.
            try:
                from ark.figure_overlap import check_and_fix_figures
                state_dir = self.code_dir / "auto_research" / "state"
                overlap_report = check_and_fix_figures(
                    full_script, self.figures_dir, geo, log_fn=self.log,
                    state_dir=state_dir,
                )
                if overlap_report.get("summary", {}).get("with_overlaps", 0) > 0:
                    self.log_step("Regenerating figures after overlap fixes...", "progress")
                    backups = backup_protected(self.figures_dir, manifest)
                    self.generate_figures()
                    restore_protected(self.figures_dir, backups, log_fn=self.log)
                if overlap_report.get("escalation_needed"):
                    self.log(
                        "Unresolved figure overlaps escalated to coder via "
                        "auto_research/state/unresolved_overlaps.yaml — the "
                        "next planner iteration will create FIGURE_CODE_REQUIRED "
                        "tasks to redesign the affected figures.",
                        "WARN",
                    )
            except Exception as e:
                self.log(f"Overlap detection error (non-fatal): {e}", "WARN")
        else:
            self.log_step(f"No figure script at {script_path}, skipping generation", "info")
            self._precheck_figure_quality()

        # Step 4: Generate AI concept figures (Nano Banana)
        if self.config.get("figure_generation") == "nano_banana":
            self.log_step("Generating AI concept figures (Nano Banana)...", "progress")
            self._generate_nano_banana_figures()

        # Step 5: Compile LaTeX
        self.compile_latex()

    def _should_skip_figure_phase(self) -> bool:
        """Check if figure phase can be skipped (smart skipping).

        Skip if no figure-related files changed since last commit AND
        the current score is above threshold - 1.
        """
        try:
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD~1"],
                capture_output=True, text=True, timeout=30,
                cwd=self.code_dir,
            )
            if result.returncode != 0:
                return False  # Can't determine, don't skip

            changed_files = result.stdout.strip().split("\n") if result.stdout.strip() else []
            scripts_dir = self.config.get("scripts_dir", "scripts")
            figures_dir_name = self.config.get("figures_dir", "Latex/figures")

            figure_related = any(
                f.endswith(".py") and (scripts_dir in f or "figure" in f.lower())
                or figures_dir_name in f
                for f in changed_files
            )

            if figure_related:
                return False  # Figure files changed, must run

            # Check score threshold
            current_score = self.memory.scores[-1] if self.memory.scores else 0
            threshold = self.paper_accept_threshold - 1
            if current_score >= threshold:
                self.log_step("Skipping figure phase (no figure changes, score above threshold-1)", "info")
                return True

            return False
        except Exception:
            return False  # On error, don't skip

    def pdf_to_images(self) -> list:
        """Convert PDF to page images for visual review using PyMuPDF."""
        self.log("Converting PDF to images for visual review...", "INFO")
        pdf_path = self.latex_dir / "main.pdf"
        if not pdf_path.exists():
            self.log("PDF not found, skipping image conversion", "WARN")
            return []

        # Direct import (same approach as _count_pdf_pages / _count_body_pages)
        try:
            import fitz
            doc = fitz.open(str(pdf_path))
            image_paths = []
            for i, page in enumerate(doc):
                img_path = self.latex_dir / f"page_{i+1:02d}.png"
                pix = page.get_pixmap(dpi=150)
                pix.save(str(img_path))
                image_paths.append(str(img_path))
            n = doc.page_count
            doc.close()
            # A paper that just lost a page leaves the image of the page it no
            # longer has. Nothing else removes it, and the up-to-date shortcut
            # below globs the directory, so the next review would be shown a
            # phantom page — usually the near-empty one that compression cut,
            # which is exactly the kind of thing a reviewer files an issue
            # about. Measured on a cheap test: 4 images, then a 3-page PDF.
            for stale in self.latex_dir.glob("page_*.png"):
                try:
                    if int(stale.stem.split("_")[1]) > n:
                        stale.unlink()
                except (ValueError, IndexError, OSError):
                    pass
            self.log(f"Generated {len(image_paths)} page images", "INFO")
            return image_paths
        except ImportError:
            # self.log("PyMuPDF not available, trying subprocess fallback", "WARN")
            pass
        except Exception as e:
            self.log(f"Direct pdf_to_images failed: {e}", "WARN")

        return []

    def _maybe_generate_page_images(self) -> list:
        """Convert PDF to page images, skipping if images are already up-to-date."""
        pdf_path = self.latex_dir / "main.pdf"
        if not pdf_path.exists():
            return self.pdf_to_images()

        first_page = self.latex_dir / "page_01.png"
        if first_page.exists():
            try:
                if first_page.stat().st_mtime >= pdf_path.stat().st_mtime:
                    # Images are up-to-date
                    images = sorted(self.latex_dir.glob("page_*.png"))
                    if images:
                        self.log("Page images up-to-date, skipping regeneration", "INFO")
                        return [str(img) for img in images]
            except OSError:
                pass  # Fall through to regenerate

        return self.pdf_to_images()

    def _strip_legacy_needs_check_notes(self, bib_path: "Path") -> int:
        """Remove `note = {\\textcolor{red}{[NEEDS-CHECK: ...]}}` fields
        injected by older citation-verification code paths. The new
        convention is a `% [NEEDS-CHECK]` comment line above each
        affected entry; the rendered PDF stays clean.

        Returns the number of stripped notes. Idempotent.
        """
        try:
            text = bib_path.read_text(errors="replace")
            # Match the whole line containing the textcolor note (with
            # optional trailing comma so we don't leave a dangling comma).
            pattern = re.compile(
                r"\s*,?\s*note\s*=\s*\{\\textcolor\{red\}"
                r"\{\[NEEDS-CHECK[^\}]*\]\}\}\s*,?",
                re.IGNORECASE,
            )
            new_text, n = pattern.subn("", text)
            # Also tag the entry's preceding line with a comment marker
            # so downstream tooling (summary PDF) still sees the
            # NEEDS-CHECK status — but only if not already tagged.
            if n and new_text != text:
                bib_path.write_text(new_text)
                self.log(
                    f"Stripped {n} legacy red-textcolor NEEDS-CHECK note(s) "
                    "from references.bib",
                    "INFO",
                )
            return n
        except Exception as e:
            self.log(f"_strip_legacy_needs_check_notes failed: {e}", "WARN")
            return 0

    def _run_citation_verification(self):
        """Verify references.bib, fix errors, mark NEEDS-CHECK, clean unused."""
        from ark.citation import (verify_bib, fix_bib, cleanup_unused,
                                  reset_source_health, unavailable_sources)

        bib_path = self.latex_dir / "references.bib"
        if not bib_path.exists():
            return

        # Merge venue-template starter .bib files (custom.bib /
        # anthology.bib / etc.) into references.bib first. The
        # research-phase merge in PipelineMixin runs at project
        # creation but is skipped on Continue — without re-running it
        # here, citation pruning later in this same compile cycle
        # would strip every \cite{} key that lives only in custom.bib.
        # Idempotent: re-running on an already-merged file is a no-op.
        try:
            if hasattr(self, "_merge_template_bibs_into_references"):
                self._merge_template_bibs_into_references()
        except Exception as e:
            self.log(f"_merge_template_bibs_into_references skipped: {e}", "WARN")

        # Strip legacy red-textcolor notes left in the bib by earlier
        # versions of this routine. They render in red in the rendered
        # references list; the new convention is a `% [NEEDS-CHECK]`
        # comment line above the entry, which is invisible to LaTeX.
        self._strip_legacy_needs_check_notes(bib_path)

        lit_path = str(self.state_dir / "literature.yaml")
        bib_str = str(bib_path)
        tex_dir = str(self.latex_dir)

        self.log_step("Citation verification...", "progress")

        try:
            # 1. Verify each entry against DBLP/CrossRef
            reset_source_health()
            results = verify_bib(bib_str)

            if results:
                needs_check = [r for r in results if r.status == "NEEDS-CHECK"]
                corrected = [r for r in results if r.status == "CORRECTED"]
                verified = [r for r in results if r.status == "VERIFIED"]

                # 2. Apply fixes (add note field for NEEDS-CHECK, overwrite CORRECTED)
                if corrected or needs_check:
                    fix_bib(bib_str, results)

                # 2.5 Close the loop: an unverified reference must not reach
                # delivery as-is. verify_bib only consults DBLP+CrossRef, so
                # give every NEEDS-CHECK entry a second chance against the
                # FULL API set (arXiv + Semantic Scholar too): a confident
                # title match REPLACES the entry with real API BibTeX
                # (re-keyed, so \cite still resolves); anything no database
                # can confirm is DROPPED (entry + its \cite uses) rather than
                # shipped as an LLM's guess. Guard: if nothing at all
                # verified this round the APIs were likely unreachable —
                # keep the marks and touch nothing.
                replaced_keys, removed_keys = [], []
                if needs_check:
                    from ark.citation import replace_unverified_entries, remove_entries
                    replaced_keys, unresolved_keys = replace_unverified_entries(
                        bib_str, needs_check)
                    if replaced_keys:
                        self.log("Citation loop: replaced "
                                 f"{len(replaced_keys)} unverified entr{'y' if len(replaced_keys)==1 else 'ies'} "
                                 f"with API-verified BibTeX: {', '.join(replaced_keys)}", "INFO")
                    down = unavailable_sources()
                    if unresolved_keys and down:
                        # Unconfirmed is not the same as nonexistent. With a
                        # source silent, keep the entries (marked) and the text.
                        self.log("Citation loop: kept "
                                 f"{len(unresolved_keys)} unconfirmed reference(s) "
                                 f"because {', '.join(down)} did not answer; "
                                 "nothing dropped", "WARN")
                    elif unresolved_keys and (verified or corrected or replaced_keys):
                        removed_keys = remove_entries(bib_str, unresolved_keys)
                        if removed_keys:
                            pruned = self._prune_undefined_citations()
                            self.log("Citation loop: dropped "
                                     f"{len(removed_keys)} unconfirmable reference(s) "
                                     f"(+{pruned} \\cite use(s) pruned): {', '.join(removed_keys)}",
                                     "WARN")
                    elif unresolved_keys:
                        self.log("Citation loop: nothing verified this round (APIs "
                                 "unreachable?) — keeping NEEDS-CHECK marks untouched", "WARN")
                    if replaced_keys or removed_keys:
                        self.compile_latex()

                still_marked = [r.entry_key for r in needs_check
                                if r.entry_key not in replaced_keys
                                and r.entry_key not in removed_keys]

                # 3. Log summary
                summary = []
                if verified:
                    summary.append(f"{len(verified)} verified")
                if corrected:
                    summary.append(f"{len(corrected)} fixed")
                if replaced_keys:
                    summary.append(f"{len(replaced_keys)} replaced (2nd-pass API match)")
                if removed_keys:
                    summary.append(f"{len(removed_keys)} dropped (unconfirmable)")
                if still_marked:
                    summary.append(f"{len(still_marked)} marked needs-check")

                if summary:
                    self.log(f"BibTeX audit: {', '.join(summary)}", "INFO")

                # 4. Notify about entries that stayed marked (loop couldn't act)
                if still_marked:
                    self.send_notification(
                        "BibTeX Check Needed",
                        f"{len(still_marked)} citation(s) in references.bib need manual verification. "
                        "Marked with 'ark-note: NEEDS-CHECK' in the .bib file.",
                        priority="warning",
                    )

                # 4.5. Enforce critical citations
                self._enforce_critical_citations(lit_path, tex_dir)
            else:
                # Still try cleanup even if verify returns nothing or errors
                pass

            # 5. Clean up unused entries
            original_size = bib_path.stat().st_size
            cleanup_unused(bib_str, tex_dir)
            cleaned_size = bib_path.stat().st_size
            if cleaned_size < original_size:
                self.log(f"BibTeX cleanup: removed unused entries ({original_size} -> {cleaned_size} bytes)", "INFO")

        except Exception as e:
            self.log(f"Citation verification failed: {e}", "WARN")

    def _enforce_critical_citations(self, lit_path: str, tex_dir: str):
        """Check that all critical (MUST CITE) papers are cited in tex."""
        lit_file = Path(lit_path)
        if not lit_file.exists():
            return

        try:
            lit_data = yaml.safe_load(lit_file.read_text()) or {}
        except Exception:
            return

        # Collect all critical cite keys
        critical = []
        for ref in lit_data.get("references", []):
            if isinstance(ref, dict) and ref.get("importance") == "critical":
                critical.append((ref.get("bibtex_key", ""), ref.get("title", "")))
        for nc in lit_data.get("needs_check", []):
            if isinstance(nc, dict) and nc.get("importance") == "critical":
                critical.append((nc.get("bibtex_key", ""), nc.get("title", "")))

        if not critical:
            return

        # Collect all cited keys from tex (shared extractor — a narrower regex
        # here reports keys as missing that the paper already cites, and burns a
        # writer agent call telling it to add a citation that is right there).
        cited_keys = cited_keys_in_dir(tex_dir)

        # Find missing critical citations
        missing = [(key, title) for key, title in critical if key and key not in cited_keys]

        if not missing:
            return

        self.log_step(f"{len(missing)} critical citation(s) missing from paper, asking writer to add", "warning")

        missing_list = "\n".join(f"- \\cite{{{key}}} — {title}" for key, title in missing)
        latex_dir_name = self.config.get("latex_dir", "paper")

        self.run_agent("writer", f"""
The following critical citations are missing from the paper. They are marked as MUST CITE
in the research report but are not currently referenced anywhere in {latex_dir_name}/main.tex.

{missing_list}

Add each of these citations to the most appropriate location in the paper (typically Related Work).
Write a brief sentence or clause that naturally incorporates each \\cite{{}} command.
Do NOT remove any existing citations. Do NOT modify references.bib.
""", timeout=600)

    def _check_final_concept_image(self, fig, path, manifest, api_key, aspect_ratio):
        """Check the registered candidate, editing it at most once for this study design."""
        from hashlib import sha256
        from ark.figure_manifest import save_manifest
        from ark.nano_banana import (concept_design, review_concept_image, repair_concept_image,
                                     create_study_panel, SEMANTIC_REVIEW_VERSION, TYPESET_PANELS, semantic_verdict, verify_printed_labels,
                                     generated_result_conflict, reject_generated_result, native_study_design, IMAGE_MODELS)

        entry = manifest["figures"][path.name]
        if entry.get("representation") == "subject_with_mechanism_panel":
            from ark.nano_banana import mechanism_panel_is_grounded
            if not mechanism_panel_is_grounded(entry, fig, self.state_dir):
                return False
        design = concept_design(fig, getattr(self, "state_dir", None))
        design_digest = sha256(design.encode()).hexdigest()
        image_digest = sha256(path.read_bytes()).hexdigest()
        provider = entry.get("provider") or ("google" if api_key else "openrouter")
        key = os.environ.get("OPENROUTER_API_KEY") if provider == "openrouter" else api_key
        model = self.config.get("paperbanana_text_model") or os.getenv("MAIN_MODEL_NAME") or "gemini-flash-latest"
        if provider == "openrouter":
            model = model.removeprefix("openrouter/")
            if "/" not in model:
                model = "google/" + model
        else:
            model = model.removeprefix("google/").removeprefix("gemini/")
        old = entry.get("semantic_review") or {}
        if old.get("artifact_sha256") == image_digest and (conflict := generated_result_conflict(old.get("checks"))):
            blocked = reject_generated_result(old, conflict)
            if old != blocked:
                entry["semantic_review"] = blocked
                save_manifest(self.figures_dir, manifest)
            return False
        same_design = old.get("design_sha256") == design_digest
        cached = None
        if (same_design and old.get("version") == SEMANTIC_REVIEW_VERSION
                and old.get("artifact_sha256") == image_digest and old.get("model") == model
                and old.get("status") in ("passed", "unclear", "contradiction")
                and (old.get("status") != "passed" or semantic_verdict(old.get("checks")) == "passed")):
            cached = verify_printed_labels(path, old, entry, aspect_ratio)
            if cached["status"] == old["status"]:
                if cached != old:
                    entry["semantic_review"] = cached
                    save_manifest(self.figures_dir, manifest)
                return old["status"] == "passed"

        def persist(review):
            review.update(version=SEMANTIC_REVIEW_VERSION, artifact_sha256=sha256(path.read_bytes()).hexdigest(),
                          design_sha256=design_digest)
            entry["semantic_review"] = review
            save_manifest(self.figures_dir, manifest)

        def inspect():
            if not key:
                return {"status": "unavailable", "model": model, "provider": provider}
            goal = design
            if entry.get("representation") == "subject_with_comparison_panel":
                goal += ("\nPresentation: a subject-only illustration and bounded typeset comparison panels. "
                         "Compare all visible groups and every panel statement to the ORIGINAL design. The "
                         "full protocol belongs in the caption/methods, so no arrows or extra workflow stages "
                         "are required. Assess the entire image; reject invented groups or labels. Also verify the "
                         "proposed caption against the design: " + str(entry.get("panel_plan", {}).get("caption") or ""))
            elif entry.get("representation") == "subject_with_mechanism_panel":
                goal += ("\nInspect the whole composite. The subject artwork must be wordless and data-free. "
                         "Letters, numbers, labeled samples, counts, plots or observations in that artwork are "
                         "contradictions. Check the separately typeset operations, every number and the direction "
                         "of each connector against the approved protocol and the requested mechanism. A box "
                         "containing two compared operations does not mean that one operates on the other.")
            review = review_concept_image(path, goal, provider, key, model)
            return verify_printed_labels(path, review, entry, aspect_ratio)

        attempted = self.__dict__.setdefault("_concept_review_attempts", set())
        attempt = (path, image_digest, design_digest, model)
        if attempt in attempted and old.get("status") == "unavailable":
            return False
        attempted.add(attempt)
        history = {k: old[k] for k in ("repair_attempted", "initial_review", "panel_attempted", "edited_review")
                   if same_design and k in old}
        review = cached or inspect()
        if conflict := generated_result_conflict(review.get("checks")):
            persist(reject_generated_result(review, conflict))
            return False
        native = getattr(self, "state_dir", None)
        native = Path(native) / "native_project.json" if native else None
        image_design = native_study_design(json.loads(native.read_text()), native.parent) if (
            native and native.is_file() and fig.get("representation") in ("study_panel", "schematic")
        ) else design
        if (review["status"] == "contradiction" and not history.get("repair_attempted")
                and entry.get("representation") not in TYPESET_PANELS):
            persist(review)
            history.update(repair_attempted=True, initial_review=dict(review))
            persist({**review, **history})
            image_model = entry.get("image_model") or self.config.get("paperbanana_image_model") or IMAGE_MODELS["flash"]
            receipt = {}
            if repair_concept_image(path, image_design, review, provider, key, image_model, aspect_ratio, receipt):
                entry["before_semantic_edit"] = {k: entry[k] for k in (
                    "source", "provider", "image_model", "model_version", "response_id", "payload_source",
                    "artifact_sha256", "payload_sha256", "selected_candidate") if k in entry}
                entry.update(receipt, source="nano_banana", selected_candidate="semantic_edit")
                persist({"status": "unavailable", "model": model, "provider": provider, **history})
                review = inspect()
            else:
                review["repair_status"] = "unavailable"

        if (review["status"] == "contradiction" and entry.get("selected_candidate") == "semantic_edit"
                and not history.get("panel_attempted")
                and (history.get("initial_review") or {}).get("status") == "contradiction"):
            # Two distinct reviewed images contradicted the design. Stop using
            # freeform visual relationships and typeset the supported conditions.
            persist({**review, **history})
            history.update(panel_attempted=True, edited_review=dict(entry["semantic_review"]))
            persist({**review, **history})
            receipt = create_study_panel(path, image_design, provider, key, model, aspect_ratio)
            if receipt:
                entry["before_study_panel"] = {k: entry[k] for k in (
                    "provider", "image_model", "response_id", "payload_source", "artifact_sha256",
                    "payload_sha256", "selected_candidate") if k in entry}
                entry.update(receipt, source="nano_banana")
                persist({"status": "unavailable", "model": model, "provider": provider, **history})
                review = inspect()
            else:
                review["panel_status"] = "unavailable"
        attempted.add((path, sha256(path.read_bytes()).hexdigest(), design_digest, model))
        review.update(history)
        persist(review)
        self.log(f"Final concept review for {path.name}: {review['status']}", "INFO")
        return review["status"] == "passed"

    def _generate_nano_banana_figures(self) -> int:
        import fcntl
        self.figures_dir.mkdir(parents=True, exist_ok=True)
        with (self.figures_dir / ".concept-review.lock").open("a") as lock:
            # Two overlapping workers must share a single repair allowance.
            fcntl.flock(lock, fcntl.LOCK_EX)
            return self._generate_and_review_concept_figures()

    def _generate_and_review_concept_figures(self) -> int:
        """Generate AI concept figures using PaperBanana pipeline or Nano Banana fallback.

        All concept figure data lives in figures_dir (paper/figures/):
        - concept_figures.json — spec of what figures to generate
        - fig_*.png — generated images
        - figure_manifest.json — tracks provenance (source: paperbanana/nano_banana)

        Flow:
        1. Check if spec + all PNGs already exist → skip planner
        2. Otherwise run planner agent to identify concept figures
        3. Read spec from: figures_dir (designated) → agent text → rglob (fallback)
        4. Normalize spec to figures_dir/concept_figures.json
        5. For each figure not yet in manifest: PaperBanana → Nano Banana fallback

        Returns:
            Number of concept figures available (existing + newly generated).
        """
        from ark.nano_banana import DEFAULT_MODEL, get_api_key
        from ark.figure_manifest import load_manifest, save_manifest, register_figure, AI_SOURCES

        spec_path = self.figures_dir / "concept_figures.json"
        manifest = load_manifest(self.figures_dir, infer_existing=False)

        def reusable(name):
            import hashlib
            from PIL import Image

            path = self.figures_dir / f"{name}.png"
            entry = manifest.get("figures", {}).get(path.name)
            if not isinstance(entry, dict) or entry.get("source") not in AI_SOURCES:
                return False
            try:
                if entry.get("artifact_sha256"):
                    return hashlib.sha256(path.read_bytes()).hexdigest() == entry["artifact_sha256"]
                # Older generated projects have no digest. Preserve their
                # recorded assets when the image still decodes.
                with Image.open(path) as image:
                    image.verify()
                return True
            except (OSError, ValueError, SyntaxError):
                return False

        def valid_specs(specs):
            return isinstance(specs, list) and bool(specs) and all(
                isinstance(fig, dict) and isinstance(fig.get("name"), str)
                and fig["name"] and Path(fig["name"]).name == fig["name"] for fig in specs)

        saved_figures = []
        if spec_path.is_file():
            try:
                candidate = json.loads(spec_path.read_text())
                if valid_specs(candidate):
                    saved_figures = candidate
            except (ValueError, OSError):
                pass
        # ── Phase 1: Get API key ──
        # PaperBanana can route image generation through OpenRouter, so an
        # OpenRouter key alone is enough — a Gemini key is no longer required.
        api_key = get_api_key()
        cached_candidates = bool(saved_figures) and all(reusable(fig["name"]) for fig in saved_figures)
        if not cached_candidates and not api_key and not os.environ.get("OPENROUTER_API_KEY"):
            self.log("No Gemini or OpenRouter API key found, skipping AI figure generation", "WARN")
            # Tell the USER, not just the log — an OpenAI-only user silently got
            # papers without concept figures and had no idea why (d239c708).
            try:
                self._chat(
                    "agent",
                    "ℹ️ AI concept figures were skipped: no Gemini or OpenRouter "
                    "API key is configured. Data figures are unaffected. To get "
                    "AI-generated overview/method figures, add an OpenRouter or "
                    "Gemini key in Settings → API Keys, then Continue the project.",
                    kind="notice",
                )
            except Exception:
                pass
            return 0

        # A spent OpenRouter key. PaperBanana prefers OpenRouter whenever the
        # key is set, so every figure would make a paid call that 402s before
        # falling back. With a Gemini key, go straight to the Gemini-direct
        # Nano Banana path; without one, say why the figures are missing.
        skip_paperbanana = False
        if not cached_candidates and os.environ.get("OPENROUTER_API_KEY"):
            from ark.provider_billing import openrouter_too_low_for_side_tasks
            or_low = openrouter_too_low_for_side_tasks()
            if or_low is not None:
                if api_key:
                    self.log(f"OpenRouter balance is ${or_low:.2f}: generating concept "
                             f"figures with the Gemini key instead", "WARN")
                    skip_paperbanana = True
                else:
                    self.log(f"OpenRouter balance is ${or_low:.2f} and there is no Gemini "
                             f"key: skipping AI figure generation", "WARN")
                    try:
                        self._chat(
                            "agent",
                            f"ℹ️ AI concept figures were skipped: your OpenRouter "
                            f"balance is ${or_low:.2f}, too low for image generation. "
                            f"Data figures are unaffected. Top up at "
                            f"https://openrouter.ai/credits (or add a Gemini key in "
                            f"Settings → API Keys), then Continue the project to add them.",
                            kind="notice",
                        )
                    except Exception:
                        pass
                    return 0

        venue = self.config.get("venue", "")

        # ── Phase 2: Gather context for planner ──
        title = self.config.get("title", "")
        findings_file = self.state_dir / "findings.yaml" if hasattr(self, 'state_dir') else None
        dr_file = self.state_dir / "deep_research.md" if hasattr(self, 'state_dir') else None
        main_tex = self.latex_dir / "main.tex"

        source_lines = [f"Paper title: {title}", f"Venue: {venue}", "",
                        "## Source Material (MANDATORY — Read in full before planning)"]
        idea_file = self.state_dir / "idea.md" if hasattr(self, 'state_dir') else None
        if idea_file and idea_file.exists():
            source_lines.append("- `auto_research/state/idea.md` — research idea")
        if dr_file and dr_file.exists():
            source_lines.append("- `auto_research/state/deep_research.md` — background research")
        if findings_file and findings_file.exists():
            source_lines.append("- `auto_research/state/findings.yaml` — experiment findings")
        if main_tex.exists():
            main_tex_rel = main_tex.relative_to(self.code_dir) if main_tex.is_relative_to(self.code_dir) else main_tex
            source_lines.append(f"- `{main_tex_rel}` — current paper draft (if already written)")
        source_lines.append("")
        source_lines.append("Use Read to load each file in full. Do NOT guess at the research content —")
        source_lines.append("concept figures only make sense when grounded in what the paper actually claims.")

        paper_context = "\n".join(source_lines)

        # ── Phase 3: Run planner agent ──
        figures_dir_rel = self.figures_dir.relative_to(self.code_dir) if self.figures_dir.is_relative_to(self.code_dir) else self.figures_dir
        analysis_output = "" if saved_figures else self.run_agent("planner", f"""Based on the research described below, identify concept figures that should be
AI-generated for this paper. These are architecture diagrams, system overviews, pipeline illustrations,
mechanism diagrams — NOT data plots (bar charts, line charts etc. are handled separately).

## Research Context
{paper_context}

## Your Task
Select the concept figure that best explains the study's central comparison, mechanism or design.
Additional distinct figures should answer a different reader question and fit the page budget.
For empirical studies use the actual data flow, contrasts or evaluation design. Do not invent
an architecture, learned component or quantitative result to make a diagram look more complex.

IMPORTANT: Save the JSON array to the file: {figures_dir_rel}/concept_figures.json
Also output the same JSON in your response text.

The JSON format:
```json
[
  {{
    "name": "fig_overview",
    "caption": "System architecture overview showing the main components and data flow",
    "section_context": "Detailed description of what the figure should show — all components, connections, stages, data flows. Be specific about the research system's structure.",
    "latex_label": "fig:overview",
    "placement": "full_width"
  }}
]
```

Rules for "placement":
- "full_width": for complex multi-stage pipelines, architectures with 4+ components
- "single_column": for simple 2-3 component diagrams

We encourage at least 1 system overview figure if the research has a multi-component system.
Output up to 3 figures maximum. If the research truly has no visual architecture to illustrate,
output: NO_CONCEPT_FIGURES
""", timeout=600)

        if not saved_figures and (not analysis_output or "NO_CONCEPT_FIGURES" in analysis_output):
            # Quality floor: a paper with any system / method / pipeline almost
            # always wants one overview figure — a weak model emitting
            # NO_CONCEPT_FIGURES is usually a miss, not a real absence (this is
            # exactly how runs shipped figureless). Repair once with a stricter
            # prompt; synthesize a grounded default if it still refuses. Opt out
            # via config require_concept_figure=False.
            if not self.config.get("require_concept_figure", True):
                self.log_step("Planner decided no concept figures needed", "info")
                return 0
            self.log("Planner emitted NO_CONCEPT_FIGURES — repairing: forcing one grounded overview figure.", "WARN")
            analysis_output = self.run_agent("planner", f"""You previously concluded this paper needs no concept figure. For a paper with
any system, method, pipeline, or architecture that is almost never correct.

Re-read the research context and output EXACTLY ONE system-overview / pipeline
figure that best illustrates the paper's core contribution. "NO_CONCEPT_FIGURES"
is NOT an allowed answer this time.

## Research Context
{paper_context}

Save the JSON array (a single figure object) to {figures_dir_rel}/concept_figures.json
and also output it in your response. Format:
```json
[{{"name": "fig_overview", "caption": "...", "section_context": "Be specific: the system's components, stages, connections, and data flow.", "latex_label": "fig:overview", "placement": "full_width"}}]
```
""", timeout=600)
            if not saved_figures and (not analysis_output or "NO_CONCEPT_FIGURES" in analysis_output):
                self.log("Repair still produced none — synthesizing a default overview figure spec.", "WARN")
                fallback_fig = [{
                    "name": "fig_overview",
                    "caption": f"Overview of {title or 'the proposed approach'}.",
                    "section_context": (
                        f"A clean modern technical illustration giving a system overview for the "
                        f"paper titled '{title}'. Show the main components, how they connect, the "
                        f"processing/data flow between them, and the overall inputs and outputs."),
                    "latex_label": "fig:overview",
                    "placement": "full_width",
                }]
                try:
                    spec_path.write_text(json.dumps(fallback_fig, indent=2))
                    self.log_step("Synthesized a default overview concept figure (floor).", "info")
                except Exception as e:
                    self.log(f"Could not write synthesized concept spec: {e}", "WARN")
                    return 0
            # fall through to Phase 4 — spec_path / analysis_output now hold a figure

        # ── Phase 4: Read concept figure spec (2-level fallback) ──
        figures = saved_figures

        # Level 1: Read from designated path (agent was told to save here)
        if not figures and spec_path.exists():
            try:
                parsed = json.loads(spec_path.read_text())
                if valid_specs(parsed):
                    figures = parsed
                    self.log(f"Loaded concept figures from {spec_path}", "INFO")
            except (json.JSONDecodeError, OSError):
                pass

        # Level 2: Parse from agent text response
        if not figures and analysis_output:
            bracket_blocks = re.findall(r'\[[\s\S]*?\]', analysis_output)
            for block in sorted(bracket_blocks, key=len, reverse=True):
                if len(block) < 20:
                    continue
                try:
                    parsed = json.loads(block)
                    if valid_specs(parsed):
                        figures = parsed
                        self.log("Parsed concept figures from planner text output", "INFO")
                        break
                except json.JSONDecodeError:
                    continue

        if not figures:
            self.log("No concept figures from designated path or planner text output", "WARN")
            return 0

        # ── Phase 4.5: Normalize — save spec to designated path ──
        self.figures_dir.mkdir(parents=True, exist_ok=True)
        spec_path.write_text(json.dumps(figures, indent=2, ensure_ascii=False) + "\n")

        # ── Phase 5: Generate images ──
        paper_text = paper_context

        from ark.latex_geometry import get_geometry
        venue_format = self.config.get("venue_format", venue)
        geo = get_geometry(venue_format, paper_dir=self.latex_dir) if venue_format else {"columnwidth_in": 3.333}

        columns = geo.get("columns", 1)
        col_w = geo.get("columnwidth_in", 3.333)
        text_w = geo.get("textwidth_in", 7.0)

        generated = 0
        skipped = 0
        for fig in figures:
            name = fig.get("name", "concept_fig")
            caption = fig.get("caption", "")
            section_ctx = fig.get("section_context", "")
            placement = fig.get("placement", "full_width")
            output_path = self.figures_dir / f"{name}.png"

            # Determine aspect ratio and width based on placement
            if columns == 1:
                fig_width = text_w
                aspect_ratio = "16:9"
            elif placement == "full_width":
                fig_width = text_w
                aspect_ratio = "21:9"
            else:
                fig_width = col_w
                aspect_ratio = "4:3"

            if aspect_ratio not in GEMINI_IMAGE_ASPECT_RATIOS:
                raise ValueError(
                    f"Illegal aspect_ratio {aspect_ratio!r} for Gemini image API; "
                    f"must be one of {sorted(GEMINI_IMAGE_ASPECT_RATIOS)}"
                )

            if reusable(name):
                if self._check_final_concept_image(fig, output_path, manifest, api_key, aspect_ratio):
                    skipped += 1
                continue

            self.log(f"  Generating: {name} (placement={placement}, {fig_width:.1f}in, ratio={aspect_ratio})...", "INFO")

            # Try PaperBanana pipeline first (best quality)
            receipt = {}
            source = "paperbanana"
            ok = (not skip_paperbanana) and self._try_paperbanana(
                name=name,
                caption=caption,
                paper_context=section_ctx or paper_text[:3000],
                output_path=output_path,
                api_key=api_key,
                aspect_ratio=aspect_ratio,
                receipt=receipt,
            )

            # Fallback to our Nano Banana pipeline
            if not ok:
                source = "nano_banana"
                self.log(f"  PaperBanana unavailable, falling back to Nano Banana...", "INFO")
                from ark.nano_banana import generate_figure_pipeline
                ok = generate_figure_pipeline(
                    figure_name=name,
                    caption=caption,
                    paper_context=section_ctx or paper_text[:2000],
                    output_path=output_path,
                    api_key=api_key,
                    model=self.config.get("nano_banana_model") or DEFAULT_MODEL,
                    venue=venue,
                    column_width_in=fig_width,
                    max_critic_rounds=self.config.get("nano_banana_critic_rounds", 3),
                    log_fn=self.log,
                    aspect_ratio=aspect_ratio,
                    receipt=receipt,
                )
            if ok:
                self.log(f"  Generated: {output_path.name}", "INFO")
                # Pass the authoritative placement (from concept_figures.json)
                # and actual rendered width through to the manifest, so the
                # writer and compression skill don't have to infer from
                # pixel count — AI PNG pixel dimensions are a model choice,
                # not a physical paper measurement.
                register_figure(
                    manifest, output_path.name, source,
                    figures_dir=self.figures_dir,
                    width_in=fig_width,
                    placement=placement,
                    **receipt,
                    # scalable defaults to True for AI sources (bitmap)
                )
                save_manifest(self.figures_dir, manifest)
                if self._check_final_concept_image(fig, output_path, manifest, api_key, aspect_ratio):
                    generated += 1
            else:
                self.log(f"  Failed: {name}", "WARN")

        # Bytes must match the extension before anything reads these files.
        # Image models return whatever format they please; a JPEG saved as
        # .png compiles fine but makes the reviewer's vision call fail with
        # a 400 that aborts the whole run. Runs on the reuse path too — a
        # pre-existing (seeded or resumed) figure is just as likely to lie.
        try:
            from ark.figure_manifest import normalize_image_formats
            normalize_image_formats(self.figures_dir, log_fn=self.log)
        except Exception as e:  # noqa: BLE001
            self.log(f"Figure format normalisation skipped: {e}", "WARN")

        if generated > 0:
            self.log_step(f"Generated {generated} AI concept figures", "success")
        elif skipped > 0:
            self.log_step(f"All {skipped} concept figures already exist", "info")
        else:
            self.log_step("No new concept figures generated", "info")

        return generated + skipped

    def _try_paperbanana(self, name: str, caption: str, paper_context: str,
                          output_path, api_key: str, aspect_ratio: str = "16:9",
                          receipt: dict | None = None) -> bool:
        """Try to generate a concept figure using PaperBanana's full pipeline.

        PaperBanana uses: Retriever → Planner → Stylist → Visualizer → Critic (×3 rounds)
        with reference images from PaperBananaBench for few-shot learning.

        Returns True if figure was generated successfully, False if PaperBanana unavailable.
        """
        import asyncio
        output_path = Path(output_path)

        # Set API key BEFORE importing PaperBanana — its generation_utils
        # module calls reinitialize_clients() at import time, which reads
        # GOOGLE_API_KEY / OPENROUTER_API_KEY from the environment.
        import os
        if api_key:
            os.environ["GOOGLE_API_KEY"] = api_key
        from ark.nano_banana import IMAGE_MODELS, _save_generated_image

        openrouter = bool(os.environ.get("OPENROUTER_API_KEY"))
        text_default = "google/gemini-3.1-pro-preview" if openrouter else "gemini-3.1-pro-preview"
        # Respect explicit project overrides on either route. Keep historical
        # OpenRouter Pro / native Flash defaults unless the owner selected a tier.
        tier = self.config.get("nano_banana_model") or ("pro" if openrouter else "flash")
        image_default = IMAGE_MODELS.get(tier, tier)
        if openrouter:
            image_default = "google/" + image_default.removeprefix("google/")
        text_model = self.config.get("paperbanana_text_model") or os.getenv("MAIN_MODEL_NAME") or text_default
        image_model = self.config.get("paperbanana_image_model") or os.getenv("IMAGE_GEN_MODEL_NAME") or image_default

        try:
            import sys
            # compiler.py lives at ark/latex/compiler.py — three .parent
            # walks (compiler.py → latex/ → ark/ → repo root) reach the
            # submodules/ directory. The pre-refactor path used
            # ``parent.parent`` because compiler.py was at ark/compiler.py.
            # That two-step walk now stops at ark/ and silently returns
            # False here, sending every concept-figure call to the Nano
            # Banana fallback even when PaperBanana is fully installed.
            pb_dir = Path(__file__).parent.parent.parent / "submodules" / "PaperBanana"
            if not pb_dir.exists():
                return False
            if str(pb_dir) not in sys.path:
                sys.path.insert(0, str(pb_dir))

            from agents.planner_agent import PlannerAgent
            from agents.visualizer_agent import VisualizerAgent
            from agents.stylist_agent import StylistAgent
            from agents.critic_agent import CriticAgent
            from agents.retriever_agent import RetrieverAgent
            from utils import generation_utils
            from utils.config import ExpConfig
            from utils.paperviz_processor import PaperVizProcessor
        except ImportError as e:
            self.log(f"PaperBanana not available: {e}", "WARN")
            return False

        # Check if PaperBananaBench data exists (for reference retrieval)
        data_dir = pb_dir / "data" / "PaperBananaBench"
        retrieval = "auto" if (data_dir / "diagram" / "ref.json").exists() else "none"
        if retrieval == "auto":
            self.log(f"  Using PaperBanana with reference retrieval ({data_dir})", "INFO")
        else:
            self.log(f"  Using PaperBanana without reference retrieval", "INFO")

        try:
            # PaperBanana is also a standalone tool: a missing environment key
            # falls back to its checkout-wide YAML, and its router prefers any
            # OpenRouter client it finds. Project workers must use owner keys.
            # Rebind its cached clients before invoking any vendor agents.
            file_config = generation_utils.model_config
            generation_utils.model_config = {k: v for k, v in file_config.items() if k != "api_keys"}
            try:
                generation_utils.reinitialize_clients()
            finally:
                generation_utils.model_config = file_config

            # Pass the models EXPLICITLY. PaperBanana's ExpConfig otherwise loads
            # configs/model_config.yaml, whose `main_model_name: gemini-flash-latest`
            # (an invalid OpenRouter slug) takes precedence over our env vars — it
            # 400-fails every text agent (planner/stylist/critic), so the image
            # model draws blind and produces a generic off-topic diagram. Setting
            # these here bypasses the bad file and restores the full pipeline.
            exp_config = ExpConfig(
                dataset_name="PaperBananaBench",
                task_name="diagram",
                exp_mode="demo_full",
                retrieval_setting=retrieval,
                max_critic_rounds=self.config.get("nano_banana_critic_rounds", 3),
                work_dir=pb_dir,
                main_model_name=text_model,
                image_gen_model_name=image_model,
            )

            retriever = RetrieverAgent(exp_config=exp_config)
            if tier == "flash":
                # PaperBanana sends every candidate's entire method section to
                # the selector (809k input tokens on a four-page evaluation).
                # The Flash tier still selects ten visual references.
                retriever.task_config["ref_limit"] = 24
            processor = PaperVizProcessor(
                exp_config=exp_config,
                vanilla_agent=None,
                planner_agent=PlannerAgent(exp_config=exp_config),
                visualizer_agent=VisualizerAgent(exp_config=exp_config),
                stylist_agent=StylistAgent(exp_config=exp_config),
                critic_agent=CriticAgent(exp_config=exp_config),
                retriever_agent=retriever,
                polish_agent=None,
            )

            data = {
                "candidate_id": name,
                "content": paper_context,
                "visual_intent": f"{caption} Use brief legible labels, clear reading order and only the elements needed to explain the stated comparison or mechanism. Keep experimental measurements in the data plots.",
                "additional_info": {"rounded_ratio": aspect_ratio},
            }

            # Run async pipeline
            async def _run():
                return await processor.process_single_query(data, do_eval=False)

            try:
                asyncio.get_running_loop()
            except RuntimeError:
                result = asyncio.run(_run())
            else:
                # This synchronous mixin can also be invoked by an async host.
                # Use another loop without retrying an already-started paid run.
                from concurrent.futures import ThreadPoolExecutor
                with ThreadPoolExecutor(max_workers=1) as executor:
                    result = executor.submit(lambda: asyncio.run(_run())).result()

            # The critic chooses this field, including when it rolls back after
            # a failed revision. Sorting all base64 fields picks the stylist's
            # draft before the critic's revision and can even select a reference.
            import base64
            selected = result.get("eval_image_field", "")
            encoded = result.get(selected) if selected.endswith("_base64_jpg") else None
            if not encoded:
                self.log("PaperBanana returned no selected image", "WARN")
                return False
            _save_generated_image(base64.b64decode(encoded, validate=True), output_path, receipt,
                                  provider="openrouter" if openrouter else "google",
                                  image_model=image_model, selected_candidate=selected,
                                  payload_source="paperbanana_selected_image")
            self.log(f"  PaperBanana generated {output_path.name} with {image_model} ({selected})", "INFO")
            return True

        except Exception as e:
            self.log(f"  PaperBanana error: {e}", "WARN")
            return False

    def _pdf_to_images_fallback(self) -> list:
        """Fallback: use external pdf_to_images.py script."""
        env_name = self.config.get("conda_env", "base")
        script_path = f"{self.config.get('scripts_dir', 'scripts')}/pdf_to_images.py"
        try:
            result = subprocess.run(
                ["bash", "-c", f"source ~/.bashrc 2>/dev/null || true; mamba activate {env_name} && python {script_path} {self.latex_dir}/main.pdf --dpi 150"],
                capture_output=True, text=True, timeout=120, cwd=self.code_dir,
            )
            if result.returncode == 0:
                images = list(self.latex_dir.glob("page_*.png"))
                return [str(img) for img in sorted(images)]
            else:
                self.log(f"PDF to images fallback warning: {result.stderr[:200]}", "WARN")
                return []
        except Exception as e:
            self.log(f"PDF to images fallback error: {e}", "ERROR")
            return []
