"""SLURM job submission, polling, and cancellation; local subprocess fallback."""

from __future__ import annotations

import getpass
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

from jinja2 import Template

_SLURM_TEMPLATE = Path(__file__).parent / "slurm_template.sh"

# Per-run control-plane job token lifetime. Generous so long runs never outlive
# their token; tokens are project-scoped and rotate with SECRET_KEY.
CONTROL_PLANE_TOKEN_TTL_SECONDS = 14 * 86400


def control_plane_transport(project_id: str, settings) -> tuple[str, str]:
    """Choose the boundary transport for a launched orchestrator.

    Returns ``(control_plane_url, control_plane_token)``. When
    ``settings.control_plane_url`` is configured, mints a per-project bearer token
    so the run reports over the /v1 HTTP API. Otherwise returns ``("", "")`` and
    callers fall back to the legacy in-process ``--db-path`` path (keeps SLURM /
    local single-node working unchanged until an operator opts in)."""
    url = (getattr(settings, "control_plane_url", "") or "").strip()
    if not url:
        return "", ""
    # Fail fast on a malformed / unexpanded URL (e.g. a literal "${BASE_URL}/v1"
    # that was never substituted, or a bare host). Otherwise it is handed verbatim
    # to the remote orchestrator, which crashes on its first status report deep in
    # urllib ("unknown url type") — a silent-remote-death that looks like a hung
    # run, since poll() only sees the cluster still UP.
    from urllib.parse import urlparse
    _p = urlparse(url)
    if _p.scheme not in ("http", "https") or not _p.netloc:
        raise ValueError(
            f"CONTROL_PLANE_URL is not a valid absolute http(s) URL: {url!r}. "
            f"If it references ${{BASE_URL}}, ensure BASE_URL is set so it expands."
        )
    from .auth import make_job_token
    token = make_job_token(project_id, settings.secret_key,
                           ttl_seconds=CONTROL_PLANE_TOKEN_TTL_SECONDS)
    return url, token

# Per-project conda env: lives at <project_dir>/.env as a `--prefix` env cloned
# from the configured base env. Detected via the conda-meta directory which
# every conda env has, even an empty one.
PROJECT_ENV_DIRNAME = ".conda_env"


def project_env_prefix(project_dir: Path) -> Path:
    return Path(project_dir) / PROJECT_ENV_DIRNAME


def project_env_ready(project_dir: Path) -> bool:
    return (project_env_prefix(project_dir) / "conda-meta").is_dir()


def find_conda_binary() -> str | None:
    """
    Locate the conda binary even when PATH is bare (e.g. systemd unit with no
    Environment=PATH=). Tries shutil.which, then $CONDA_EXE, then common
    install prefixes under $HOME.
    """
    # Shared team install (e.g. /data/fat/ark/conda) takes precedence so every
    # member resolves the same conda/envs. Env var, else pyproject [tool.ark].
    from ark.paths import get_team_config
    shared_root = get_team_config().get("conda_root")
    if shared_root:
        for rel in ("condabin/conda", "bin/conda"):
            cand = Path(shared_root) / rel
            if cand.is_file():
                return str(cand)
    found = shutil.which("conda")
    if found:
        return found
    env_var = os.environ.get("CONDA_EXE")
    if env_var and Path(env_var).is_file():
        return env_var
    home = Path(os.path.expanduser("~"))
    candidates = [
        home / "miniforge3" / "condabin" / "conda",
        home / "miniforge3" / "bin" / "conda",
        home / "miniconda3" / "condabin" / "conda",
        home / "miniconda3" / "bin" / "conda",
        home / "anaconda3" / "condabin" / "conda",
        home / "anaconda3" / "bin" / "conda",
        Path("/opt/conda/bin/conda"),
    ]
    if sys.platform == "darwin":
        # Homebrew on Apple Silicon installs to /opt/homebrew
        candidates += [
            Path("/opt/homebrew/anaconda3/condabin/conda"),
            Path("/opt/homebrew/anaconda3/bin/conda"),
            Path("/opt/homebrew/miniforge3/condabin/conda"),
            Path("/opt/homebrew/miniforge3/bin/conda"),
        ]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


_ANACONDA_TOS_CHANNELS = [
    "https://repo.anaconda.com/pkgs/main",
    "https://repo.anaconda.com/pkgs/r",
]


def _accept_conda_tos(conda_bin: str, log_file=None) -> None:
    """Accept ToS for the default Anaconda channels non-interactively.

    conda 24+ requires per-user ToS acceptance stored in ~/.conda/tos.
    This is safe to call multiple times; already-accepted channels are a no-op.
    Errors are logged but do not raise so that a missing tos sub-command on
    older conda builds doesn't break provisioning.
    """
    for channel in _ANACONDA_TOS_CHANNELS:
        try:
            proc = subprocess.run(
                [conda_bin, "tos", "accept", "--override-channels",
                 "--channel", channel],
                capture_output=True, text=True,
            )
            if log_file is not None:
                log_file.write(f"# conda tos accept {channel}: "
                               f"rc={proc.returncode} {proc.stdout.strip()}\n")
        except Exception as e:
            if log_file is not None:
                log_file.write(f"# conda tos accept {channel} failed: {e}\n")


_PROVISION_HEARTBEAT_SECONDS = 30
# Generous: a lean base clones in well under a minute, but a cold NFS cache
# can make even that slow. Overridable for hosts with an unusual base env.
_PROVISION_TIMEOUT_SECONDS = int(os.environ.get("ARK_ENV_PROVISION_TIMEOUT", "600"))
# Cloning onto NFS occasionally loses a race: conda cannot unlink a file it just
# wrote ("Could not remove or rename ... you may need to reboot to free file
# handles"), the link transaction rolls back, and rc=1 kills a run that had
# already spent Gate A budget (2026-09-10, project b5fedacd, libglib). The exact
# same clone succeeded on the next try, so the step is flaky rather than broken.
# Retries only help if each one starts from a genuinely empty target — which is
# what _set_aside_partial_env guarantees. With that in place, three attempts
# ride out a transient NFS wobble at the cost of a couple of minutes.
_PROVISION_ATTEMPTS = int(os.environ.get("ARK_ENV_PROVISION_ATTEMPTS", "3"))
# 5s was not enough: on 2026-09-11 a retry fired 13s after the first failure
# and hit the same wedged NFS state. Give the filesystem room to settle. The
# pause is multiplied by the attempt number so later retries back off further.
_PROVISION_RETRY_PAUSE_SECONDS = 20


def _set_aside_partial_env(target: Path) -> Path | None:
    """Move a broken/partial env out of the way ATOMICALLY instead of deleting it.

    This is the fix for the retry that never worked. `shutil.rmtree(...,
    ignore_errors=True)` cannot remove files that still have handles open over
    NFS — the server silly-renames them to .nfsXXXX and the unlink is silently
    skipped. So the retry's `conda create --clone` landed in a directory that
    was NOT empty, tried to replace the previous attempt's leftovers, and hit
    the very same "Could not remove or rename ... free file handles" race that
    killed attempt one. Every retry inherited the last attempt's corpse
    (b5fedacd 09-10, 5c0e44f1 09-11, f028f3ba 09-12 — all three, both attempts).

    `os.rename` of the directory is atomic on the same filesystem, NFS
    included, and requires no unlink of anything inside. The debris is simply
    no longer at the path conda writes to, so the next attempt starts from a
    genuinely empty target. The set-aside dirs are reclaimed best-effort by
    `_sweep_stale_envs`; if a sweep can't delete one yet, nothing is blocked.

    The clone itself must still target the canonical prefix — conda bakes the
    prefix into shebangs and activation scripts, so clone-to-temp-then-rename
    would produce a broken env. Only the FAILED debris is ever renamed.
    """
    if not target.exists():
        return None
    aside = target.with_name(f"{target.name}.stale-{uuid.uuid4().hex[:8]}")
    try:
        os.rename(target, aside)
        return aside
    except OSError:
        # Rename itself failed (target vanished mid-flight, or a truly odd
        # mount). Fall back to the old best-effort delete; the attempt loop
        # still gets whatever clean slate it can.
        shutil.rmtree(target, ignore_errors=True)
        return None


def _sweep_stale_envs(target: Path) -> int:
    """Best-effort reclaim of `<target>.stale-*` set-aside dirs. Never raises.

    Returns how many were removed. A dir that still can't be deleted (handles
    open on NFS) is left for a later sweep — it is out of conda's path, so it
    costs disk, not correctness.
    """
    removed = 0
    try:
        for stale in target.parent.glob(f"{target.name}.stale-*"):
            if stale.is_dir():
                shutil.rmtree(stale, ignore_errors=True)
                if not stale.exists():
                    removed += 1
    except Exception:
        pass
    return removed


def _kill_tree(proc) -> None:
    """Kill a process group started with start_new_session=True. Best-effort.

    SIGTERM first so conda can unwind, escalating to SIGKILL only if it is
    still alive — a wedged NFS call often ignores TERM.
    """
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(os.getpgid(proc.pid), sig)
        except Exception:
            return
        try:
            proc.wait(timeout=3)
            return
        except Exception:
            continue


def _provision_progress(log_path: Path) -> str:
    """Liveness signal for the heartbeat, read from OUTSIDE the env being built.

    This used to be `sum(1 for _ in target.rglob("*"))` — a full recursive walk
    of the very tree conda was mid-transaction on, every 30s, over NFS. The
    walk holds directory references, so conda's unlink of a file it had just
    written degraded to an NFS silly-rename and failed:

        Could not remove or rename .../pandas/plotting/_matplotlib/hist.py.
        Please remove this file manually (you may need to reboot to free
        file handles)

    …and the link transaction rolled back. Both 2026-09 provisioning failures
    (b5fedacd, 5c0e44f1) died 13 and 17 seconds after a heartbeat walk, and
    clones that finished inside the first 30s — before any walk — never failed.
    Monitoring must not perturb what it monitors, so this stats one file conda
    is only appending to.
    """
    try:
        return f"{log_path.stat().st_size // 1024} KB of conda output"
    except Exception:
        return "no output yet"


def provision_project_env(project_dir: Path, base_env: str = "ark-base",
                          log_path: Path | None = None,
                          timeout: int = _PROVISION_TIMEOUT_SECONDS,
                          log_fn=None) -> tuple[bool, str]:
    """
    Create a per-project conda env at <project_dir>/.env by cloning ``base_env``.

    Returns ``(success, message)``. Idempotent: returns success immediately if
    the env is already present. Writes the conda command output to ``log_path``
    (or <project_dir>/.env_provision.log) for debugging.

    The clone is BOUNDED: it is killed after ``timeout`` seconds and emits a
    heartbeat through ``log_fn`` every 30s so a long clone is visibly alive.
    """
    project_dir = Path(project_dir)
    target = project_env_prefix(project_dir)
    log_path = Path(log_path) if log_path else (project_dir / ".env_provision.log")
    log_path.parent.mkdir(parents=True, exist_ok=True)

    if project_env_ready(project_dir):
        return True, f"already exists at {target}"

    conda_bin = find_conda_binary()
    if not conda_bin:
        msg = ("conda binary not found (checked PATH, $CONDA_EXE, and common "
               "miniforge/anaconda locations); cannot provision project env")
        log_path.write_text(msg + "\n")
        return False, msg

    cmd = [conda_bin, "create", "--prefix", str(target),
           "--clone", base_env, "--yes"]

    def _clone_once(attempt: int) -> tuple[bool, str, bool]:
        """One clone. Returns (ok, message, retryable)."""
        # A prior attempt's partial env is moved ASIDE atomically, never
        # rmtree'd in place: over NFS an in-place delete leaves busy files
        # behind and the retry clones into a polluted dir (see
        # _set_aside_partial_env). Conda always targets the canonical prefix.
        _set_aside_partial_env(target)
        started = time.time()
        try:
            with open(log_path, "w" if attempt == 1 else "a") as lf:
                if attempt > 1:
                    lf.write(f"\n\n===== attempt {attempt} =====\n")
                _accept_conda_tos(conda_bin, log_file=lf)
                lf.write(f"$ {' '.join(cmd)}\n")
                lf.flush()
                proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT,
                                        start_new_session=True)
                # Bounded wait with a heartbeat. `subprocess.run` here had no
                # timeout: on 2026-08-03 a clone wedged on a sick NFS mount and
                # hung for FIVE DAYS with zero output, the project stuck at
                # "running" the whole time. An unbounded external call in the
                # launch path is never acceptable — and silence for minutes is
                # its own bug (users read it as a freeze).
                deadline = started + timeout
                next_beat = started + _PROVISION_HEARTBEAT_SECONDS
                while True:
                    try:
                        proc.wait(timeout=2)
                        break
                    except subprocess.TimeoutExpired:
                        pass
                    now = time.time()
                    if now >= deadline:
                        _kill_tree(proc)
                        lf.write(f"\n[ark] TIMEOUT after {timeout}s — killed\n")
                        lf.flush()
                        _set_aside_partial_env(target)
                        # Not retryable: a wedged mount stays wedged, and a
                        # second full timeout doubles the wait before the user
                        # hears anything.
                        return False, (
                            f"conda create timed out after {timeout // 60} min cloning "
                            f"'{base_env}'. The base env may be enormous or the "
                            f"filesystem unresponsive; see {log_path}"), False
                    if now >= next_beat:
                        next_beat = now + _PROVISION_HEARTBEAT_SECONDS
                        if log_fn:
                            log_fn(f"still provisioning… {_provision_progress(log_path)}, "
                                   f"{int(now - started)}s elapsed")
            elapsed = time.time() - started
            if proc.returncode != 0 or not project_env_ready(project_dir):
                return False, f"conda create failed (rc={proc.returncode}); see {log_path}", True
            return True, f"cloned {base_env} in {elapsed:.1f}s", False
        except Exception as e:
            return False, f"conda create raised {type(e).__name__}: {e}", True

    # Reclaim debris set aside by earlier runs before we start (best-effort).
    _sweep_stale_envs(target)
    for attempt in range(1, _PROVISION_ATTEMPTS + 1):
        ok, msg, retryable = _clone_once(attempt)
        if ok:
            _sweep_stale_envs(target)
            return ok, msg
        if not retryable or attempt == _PROVISION_ATTEMPTS:
            return ok, msg
        if log_fn:
            log_fn(f"env provisioning hit a transient error, retrying "
                   f"({attempt}/{_PROVISION_ATTEMPTS - 1}) on a clean slate…")
        # Back off further on each retry so a transient NFS wobble has time to
        # clear rather than being hit again 20s later.
        time.sleep(_PROVISION_RETRY_PAUSE_SECONDS * attempt)
    return False, "env provisioning exhausted all attempts"  # unreachable


def find_claude_binary() -> str | None:
    """
    Locate the ``claude`` CLI even when systemd's bare PATH doesn't include
    the user's nvm/npm bin dir. Tries shutil.which, $HOME/.local/bin, then
    every nvm node version's bin dir, then a few common npm prefixes.
    """
    found = shutil.which("claude")
    if found:
        return found
    home = Path(os.path.expanduser("~"))
    candidates: list[Path] = [home / ".local" / "bin" / "claude"]
    nvm_dir = home / ".nvm" / "versions" / "node"
    if nvm_dir.is_dir():
        # Newest version first so we pick the actively used one.
        try:
            for v in sorted(nvm_dir.iterdir(), reverse=True):
                candidates.append(v / "bin" / "claude")
        except OSError:
            pass
    candidates += [
        home / ".npm-global" / "bin" / "claude",
        Path("/usr/local/bin/claude"),
    ]
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    return None


def find_gemini_binary() -> str | None:
    """Locate the ``gemini`` CLI (analogous to find_claude_binary)."""
    found = shutil.which("gemini")
    if found:
        return found
    home = Path(os.path.expanduser("~"))
    candidates: list[Path] = [
        home / ".local" / "bin" / "gemini",
        home / ".npm-global" / "bin" / "gemini",
        Path("/usr/local/bin/gemini"),
        Path("/opt/homebrew/bin/gemini"),
    ]
    # Check nvm for gemini as well (it's often an npm package)
    nvm_dir = home / ".nvm" / "versions" / "node"
    if nvm_dir.is_dir():
        try:
            for v in sorted(nvm_dir.iterdir(), reverse=True):
                candidates.append(v / "bin" / "gemini")
        except OSError:
            pass
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    return None


def build_subprocess_path(extra: list[str] | None = None) -> str:
    """
    Build a PATH string suitable for spawning ARK subprocesses (the orchestrator,
    the OpenHands CLI, etc.) when the parent process has a bare systemd PATH.
    Prepends: the openhands binary dir, ~/.local/bin (uv tool install location),
    texlive 2025 bin, plus any caller-supplied dirs, then the existing PATH.
    """
    import shutil
    parts: list[str] = list(extra or [])
    home = Path(os.path.expanduser("~"))

    # Shared team locations first (env vars or pyproject [tool.ark]) — then
    # per-user fallbacks.
    from ark.paths import get_team_config
    _team = get_team_config()
    for v in (_team.get("tools_bin"), os.environ.get("ARK_TEXLIVE_BIN", "").strip()):
        if v and Path(str(v)).is_dir():
            parts.append(str(v))

    openhands = shutil.which("openhands")
    if openhands:
        parts.append(str(Path(openhands).parent))

    # `uv tool install` puts the openhands entry point here.
    parts.append(str(home / ".local" / "bin"))

    texlive = home / "texlive" / "2025" / "bin" / "x86_64-linux"
    if texlive.is_dir():
        parts.append(str(texlive))

    existing = os.environ.get("PATH", "/usr/bin:/bin")
    # Dedupe while preserving order.
    seen: set[str] = set()
    out: list[str] = []
    for p in parts + existing.split(":"):
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return ":".join(out)


def _run(cmd: list[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, **kwargs)


def slurm_available() -> bool:
    # Escape hatch: set ARK_FORCE_LOCAL=1 to bypass SLURM submission and run
    # everything as local subprocesses (useful when slurmctld spool is full or
    # the cluster is unavailable). Falsy values ("", "0", "false") are ignored.
    force_local = os.environ.get("ARK_FORCE_LOCAL", "").strip().lower()
    if force_local and force_local not in ("0", "false", "no", "off"):
        return False
    return shutil.which("sbatch") is not None


_CLAUDE_VERSION_CACHE = None

def get_claude_version() -> str:
    """Detect and cache the current version of the Claude CLI."""
    global _CLAUDE_VERSION_CACHE
    if _CLAUDE_VERSION_CACHE:
        return _CLAUDE_VERSION_CACHE
    try:
        r = _run(["claude", "--version"])
        # Output: "2.0.32 (Claude Code)"
        m = re.search(r"([\d\.]+)", r.stdout)
        if m:
            _CLAUDE_VERSION_CACHE = m.group(1)
            return _CLAUDE_VERSION_CACHE
    except Exception:
        pass
    return "0.1.0"


_GEMINI_VERSION_CACHE = None

def get_gemini_version() -> str:
    """Detect and cache the current version of the Gemini CLI."""
    global _GEMINI_VERSION_CACHE
    if _GEMINI_VERSION_CACHE:
        return _GEMINI_VERSION_CACHE
    try:
        r = _run(["gemini", "--version"])
        m = re.search(r"([\d\.]+)", r.stdout)
        if m:
            _GEMINI_VERSION_CACHE = m.group(1)
            return _GEMINI_VERSION_CACHE
    except Exception:
        pass
    return "0.1.0"


def provision_claude_session(target_dir: Path, keys: dict[str, str]):
    """
    Writes a manual ~/.claude.json to skip onboarding.
    Requires oauth_token, account_uuid, email, and org_uuid in keys.
    """
    if "claude_oauth_token" not in keys:
        return
    
    config = {
        "hasCompletedOnboarding": True,
        "lastOnboardingVersion": get_claude_version()
    }
    
    target_dir.mkdir(parents=True, exist_ok=True)
    import json
    (target_dir / ".claude.json").write_text(json.dumps(config))


def provision_gemini_session(target_dir: Path, keys: dict[str, str]):
    """
    Writes a manual credentials file for Gemini CLI if gemini_oauth_json is provided.
    """
    oauth_json = keys.get("gemini_oauth_json")
    if not oauth_json:
        return
    
    # Gemini CLI looks for credentials in ~/.gemini/oauth_creds.json
    gemini_dir = target_dir / ".gemini"
    gemini_dir.mkdir(parents=True, exist_ok=True)

    creds_file = gemini_dir / "oauth_creds.json"
    creds_file.write_text(oauth_json)
    creds_file.chmod(0o600)  # Restrict to owner only

    # Pre-create the project registry so the CLI's atomic write (tmp→rename) is
    # never triggered on first run — that rename fails inside macOS temp dirs.
    registry_file = gemini_dir / "projects.json"
    if not registry_file.exists():
        registry_file.write_text('{"projects":{}}')

    # Write settings.json to select OAuth auth and suppress IDE nudges.
    settings_file = gemini_dir / "settings.json"
    settings_file.write_text(
        '{\n'
        '  "ide": {\n'
        '    "hasSeenNudge": true,\n'
        '    "enabled": true\n'
        '  },\n'
        '  "security": {\n'
        '    "auth": {\n'
        '      "selectedType": "oauth-personal"\n'
        '    }\n'
        '  }\n'
        '}'
    )


def api_keys_to_env(api_keys: dict[str, str]) -> dict[str, str]:
    """Map user API-key entries to the standard provider env-var names shared by
    the local orchestrator subprocess env and the remote VM's ``.env``.

    Only the provider string→string mappings live here (claude oauth, ``*_api_key``,
    ``aws_*``, ``azure_*``). File-based creds (``gcp_service_account_json`` → a creds
    file) and orchestrator-only vars (``github_pat``/``github_org``) are local-launch
    concerns and stay in ``launch_local_job``; the cloud VM gets its GCP identity from
    the instance service account, not a synced key file. Single source of truth so a
    newly-supported provider key reaches both launch paths."""
    env: dict[str, str] = {}
    for k, v in (api_keys or {}).items():
        if not v:
            continue  # never export empty-valued keys — absence IS the signal
        if k == "claude_oauth_token":
            env["CLAUDE_CODE_OAUTH_TOKEN"] = v
        elif k.endswith("_api_key") or k in ("gemini", "anthropic", "openai", "openrouter"):
            # openrouter → OPENROUTER_API_KEY so LiteLLM can route first-party
            # models through the OpenRouter proxy.
            env_key = f"{k.upper()}_API_KEY" if "_api_key" not in k.lower() else k.upper()
            env[env_key] = v
        elif k in ("aws_account_id", "aws_region"):
            # SkyPilot launcher-routing metadata (which account/region to assume
            # into) — NOT run credentials. The cloud identity comes from the
            # launcher's assumed role, not a synced key, so skip these like
            # gcp_project below (else the long-tail branch would mis-inject them as
            # bogus AWS_ACCOUNT_ID_API_KEY / AWS_REGION_API_KEY env vars).
            continue
        elif k in ("aws_access_key_id", "aws_secret_access_key", "aws_default_region"):
            env[k.upper()] = v
        elif k.startswith("azure_"):
            env[k.upper()] = v
        elif k.startswith(("gcp_", "github_")) or k == "gemini_oauth_json":
            continue  # file-based / orchestrator-local concerns, not env keys
        elif isinstance(v, str) and v and k.isidentifier():
            # Long-tail provider key stored under its BARE provider name
            # ('deepseek', 'xai', 'mistral', …) by the Settings "Other
            # providers" sweep. Matches llm_lite.provider_key_env's
            # <PROVIDER>_API_KEY convention, which the OpenHands engine reads.
            # Without this branch such keys were stored + verified but NEVER
            # injected into runs — a user with a valid direct DeepSeek key had
            # two launches die with "no key found" (2026-07-05).
            env[f"{k.upper()}_API_KEY"] = v
    return env


def _auto_partition() -> str:
    """Try to detect an available partition from sinfo."""
    try:
        r = _run(["sinfo", "-h", "-o", "%P"])
        partitions = [p.rstrip("*") for p in r.stdout.split() if p]
        # Prefer non-GPU partitions (ARK uses no GPU)
        for p in partitions:
            if "gpu" not in p.lower():
                return p
        return partitions[0] if partitions else ""
    except Exception:
        return ""


def _auto_account() -> str:
    """Read the Slurm default account of the user submitting the job."""
    try:
        r = _run(["sacctmgr", "-nP", "show", "user", "where",
                  f"name={getpass.getuser()}", "format=DefaultAccount"])
        if r.returncode != 0:
            return ""
        accounts = r.stdout.split()
        return accounts[0] if accounts else ""
    except Exception:
        return ""


def submit_job(
    project_id: str,
    mode: str,
    max_iterations: int,
    project_dir: Path,
    log_dir: Path,
    settings,
    api_keys: dict[str, str] = None,
) -> str:
    """Render slurm_template.sh and submit via sbatch. Returns job_id string."""
    partition = settings.slurm_partition or _auto_partition()
    account = settings.slurm_account or _auto_account()

    safe_api_keys = {k: shlex.quote(v) for k, v in (api_keys or {}).items()}

    # HTTP /v1 transport when configured, else legacy shared DB path.
    cp_url, cp_token = control_plane_transport(project_id, settings)
    from website.dashboard.db import resolve_db_path
    db_path = "" if cp_url else resolve_db_path()

    template_text = _SLURM_TEMPLATE.read_text()
    script = Template(template_text).render(
        project_id=project_id,
        project_dir=str(project_dir),
        log_dir=str(log_dir),
        # Quote every value that lands in the shell script. `mode` is validated
        # to an allowlist at the API boundary, but quote here too so the submit
        # script can never be injected regardless of caller.
        mode=shlex.quote(mode),
        max_iterations=max_iterations,
        partition=partition,
        account=account,
        gres=settings.slurm_gres,
        cpus_per_task=settings.slurm_cpus_per_task,
        conda_env=settings.slurm_conda_env,
        api_keys=safe_api_keys,
        api_env=api_keys_to_env(safe_api_keys),
        db_path=db_path,
        control_plane_url=shlex.quote(cp_url) if cp_url else "",
        control_plane_token=shlex.quote(cp_token) if cp_token else "",
        ark_code_root=str(Path(__file__).resolve().parents[2]),
        ark_python=shlex.quote(sys.executable),
    )

    if api_keys:
        provision_claude_session(project_dir, api_keys)
        provision_gemini_session(project_dir, api_keys)

    script_path = log_dir / "submit.sh"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Securely write script with 0600 permissions immediately
        if script_path.exists():
            script_path.unlink()
        script_path.write_text(script)
        script_path.chmod(0o600)

        result = _run(["sbatch", str(script_path)])
        if result.returncode != 0:
            raise RuntimeError(f"sbatch failed: {result.stderr.strip()}")

        # "Submitted batch job 12345"
        m = re.search(r"(\d+)", result.stdout)
        if not m:
            raise RuntimeError(f"Could not parse job ID from sbatch output: {result.stdout!r}")
        return m.group(1)
    finally:
        # Wipe the script from disk immediately after handing off to SLURM
        if script_path.exists():
            script_path.unlink()


def poll_job(job_id: str) -> str:
    """Return current job state: PENDING, RUNNING, COMPLETED, FAILED, CANCELLED, UNKNOWN."""
    try:
        r = _run(["squeue", "-j", job_id, "-h", "-o", "%T"])
        state = r.stdout.strip()
        if state:
            return state  # PENDING / RUNNING / ...
        # Job not in squeue → check sacct
        r2 = _run(["sacct", "-j", job_id, "-n", "-o", "State", "--noconvert"])
        lines = [l.strip() for l in r2.stdout.splitlines() if l.strip()]
        return lines[0] if lines else "COMPLETED"
    except Exception:
        return "UNKNOWN"


def cancel_job(job_id: str) -> bool:
    """Cancel a SLURM job. Returns True on success."""
    try:
        r = _run(["scancel", job_id])
        return r.returncode == 0
    except Exception:
        return False


def cancel_project_sub_jobs(project_dir: Path) -> list[str]:
    """Cancel every SLURM job whose WorkDir is inside ``project_dir``.

    The orchestrator job submits an arbitrary number of sub-jobs via the
    experimenter agent, named by the agent (e.g. `_exp1_clock_diag`) —
    not by the ``SlurmBackend.job_prefix`` convention. When the webapp
    stops a project, ``cancel_job(project.slurm_job_id)`` only reaches
    the orchestrator; sub-jobs keep running, waste compute, and their
    outputs are never consumed by the dead pipeline.

    We fix this by enumerating the user's queue and using ``scontrol
    show job -o`` to read each job's WorkDir. Any job whose WorkDir
    starts with the project directory belongs to this project, even if
    the agent named it something unexpected.

    Returns the list of cancelled job IDs for logging.
    """
    cancelled: list[str] = []
    project_path = Path(project_dir).resolve()
    try:
        user = os.environ.get("USER", "")
        if not user:
            return cancelled
        r = _run(["squeue", "-u", user, "-h", "-o", "%i"])
        if r.returncode != 0:
            return cancelled
        jobids = [j for j in r.stdout.split() if j.isdigit()]
        for jobid in jobids:
            try:
                info = _run(["scontrol", "show", "job", jobid, "-o"])
                if info.returncode != 0:
                    continue
                # Look for `WorkDir=<path>` in the single-line output.
                m = re.search(r"WorkDir=(\S+)", info.stdout)
                if not m:
                    continue
                workdir = Path(m.group(1))
                if workdir.is_relative_to(project_path):
                    if cancel_job(jobid):
                        cancelled.append(jobid)
            except Exception:
                continue
    except Exception:
        pass
    return cancelled


def slurm_state_to_status(slurm_state: str) -> str:
    """Map SLURM state to ARK webapp status."""
    s = slurm_state.upper()
    if s in ("PENDING", "CONFIGURING", "REQUEUED"):
        return "queued"
    if s in ("RUNNING", "COMPLETING"):
        return "running"
    if s in ("COMPLETED",):
        return "done"
    if s in ("CANCELLED", "TIMEOUT", "PREEMPTED"):
        return "stopped"
    # FAILED, NODE_FAIL, OUT_OF_MEMORY, etc.
    return "failed"


# ── Local subprocess runner ────────────────────────────────────────────────────

def _conda_env_exists(conda_bin: str, env_name: str) -> bool | None:
    """True if the named conda env exists, False if it does not, None if
    conda could not say (it failed or timed out).

    None is not False. The answer decides whether the env gets created, and
    on 2026-10-26 a timed-out listing read the shared ark-base as missing: it
    was created again from environment.yml, which put seven platform packages
    back to older versions for every run.
    """
    # Where named envs live by default, read from disk: nothing to time out.
    root = Path(conda_bin).resolve().parent.parent
    if (root / "envs" / env_name / "conda-meta").is_dir():
        return True
    try:
        result = subprocess.run(
            [conda_bin, "env", "list", "--json"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode != 0:
            return None
        import json as _json
        envs = _json.loads(result.stdout).get("envs", [])
        return any(Path(e).name == env_name for e in envs)
    except Exception:
        return None


def _ensure_named_conda_env(conda_bin: str, env_name: str, log_path: Path) -> tuple[bool, str]:
    """Create the named conda env from the appropriate environment yml if it doesn't exist.

    Picks environment-macos.yml on macOS, environment.yml on Linux. Creates the
    env under the configured name (overriding the name in the yml file). The
    yml deliberately omits ark itself — orchestrator subprocesses get ark via
    the PYTHONPATH that ``launch_local_job`` injects, so the named env stays
    a clean research-stack template that can be safely cloned per-project.
    """
    exists = _conda_env_exists(conda_bin, env_name)
    if exists:
        return True, f"env '{env_name}' already exists"
    if exists is None:
        # Run on the env as it is. If it really is missing, `conda run` says
        # so, which beats creating it over one that is there.
        return True, f"conda could not list its envs; using '{env_name}' as is"

    ark_root = Path(__file__).resolve().parents[2]
    yml_file = ark_root / ("environment-macos.yml" if sys.platform == "darwin" else "environment.yml")
    if not yml_file.exists():
        return False, f"environment file not found: {yml_file}"

    log_path.parent.mkdir(parents=True, exist_ok=True)
    # No --yes: with it, an existing env is removed and built again, which is
    # how a wrong "missing" wiped the shared ark-base. Without it conda keeps
    # the env but still moves its packages to the yml's pins, so the checks
    # above are what must keep an existing env from getting here.
    cmd = [conda_bin, "env", "create", "-f", str(yml_file), "-n", env_name]
    started = time.time()
    try:
        with open(log_path, "w") as lf:
            _accept_conda_tos(conda_bin, log_file=lf)
            lf.write(f"$ {' '.join(cmd)}\n")
            lf.flush()
            proc = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL)
        elapsed = time.time() - started
        if proc.returncode != 0:
            return False, f"conda env create failed (rc={proc.returncode}); see {log_path}"

        if _conda_env_exists(conda_bin, env_name) is False:
            return False, f"conda env create exited 0 but env '{env_name}' not found"

        return True, f"created env '{env_name}' from {yml_file.name} in {elapsed:.1f}s"
    except Exception as e:
        return False, f"conda env create raised {type(e).__name__}: {e}"


def _systemd_user_available() -> bool:
    """True when we can register a transient systemd --user service (i.e. the
    orchestrator can be detached so it survives a webapp restart)."""
    if not shutil.which("systemd-run"):
        return False
    xdg = os.environ.get("XDG_RUNTIME_DIR")
    return bool(xdg) and os.path.exists(os.path.join(xdg, "bus"))


def _launch_detached_orchestrator(wrapper, env, log_file, project_dir, project_id):
    """Launch the orchestrator wrapper as a detached systemd --user transient
    service. Returns its MainPID, or None to tell the caller to fall back to an
    in-webapp child process.

    Why: the orchestrator is a lightweight I/O-bound driver. As a webapp child
    (the historical path) a ``webapp release`` recycles the systemd unit and
    kills it mid-run (BrokenPipeError) — on shared prod any member's release
    nukes everyone's running local jobs. A transient service lives in its own
    cgroup, sibling to the webapp, so the webapp recycling leaves it untouched.

    Secrets ride in a 0600 EnvironmentFile (read by systemd at exec, then
    unlinked) — never on the command line where ``ps`` could see them.
    """
    if not _systemd_user_available():
        return None

    # Launcher pid in the unit name: two webapp processes launching the same
    # project in the same second must NOT collide on the unit name — a
    # collision used to trigger the child-process fallback and double-launch
    # the run (2026-07-07 incident).
    unit = f"ark-orch-{str(project_id)[:8]}-{int(time.time())}-{os.getpid()}"
    env_file = Path(project_dir) / ".orch_env"
    try:
        lines = []
        for k, v in env.items():
            # systemd env names are [A-Za-z_][A-Za-z0-9_]*; skip invalid names
            # (e.g. exported bash functions) and multi-line values.
            if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", k):
                continue
            v = str(v)
            if "\n" in v or "\r" in v:
                continue
            esc = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k}="{esc}"')
        env_file.write_text("\n".join(lines) + "\n")
        os.chmod(env_file, 0o600)

        sd_cmd = [
            "systemd-run", "--user", f"--unit={unit}", "--collect",
            f"--property=StandardOutput=truncate:{log_file}",
            "--property=StandardError=inherit",
            f"--property=WorkingDirectory={project_dir}",
            f"--property=EnvironmentFile={env_file}",
            sys.executable, "-c", wrapper,
        ]
        r = subprocess.run(sd_cmd, capture_output=True, text=True)
        if r.returncode != 0:
            # Do NOT fall back to an in-webapp child here: systemd IS available,
            # so a failure is either a duplicate launch (unit collision — the
            # other launcher owns the run) or a real provisioning error. The
            # child fallback silently forfeits release-survival and, in the
            # collision case, double-launches the run (2026-07-07 incident).
            raise RuntimeError(
                f"systemd-run failed for {unit} (rc={r.returncode}): "
                f"{(r.stderr or '').strip()[:300]}"
            )

        # systemd-run --unit blocks until the unit has started, so MainPID is set.
        q = subprocess.run(
            ["systemctl", "--user", "show", f"{unit}.service", "-p", "MainPID", "--value"],
            capture_output=True, text=True,
        )
        pid = int((q.stdout or "0").strip() or 0)
        if pid <= 0:
            subprocess.run(["systemctl", "--user", "stop", f"{unit}.service"],
                           capture_output=True)
            raise RuntimeError(f"{unit}: no MainPID after systemd-run start")
        return pid
    finally:
        # systemd has already consumed the EnvironmentFile at exec; drop the
        # on-disk secrets immediately, regardless of outcome.
        env_file.unlink(missing_ok=True)


def launch_local_job(
    project_id: str,
    mode: str,
    max_iterations: int,
    project_dir: Path,
    log_dir: Path,
    settings,
    api_keys: dict[str, str] = None,
    apply_instruction: str = "",
    apply_scope: str = "edit",
    chat_message: str = "",
) -> str:
    """Launch orchestrator as a local subprocess. Returns 'local:{host}:{pid}'.

    Prefers a detached systemd --user transient service (survives webapp
    restarts); falls back to an in-webapp child where systemd isn't available.
    """
    from ark.launcher.local import local_handle

    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    log_file = log_dir / f"local_{int(time.time())}.out"
    # The exit sentinel is how the poller learns a vanished run's outcome. A
    # chat/apply helper is a side channel of the run, so it must neither erase
    # the run's sentinel nor leave its own exit code behind as the run's.
    exit_file = None if (apply_instruction or chat_message) else log_dir / "local_exit.txt"
    if exit_file is not None:
        exit_file.unlink(missing_ok=True)

    # Build the orchestrator command, preferring the project-local conda env
    # at <project_dir>/.env. Falls back to the named env from settings, then
    # the webapp's own interpreter.
    conda_bin = find_conda_binary()
    local_env = project_env_prefix(project_dir)
    fallback_env = getattr(settings, "slurm_conda_env", "") or ""
    if conda_bin and project_env_ready(project_dir):
        python_prefix = [conda_bin, "run", "--no-capture-output",
                         "--prefix", str(local_env), "python"]
    elif conda_bin and fallback_env:
        provision_log = log_dir / "conda_provision.log"
        ok, msg = _ensure_named_conda_env(conda_bin, fallback_env, provision_log)
        if not ok:
            raise RuntimeError(f"Could not provision conda env '{fallback_env}': {msg}")
        python_prefix = [conda_bin, "run", "--no-capture-output",
                         "-n", fallback_env, "python"]
    else:
        python_prefix = [sys.executable]

    # Choose the control-plane transport: HTTP /v1 when configured, else the
    # legacy shared-DB path. The token (if any) rides in via env, not argv.
    cp_url, cp_token = control_plane_transport(project_id, settings)
    from website.dashboard.db import resolve_db_path
    db_path = "" if cp_url else resolve_db_path()

    cmd = python_prefix + [
        "-m", "ark.orchestrator",
        "--project", project_id,
        "--project-dir", str(project_dir),
        "--code-dir", str(project_dir),
        "--mode", mode,
        "--iterations", str(max_iterations),
        "--project-id", project_id,
    ]
    if cp_url:
        cmd += ["--control-plane-url", cp_url]
    else:
        cmd += ["--db-path", db_path]
    if apply_instruction:
        # Lightweight targeted change instead of a full iteration loop.
        cmd += ["--apply-instruction", apply_instruction,
                "--apply-scope", apply_scope or "edit"]
    if chat_message:
        # Persistent streaming chat turn (out-of-band management).
        cmd += ["--chat-message", chat_message]

    # Inline wrapper (uses webapp's Python — only needs subprocess + pathlib).
    # Runs orchestrator in the correct env, then writes exit code to sentinel.
    # Also includes a signal handler to ensure sensitive credentials are cleaned up.
    wrapper = (
        "import subprocess as _s, signal as _sig, sys as _sys, shutil as _sh, os\n"
        "from pathlib import Path\n"
        "pdir = Path({project_dir!r})\n"
        "def cleanup(*args):\n"
        "    for d in (pdir / '.gemini', pdir / '.config', pdir / '.claude.json', pdir / '.gcp_credentials.json'):\n"
        "        if d.is_dir(): _sh.rmtree(d, ignore_errors=True)\n"
        "        elif d.is_file(): d.unlink(missing_ok=True)\n"
        "    _sys.exit(0)\n"
        "_sig.signal(_sig.SIGTERM, cleanup)\n"
        "_sig.signal(_sig.SIGINT, cleanup)\n"
        "try:\n"
        "    _r = _s.run({cmd!r})\n"
        "{record_exit}"
        "finally:\n"
        "    cleanup()\n"
    ).format(
        project_dir=str(project_dir), cmd=cmd,
        record_exit=(f"    open({str(exit_file)!r}, 'w').write(str(_r.returncode))\n"
                     if exit_file is not None else ""),
    )

    # Prepare environment with user keys and home isolation
    env = os.environ.copy()
    # The webapp interpreter supplies DSH when the orchestrator uses a conda
    # environment that only has the project's research dependencies.
    if not env.get("ARK_DSH_PYTHON"):
        env["ARK_DSH_PYTHON"] = sys.executable
    # The webapp's own environ may carry server-side credentials: ``ark.cli
    # main()`` loads the operator's global ~/.ark config keys into os.environ
    # at startup (GOOGLE_API_KEY alias included), and /proc-invisible runtime
    # mutations can add more. A user's run must see ONLY the owner's keys —
    # scrub every credential-shaped var before applying api_keys. (Found
    # 2026-07-05: the operator's Gemini key reached user orchestrators as
    # GOOGLE_API_KEY, which deep_research falls back to.)
    _secret_suffixes = ("_API_KEY", "_ACCESS_KEY_ID", "_SECRET_ACCESS_KEY",
                        "_SESSION_TOKEN", "_OAUTH_TOKEN", "_CLIENT_SECRET")
    for _k in list(env):
        if _k.endswith(_secret_suffixes) or _k in (
                "GOOGLE_APPLICATION_CREDENTIALS", "ARK_GITHUB_PAT"):
            del env[_k]
    # Control-plane bearer token via env (never argv) — carried in the 0600
    # EnvironmentFile for the detached systemd unit, then unlinked.
    if cp_token:
        env["ARK_CONTROL_PLANE_TOKEN"] = cp_token
    if api_keys:
        provision_claude_session(project_dir, api_keys)
        provision_gemini_session(project_dir, api_keys)
        # Shared provider keys (claude oauth / *_api_key / aws / azure).
        env.update(api_keys_to_env(api_keys))
        # Local-launch-only extras below.
        if api_keys.get("github_pat"):
            # Orchestrator-only GitHub PAT for auto-push. Exposed solely as
            # ARK_GITHUB_PAT (never as GITHUB_TOKEN) and stripped from the
            # agent subprocess env in ark/engines/cli.py.
            env["ARK_GITHUB_PAT"] = api_keys["github_pat"]
        if api_keys.get("github_org"):
            # Optional org to create project repos under (not secret).
            env["ARK_GITHUB_ORG"] = api_keys["github_org"]
        gcp_json = api_keys.get("gcp_service_account_json")
        if gcp_json:
            # For GCP, we write the JSON to a file and set GOOGLE_APPLICATION_CREDENTIALS
            gcp_creds_path = project_dir / ".gcp_credentials.json"
            gcp_creds_path.write_text(gcp_json)
            gcp_creds_path.chmod(0o600)
            env["GOOGLE_APPLICATION_CREDENTIALS"] = str(gcp_creds_path)
            # Also set standard GCP env vars if available in keys/settings
            if api_keys.get("gcp_project"):
                env["GOOGLE_CLOUD_PROJECT"] = api_keys["gcp_project"]
    
    # Ensure the orchestrator can find the ark package even when running
    # inside a project-local conda env that doesn't have ark installed.
    ark_code_root = str(Path(__file__).resolve().parents[2])
    env["PYTHONPATH"] = ark_code_root + ((":" + env["PYTHONPATH"]) if env.get("PYTHONPATH") else "")
    env["HOME"] = str(project_dir)
    # Keep pinned bundles available to this owner across runs and outside the
    # editable project even when the service has no configured XDG cache.
    if not env.get("XDG_CACHE_HOME"):
        env["XDG_CACHE_HOME"] = str(Path(project_dir).resolve().parent / ".cache")
    env["XDG_CONFIG_HOME"] = str(project_dir / ".config")
    env["TMPDIR"] = str(project_dir)
    # Disable Python's pip user-site discovery so projects are completely
    # isolated — no project can read packages from /home/xinj/.local/... or
    # any other user's user-site. The cloned per-project conda env is the
    # ONLY source of Python packages for the orchestrator.
    env["PYTHONNOUSERSITE"] = "1"
    # Make sure the orchestrator's PATH can find the claude CLI (lives in
    # ~/.nvm/.../bin), latexmk (~/.local/bin), and pdflatex (~/texlive/2025/...).
    # systemd's bare PATH doesn't include any of these.
    env["PATH"] = build_subprocess_path()

    # Prefer a detached systemd --user service so the orchestrator survives a
    # webapp restart/redeploy; fall back to an in-webapp child otherwise.
    pid = _launch_detached_orchestrator(wrapper, env, log_file, project_dir, project_id)
    if pid is not None:
        return local_handle(pid)

    with open(log_file, "w") as lf:
        proc = subprocess.Popen(
            [sys.executable, "-c", wrapper],
            stdout=lf,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            cwd=str(project_dir),
            env=env,
        )

    return local_handle(proc.pid)


def poll_local_job(pid: int, log_dir: Path) -> str:
    """
    Return RUNNING, COMPLETED, or FAILED for a local subprocess job.

    Also reaps the wrapper subprocess if it's a finished child (zombie).
    Plain ``os.kill(pid, 0)`` returns success for zombies — the kernel
    only checks "is this PID slot occupied" — so without this we'd see
    finished projects stuck in RUNNING forever.
    """
    # Try waitpid first; this both checks state AND reaps if it's our
    # child and has finished.
    try:
        wpid, _status = os.waitpid(pid, os.WNOHANG)
        if wpid == 0:
            # Child still running.
            return "RUNNING"
        # wpid == pid → was a zombie, just reaped → fall through to sentinel.
    except ChildProcessError:
        # Not our child (e.g. reparented to PID 1 after a webapp restart,
        # or never our child at all). Fall back to existence check.
        try:
            os.kill(pid, 0)
            return "RUNNING"
        except ProcessLookupError:
            pass
        except PermissionError:
            # Process exists but we can't signal it — it's alive.
            return "RUNNING"

    # Process really has exited — check the sentinel the wrapper writes.
    exit_file = Path(log_dir) / "local_exit.txt"
    if exit_file.exists():
        code = exit_file.read_text().strip()
        return "COMPLETED" if code == "0" else "FAILED"
    return "FAILED"


def cancel_local_job(pid: int) -> bool:
    """Cancel a local job.

    If the orchestrator runs as a detached ``ark-orch-*`` systemd --user service
    (the default when systemd is available), stop the whole unit so its entire
    process tree — orchestrator plus all agent subprocesses — is killed. Else
    fall back to signalling the process group of an in-webapp child.
    """
    try:
        cg = Path(f"/proc/{pid}/cgroup").read_text()
        m = re.search(r"/(ark-orch-[A-Za-z0-9:_.\-]+\.service)", cg)
        if m:
            subprocess.run(["systemctl", "--user", "stop", m.group(1)],
                           capture_output=True)
            return True
    except Exception:
        pass
    try:
        pgid = os.getpgid(pid)
        os.killpg(pgid, signal.SIGTERM)
        return True
    except Exception:
        return False
