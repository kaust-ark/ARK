"""Load ARK webapp configuration from .ark/webapp.env."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

from ark.paths import get_ark_root, get_config_dir, get_primary_ip


def _env_file() -> Path:
    return get_config_dir() / "webapp.env"

_DEFAULTS = {
    "BASE_URL": f"http://{get_primary_ip()}:9527",
    "EMAIL_DOMAINS": "",
    "SMTP_HOST": "smtp.gmail.com",
    "SMTP_PORT": "587",
    "SMTP_USER": "",
    "SMTP_PASSWORD": "",
    "SMTP_RELAY": "",
    "SMTP_FROM": "contact@idea2paper.org",
    "PROJECTS_ROOT": "",  # resolved lazily
    "SECRET_KEY": secrets.token_hex(32),
    "DB_PATH": "",  # resolved lazily
    "SLURM_PARTITION": "",
    "SLURM_ACCOUNT": "",
    "SLURM_CONDA_ENV": "ark-base",
    # Base conda env that each new project's per-project env is cloned from.
    # ark-base is the project template env with runtime deps (numpy, pandas,
    # matplotlib, anthropic, etc.) but NOT the ARK code itself.
    # ark-dev and ark-prod are for developing/deploying the ARK webapp.
    # Set to empty to disable per-project env provisioning entirely.
    "PROJECT_BASE_CONDA_ENV": "ark-base",
    "GOOGLE_CLIENT_ID": "",
    "GOOGLE_CLIENT_SECRET": "",
    # SkyPilot cloud compute (the central launcher SA provisions per-user)
    "CLOUD_GCP_PROJECT": "",         # central GCP project holding the baked ARK image
    "CLOUD_LAUNCHER_SA": "",         # central ark-launcher service-account email
    "CLOUD_LAUNCHER_ORG_CUSTOMER_ID": "",  # directory customer id of the launcher SA's org (for Domain Restricted Sharing allowlists)
    "CLOUD_LAUNCHER_SA_KEY": "~/.config/ark/ark-launcher-sa-key.json",
    "CLOUD_CONDA_ENV": "ark-base",   # base conda env cloned per project on the remote
    # AWS launcher (parallels the GCP launcher SA). The central launcher identity
    # in the operator's account assumes a per-tenant role in each user's account
    # (STS AssumeRole); the user grants access by creating that role with a trust
    # policy naming our identity. No per-user key material touches this DB.
    "CLOUD_LAUNCHER_ROLE_ARN": "",   # ARN of OUR launcher identity (named in each tenant trust policy)
    "CLOUD_AWS_REGION": "",          # default region for tenant launches when a user sets none
    "CLOUD_LAUNCHER_AWS_PROFILE": "ark-launcher",  # base ~/.aws profile holding the launcher's source creds
    "CLOUD_LAUNCHER_AWS_CREDENTIAL_SOURCE": "",    # set (e.g. Ec2InstanceMetadata) to use the host role instead of a base profile
    "CLOUD_LAUNCHER_AWS_EXTERNAL_ID": "",          # optional STS ExternalId (confused-deputy protection)
}


def _load_env_file() -> dict[str, str]:
    env: dict[str, str] = {}
    if _env_file().exists():
        for line in _env_file().read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            env[k.strip()] = v.strip()
    return env


def _write_default_env():
    """Create .ark/webapp.env with placeholder values on first run."""
    ip = get_primary_ip()
    _root = get_ark_root()
    _config_dir = get_config_dir()
    content = f"""\
# ARK Web App configuration
# Edit this file, then restart: ark webapp

BASE_URL=http://{ip}:9527

# SMTP — required for magic link login
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_RELAY=
SMTP_FROM=contact@idea2paper.org

# Allowed emails (comma-separated). If set, only these addresses can log in.
ALLOWED_EMAILS=

# Or restrict by domain only (comma-separated, e.g. kaust.edu.sa). Ignored if ALLOWED_EMAILS is set.
EMAIL_DOMAINS=

# Admin emails (comma-separated). Admins can disable/enable the webapp and kill all jobs.
ADMIN_EMAILS=

# Google OAuth (optional). Get credentials at console.cloud.google.com → APIs & Services → Credentials.
# Redirect URI to register: <BASE_URL>/auth/google/callback  (use the BASE_URL value above)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

PROJECTS_ROOT={_root / '.ark' / 'data' / 'projects'}
SECRET_KEY={secrets.token_hex(32)}
DB_PATH={_root / '.ark' / 'data' / 'webapp.db'}

# Control-plane database. Leave DB_PATH (above) for single-node sqlite dev.
# For a deployed control plane serving concurrent remote orchestrators, set a
# full Postgres DSN here instead (takes priority over DB_PATH):
#   DATABASE_URL=postgresql+psycopg://ark:password@localhost:5432/ark_cp
DATABASE_URL=

# Control-plane API for launched orchestrators. Leave blank to keep the legacy
# in-process shared-DB path. Set to the /v1 base URL to make runs report over
# HTTP (required for remote/BYOC; the orchestrator must be able to reach it):
#   CONTROL_PLANE_URL=http://127.0.0.1:9527/v1   (same-host)
#   CONTROL_PLANE_URL=https://your-host/v1       (remote)
CONTROL_PLANE_URL=

# Optional SLURM settings (auto-detected if blank)
SLURM_PARTITION=
SLURM_ACCOUNT=
SLURM_CONDA_ENV=ark-base

# SkyPilot cloud compute (the central ark-launcher SA provisions per user).
# CLOUD_GCP_PROJECT is the central project holding the baked ARK image; the
# launcher SA + key let the webapp launch AS that identity (see
# scripts/setup_ark_launcher_sa.sh). Blank ⇒ SkyPilot cloud runs are disabled.
CLOUD_GCP_PROJECT=
CLOUD_LAUNCHER_SA=
# Directory customer id (e.g. C0abc1234) of the org that owns the launcher SA.
# If a user's project org enforces Domain Restricted Sharing
# (constraints/iam.allowedPolicyMemberDomains), the generated grant script uses
# this to allowlist the launcher's org before binding roles. Blank ⇒ the script
# emits a discovery helper instead.
CLOUD_LAUNCHER_ORG_CUSTOMER_ID=
CLOUD_LAUNCHER_SA_KEY=~/.config/ark/ark-launcher-sa-key.json
CLOUD_CONDA_ENV=ark-base

# AWS SkyPilot compute (parallels the GCP launcher above). The central launcher
# identity in the operator's account assumes a per-tenant role in each user's
# account (STS AssumeRole); the user grants access by creating that role with a
# trust policy naming CLOUD_LAUNCHER_ROLE_ARN. No per-user key material is stored.
# Run scripts/setup_ark_launcher_aws.sh to create the launcher identity + base
# profile. Blank CLOUD_LAUNCHER_ROLE_ARN ⇒ AWS SkyPilot runs are disabled.
CLOUD_LAUNCHER_ROLE_ARN=
# Default region for tenant launches when a user sets none (e.g. us-east-1).
CLOUD_AWS_REGION=
# Base ~/.aws profile that holds the launcher's source credentials (the identity
# whose ARN is CLOUD_LAUNCHER_ROLE_ARN). Each per-user profile assumes the
# tenant role via this one. Leave as the setup script's default unless you renamed it.
CLOUD_LAUNCHER_AWS_PROFILE=ark-launcher
# Instead of a base profile, source the launcher creds from the webapp host's own
# role: set to Ec2InstanceMetadata (host runs on EC2) or Environment (AWS_* env
# vars). Blank ⇒ use CLOUD_LAUNCHER_AWS_PROFILE.
CLOUD_LAUNCHER_AWS_CREDENTIAL_SOURCE=
# Optional STS ExternalId embedded in the generated trust policy + used on assume
# (confused-deputy protection). Blank ⇒ omitted.
CLOUD_LAUNCHER_AWS_EXTERNAL_ID=
"""
    _env_file().write_text(content)
    print(f"Created config: {_env_file()}")
    print("Edit it to set SMTP credentials, then re-run `ark webapp`.")


class Settings:
    def __init__(self):
        file_env = _load_env_file()
        merged = {**_DEFAULTS, **file_env, **os.environ}

        self.base_url: str = merged.get("BASE_URL", _DEFAULTS["BASE_URL"]).rstrip("/")
        self.smtp_host: str = merged.get("SMTP_HOST", "smtp.gmail.com")
        self.smtp_port: int = int(merged.get("SMTP_PORT", "587"))
        self.smtp_user: str = merged.get("SMTP_USER", "")
        self.smtp_password: str = merged.get("SMTP_PASSWORD", "")
        self.smtp_relay: str = merged.get("SMTP_RELAY", "")
        self.smtp_from: str = merged.get("SMTP_FROM", "ark@localhost")
        _root = get_ark_root()
        _config_dir = get_config_dir()
        self.projects_root: Path = Path(
            os.environ.get("PROJECTS_ROOT")
            or merged.get("PROJECTS_ROOT")
            or str(_root / ".ark" / "data" / "projects")
        )
        self.secret_key: str = merged.get("SECRET_KEY", _DEFAULTS["SECRET_KEY"])
        # DB location — a full SQLAlchemy DSN or a sqlite file path (get_engine
        # accepts either). A DATABASE_URL (e.g. postgresql+psycopg://...) points
        # the control plane at Postgres for concurrent remote orchestrators;
        # ARK_WEBAPP_DB_PATH / DB_PATH keep the single-node sqlite dev default.
        self.db_path: str = (
            os.environ.get("ARK_DATABASE_URL")
            or merged.get("DATABASE_URL")
            or os.environ.get("ARK_WEBAPP_DB_PATH")
            or merged.get("DB_PATH")
            or str(_root / ".ark" / "data" / "webapp.db")
        )
        # Base URL of the /v1 control-plane API. When set, launched orchestrators
        # report over HTTP (network-only boundary) instead of the shared SQLite
        # DB; empty keeps the legacy in-process --db-path path. Should include the
        # /v1 suffix, e.g. "http://127.0.0.1:9527/v1" or "https://host/v1".
        #
        # CONTROL_PLANE_URL commonly references ${BASE_URL} (a webapp.env idiom so
        # the host/tunnel is configured in ONE place, e.g. "${BASE_URL}/v1"). Expand
        # it against the resolved base_url + environment here — otherwise the literal
        # "${BASE_URL}/v1" is handed to remote orchestrators, which crash on their
        # first status report with an opaque urllib "unknown url type" error.
        _cp_raw = merged.get("CONTROL_PLANE_URL", "")
        _cp_expanded = os.path.expandvars(
            _cp_raw.replace("${BASE_URL}", self.base_url).replace("$BASE_URL", self.base_url)
        )
        self.control_plane_url: str = _cp_expanded.rstrip("/")
        self.slurm_partition: str = merged.get("SLURM_PARTITION", "")
        self.slurm_account: str = merged.get("SLURM_ACCOUNT", "")
        self.slurm_conda_env: str = merged.get("SLURM_CONDA_ENV", "ark-base")
        self.project_base_conda_env: str = merged.get("PROJECT_BASE_CONDA_ENV", "ark-base")
        self.slurm_gres: str = merged.get("SLURM_GRES", "")
        self.slurm_cpus_per_task: int = int(merged.get("SLURM_CPUS_PER_TASK", "4"))
        raw_domains = merged.get("EMAIL_DOMAINS", "")
        self.email_domains: list[str] = [d.strip() for d in raw_domains.split(",") if d.strip()]
        raw_allowed = merged.get("ALLOWED_EMAILS", "")
        self.allowed_emails: list[str] = [e.strip().lower() for e in raw_allowed.split(",") if e.strip()]
        raw_admins = merged.get("ADMIN_EMAILS", "")
        self.admin_emails: list[str] = [e.strip().lower() for e in raw_admins.split(",") if e.strip()]

        self.google_client_id: str = merged.get("GOOGLE_CLIENT_ID", "")
        self.google_client_secret: str = merged.get("GOOGLE_CLIENT_SECRET", "")

        # SkyPilot cloud settings. The central "ark-launcher" service account
        # provisions compute into each user's GCP project via an IAM grant — no
        # per-user key. `cloud_gcp_project` is the CENTRAL project that holds the
        # baked ARK image; `cloud_conda_env` is the base env cloned per project.
        self.cloud_gcp_project: str = merged.get("CLOUD_GCP_PROJECT", "")
        # Central "ark-launcher" service account that provisions SkyPilot compute
        # into every user's GCP project (scripts/setup_ark_launcher_sa.sh). Users
        # grant THIS identity access to their project; shown in the onboarding
        # grant instructions. Empty ⇒ derived from GOOGLE_APPLICATION_CREDENTIALS.
        self.cloud_launcher_sa: str = merged.get("CLOUD_LAUNCHER_SA", "")
        # Directory customer id of the launcher SA's org. When a user's project
        # org enforces Domain Restricted Sharing, cross-org members (our launcher
        # SA) are rejected; the grant script allowlists this customer id first.
        self.cloud_launcher_org_customer_id: str = merged.get(
            "CLOUD_LAUNCHER_ORG_CUSTOMER_ID", "")
        # Key file for that SA. If GOOGLE_APPLICATION_CREDENTIALS is unset, the
        # webapp falls back to this so SkyPilot's SDK (ADC) launches AS the SA
        # rather than whatever user account happens to own the host's ADC. Default
        # matches scripts/setup_ark_launcher_sa.sh's output path.
        self.cloud_launcher_sa_key: str = merged.get(
            "CLOUD_LAUNCHER_SA_KEY", "~/.config/ark/ark-launcher-sa-key.json")
        self.cloud_conda_env: str = merged.get("CLOUD_CONDA_ENV", "ark-base")

        # AWS launcher settings (parallel to the GCP launcher SA above). The
        # central launcher identity assumes a per-tenant role in each user's AWS
        # account; users grant access by creating that role with a trust policy
        # naming `cloud_launcher_role_arn`. No per-user key is stored.
        # `cloud_launcher_role_arn` is shown in the onboarding grant instructions;
        # empty ⇒ AWS SkyPilot runs are disabled (mirrors an empty cloud_gcp_project).
        self.cloud_launcher_role_arn: str = merged.get("CLOUD_LAUNCHER_ROLE_ARN", "")
        # Default region for tenant launches when a user configures none.
        self.cloud_aws_region: str = merged.get("CLOUD_AWS_REGION", "")
        # Base ~/.aws profile holding the launcher's source creds. Each rendered
        # per-user profile (skyworkspaces.render_aws_profiles) assumes the tenant
        # role via this one (source_profile). Matches setup_ark_launcher_aws.sh.
        self.cloud_launcher_aws_profile: str = merged.get(
            "CLOUD_LAUNCHER_AWS_PROFILE", "ark-launcher")
        # Alternative to the base profile: source the launcher creds from the
        # host's own role (Ec2InstanceMetadata) or env (Environment). When set,
        # rendered per-user profiles use credential_source instead of source_profile.
        self.cloud_launcher_aws_credential_source: str = merged.get(
            "CLOUD_LAUNCHER_AWS_CREDENTIAL_SOURCE", "")
        # Optional STS ExternalId (confused-deputy protection): embedded in the
        # generated trust policy and passed on assume. Empty ⇒ omitted.
        self.cloud_launcher_aws_external_id: str = merged.get(
            "CLOUD_LAUNCHER_AWS_EXTERNAL_ID", "")

        self.projects_root.mkdir(parents=True, exist_ok=True)


# Module-level singleton
_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        if not _env_file().exists():
            _write_default_env()
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    global _settings
    _settings = Settings()
    return _settings
